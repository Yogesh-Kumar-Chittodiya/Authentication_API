module ExportData
  
  def self.export(data,header,fields)
    wb = xlsx_package.workbook
    wb.styles do |style|
      project_heading = style.add_style(b: true, sz: 14)
      heading = style.add_style(b: true)

      wb.add_worksheet(name: "Items") do |sheet|
        # Add a title row
        sheet.add_row [data.class], style: project_heading
        # # Add the date this was downloaded
        # sheet.add_row ["Downloaded at", Time.now.strftime("%b %-d, %Y")]
        # Add a blank row
        sheet.add_row []
        sheet.add_row header, style: heading
        data.each do |item|
          sheet.add_row fields.map{|field| item[field]}
        end
      end
    end
  end
end