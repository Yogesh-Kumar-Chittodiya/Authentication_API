COLOURS = {'blue' => '#20bae5','total' => '#20bae5','green' => '#2eb85a','up' => '#2eb85a','red'=>'#ff5d5d','down'=>'#ff5d5d','amber'=>'#fdbc02'}
EXTRA_COLOURS = ['#1E90FF','#621F62','#A52A2A','#cccccc','#4D4D4D']

SLA_MATRIX = {
	'gold' => 99.99,
	'silver' =>99.50,
	'bronze' => 99.00,
}
WORKSTREAMS = [
  { "name" => "BI&BPC" , "groups" => ["OMG BI","OMG BI/BPC","OMG BPC"],"pillar"=>"Application"},

  { "name" => "Data Center & SAP Basis" , "groups" => ["OMG Data Center DBA","OMG Data Center Network Operation","OMG Data Center SAP Basis","OMG Data Center System Operation","OMG Regional System Operations"],"pillar"=>"Infrastructure"},
  
  { "name" => "GRC & Authorization" , "groups" => ["OMG GRC & Authorization"],"pillar"=>"Application"},
  
  { "name" => "Network & Security" , "groups" => ["OMG Network","OMG Security","OMG Telephony"],"pillar"=>"Infrastructure"},
  
  { "name" => "Non-SAP" , "groups" => ["OMG Application (INSEE Connect)","OMG Application (OTM)","OMG Application (SFDC)","OMG Application (SharePoint & OpenText)"],"pillar"=>"Application"},
  
  { "name" => "SAP" , "groups" => ["OMG SAP(ABAP)","OMG SAP(B2R)","OMG SAP(Fiori)","OMG SAP(H2R)","OMG SAP(O2C)","OMG SAP(P2P&Q2L) ","OMG SAP(PI)"],"pillar"=>"Application"},
  
  { "name" => "ServiceDesk & EUS" , "groups" => ["OMG SERVICE DESK-ID","OMG SERVICE DESK-LKA","OMG SERVICE DESK-TH","OMG SERVICE DESK-VNM","OMG EUS-BD-HQ","OMG EUS-CLMO","OMG EUS-IECO","OMG EUS-INDO","OMG EUS-LKA-CMBO","OMG EUS-LKA-RCWK","OMG EUS-LKA-T2","OMG EUS-SHIN","OMG EUS-SRBP","OMG EUS-VNM-CATL","OMG EUS-VNM-HCMC","OMG EUS-VNM-HONC","OMG EUS-VNM-NHON","",""],"pillar"=>"Infrastructure"}
]

GROUPS = ["OMG BI/BPC","OMG BPC","OMG BI","OMG Data Center DBA","OMG Data Center Network Operation","OMG Data Center SAP Basis","OMG Regional System Operations - Infra","OMG Regional System Operations","OMG Data Center System Operation","OMG GRC & Authorization","OMG Network","OMG Security","OMG Telephony","OMG Application (INSEE Connect)","OMG Application (OTM)","OMG Application (SFDC)","OMG Application (SharePoint & OpenText)","OMG SAP(ABAP)","OMG SAP(B2R)","OMG SAP(Fiori)","OMG SAP(H2R)","OMG SAP(O2C)","OMG SAP(P2P&Q2L)","OMG SAP(PI)","OMG EUS-BD-HQ","OMG EUS-BD-NRY","OMG EUS-CDC","OMG EUS-CLMO","OMG EUS-IECO","OMG EUS-INDO","OMG EUS-LKA-CMBO","OMG EUS-LKA-PCWK","OMG EUS-LKA-RCWK","OMG EUS-LKA-T2","OMG EUS-SHIN","OMG EUS-SRBP","OMG EUS-VNM-CATL","OMG EUS-VNM-HCMC","OMG EUS-VNM-HIEP","OMG EUS-VNM-HONC","OMG EUS-VNM-NHON","OMG EUS-VNM-THIV","OMG SERVICE DESK-ID","OMG SERVICE DESK-LKA"]
