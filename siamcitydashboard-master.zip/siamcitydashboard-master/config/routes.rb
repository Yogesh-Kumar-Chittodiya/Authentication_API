Rails.application.routes.draw do
  resources :model_report, only: :index
  resources :sap_response_mtds do
    collection do
      get :delete_respones
    end
  end
  resources :sap_response_dailies do
    collection do
      get :delete_respones
    end
  end
  namespace :admin do
    resources :solarwind_device_downtime
    resources :solarwind_interface_downtime
    resources :solarwind_component_downtime
    resources :patch_managements do
      collection do
        get :upload_multiple
        post :post_upload
      end
    end
    resources :backup_reports
    resources :solarwind_interfaces
  end

  devise_for :users, controllers: {
    sessions: 'users/sessions',
    registrations: 'users/registrations'
  }

  resources :export_table_data do
    collection do
      get :export_data
    end
  end


  devise_scope :user do

    post 'users/registrations/duo_verify', to: 'users/registrations#duo_verify', as: :duo_verify
    get 'users/registrations/duo', to: 'users/registrations#duo', as: :duo

    authenticated :user do
      #root :to => "users/registrations#duo"
      root 'dashboards#index', as: :root
      get 'change_password', to: 'users/registrations#edit'
    end

    unauthenticated do
      root 'devise/sessions#new', as: :unauthenticated_root
    end
  end
  #root to: "dashboards#index"

  # mount Blazer::Engine, at: "blazer"

  get "get_bottom_scroll", to: "dashboards#bottom_scroll"
  #get "dashboard", to: "dashboards#index"
  get "dashboards/:type", to: "dashboards#index"
  post "downtimes/create_downtime", to: "downtimes#create_downtime"
  post "downtimes/remove", to: "downtimes#remove"
  get "downtimes/:type", to: "downtimes#index"
  get "admin/downtimes/:type", to: "admin/downtime#index"
  # resources :dashboards do
  #   collection do
  #     get :enterprise
  #     get :analyst
  #   end
  # end

  resources :service_now_reports do
    collection do
     get :open_incidents
     get :open_requests
     get :incident_current_status
     get :open_change_requests
     get :auto_incidents_hiro
     get :incidents
     get :change_requests
     get :service_requests
     get :problems
     get :sla_statistics
     get :customer_feedback
     get :resolution_automation
     get :incident_origin_index
     get :incidents_open
     get :customer_satisfaction
     get :first_call_resolution
     get :overall_sla_status
     get :l2_sla_status
     get :customer_satisfaction_score
     get :critical_priority_tickets
     get :critical_security_alerts
     get :get_data_json
     get :export_data_excel
     get :assessment_feedbacks
     post :set_feedback_data
     post :get_data_json
    end
  end

  resources :pdf_reports

  resources :opsramp_reports do
    collection do
     get :system_performance_sap
     get :system_performance_non_sap
     get :system_availability_sap
     get :system_availability_non_sap
     get :local_system_availability
     get :local_system_availability_1
     get :local_network_availability
     get :o365_availability
     get :dc_patch_management
     get :local_patch_management
     get :non_sap_performance
     get :system_availability_non_sap_devices
     get :system_availability_sap_devices
     get :inventory
    end
  end

  resource :downtimes do
    collection do
      post :set_remarks
    end
  end

  resources :reports do
    collection do
      get :system_performance_sap
      get :system_availability_sap
      get :system_availability_non_sap
      get :sla_status_report_domain
      get :sla_status_report_country
      get :csat_report
      get :incidents_ageing
      get :requests_ageing
      get :first_call_resolution
      get :patch_management_status
      get :internet_link_availability
      get :network_mpls_availability
      get :system_availability_thailand
      get :system_availability_vietnam
      get :system_availability_lanka_bangladesh_indonesia
      get :get_data_json
      post :set_remarks
      post :set_extra_remarks
      post :remove_extra_remarks
      get :export_data_excel
      get :export_data
      get :backup_reports
      get :tickets_ageing
      get :patch_management_status_new
      get :network_response_time
      post :remove_downtime
    end
  end

  resources :service_now_widgets, :only => ['index'] do
    collection do
      get :incident_current_status
      get :change_request_stats
      get :open_tickets_by_resolver_group
      get :open_change_request_by_team
      get :incident_status
      get :live_incidents_scroll
      get :incidents_data
      get :sla_resolution_met
      get :sla_resolution_breached
      get :incidents_ageing
      get :auto_resolved_incidents
      get :open_tickets_by_priority
      get :open_tickets_by_status
      get :open_tickets_by_category
      get :customer_satisfaction_rate
      get :customer_satisfaction
      get :customer_responses
      get :change_requests_data
      get :service_requests_data
      get :problems_data
      get :open_change_request_by_status
      get :open_change_request_by_type
      get :resolution_automation_index
      get :incident_origin_index
      get :overall_ticket_management
    end
  end

  resources :opsramp_widgets, :only => ['index'] do
    collection do
      get :dc_center_sap_and_non_sap
      get :system_op_network_and_end_user
      get :it_security
      get :export_sap_data
      get :export_non_sap_downtime
      get :dc_sap_non_sap
      get :core_application_status
      get :sap_response_status
      get :sap_application_availability
      get :inventory
    end
  end

  namespace :admin do
    get "domain_users", to: "users#domain_wise", :as=>"domain_users"
    resources :widgets do
    end
    resources :servicenow_groups do
    end

    resources :tools_configurations do
    end

    resources :users do
    end

    resources :reports do
    end

    resources :customer_satisfaction_scores, only: [:index, :destroy]
    resources :assessments, only: [:index, :destroy]
    
    get '/search', to: "customer_satisfaction_scores#search"
    get '/search_assessment', to: "assessments#search"

    post "/fetch_customer_statisfaction_score", to: "customer_satisfaction_scores#fetch_customer_satisfaction_score" 
    post "/fetch_incident", to: "customer_satisfaction_scores#fetch_incident"

    resources :manual_availabilities do
      collection do
        get :delete_dc_patch
      end
    end

    resources :customers do
    end

    resources :roles do
    end
    resources :critical_devices do
      collection do
        post :excel_upload
        get :upload
      end
    end

    resources :dashboard do
      member do
        get :manage_users
        patch :update_users
        get :delete_users
      end
    end

    resources :configuration_parameters do
    end

    resources :customer_configurations do
    end
  end
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  # match "*path", to: "errors#catch_404", via: :all
end
