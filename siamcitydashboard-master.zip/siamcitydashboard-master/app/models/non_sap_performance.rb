class NonSapPerformance < ApplicationRecord
end
