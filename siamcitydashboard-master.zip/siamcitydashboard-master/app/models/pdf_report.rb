class PdfReport < ApplicationRecord
end
