class SolarwindDevice < ApplicationRecord
end
