class ServiceRequestAgeingTicket < ApplicationRecord
end
