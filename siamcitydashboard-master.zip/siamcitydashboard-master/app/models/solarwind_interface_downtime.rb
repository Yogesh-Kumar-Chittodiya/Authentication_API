class SolarwindInterfaceDowntime < ApplicationRecord
    validates :DownEventTime, :OutageDurationInSeconds, :created_month, :created_year, presence: true
    validates :OutageDurationInSeconds, presence: true, numericality: { only_integer: true }

end
