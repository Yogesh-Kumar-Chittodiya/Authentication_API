class SapAvailability < ApplicationRecord
end
