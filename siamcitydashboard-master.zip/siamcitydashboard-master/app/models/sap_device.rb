class SapDevice < ApplicationRecord
end
