class ConfigurationParameter < ApplicationRecord
  extend FriendlyId
  #friendly_id :parameter, use: :slugged
  friendly_id :slug_candidates, use: :slugged

  def slug_candidates
    [:parameter, :parameter_and_sequence]
  end

  def parameter_and_sequence
    slug = normalize_friendly_id(parameter)
    sequence = ConfigurationParameter.where("slug LIKE ?","#{slug}%").count + 1
    "#{slug}--#{sequence}"
  end
  
  validates_presence_of :parameter
  validates_uniqueness_of :parameter
  
  has_many :customer_configurations, :dependent => :destroy
end
