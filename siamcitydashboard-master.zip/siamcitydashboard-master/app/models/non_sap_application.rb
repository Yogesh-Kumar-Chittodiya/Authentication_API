class NonSapApplication < ApplicationRecord
end
