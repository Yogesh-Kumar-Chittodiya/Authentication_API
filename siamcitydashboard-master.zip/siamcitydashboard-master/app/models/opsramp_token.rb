class OpsrampToken < ApplicationRecord
end
