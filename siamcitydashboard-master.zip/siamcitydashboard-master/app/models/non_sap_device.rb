class NonSapDevice < ApplicationRecord
  has_many :non_sap_availabilities
  has_many :non_sap_downtimes
end
