class DcDeviceAvailability < ApplicationRecord
end
