class CriticalIncident < ApplicationRecord
end
