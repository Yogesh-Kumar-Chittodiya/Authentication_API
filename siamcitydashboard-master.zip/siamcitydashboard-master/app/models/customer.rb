class Customer < ApplicationRecord
  extend FriendlyId
  friendly_id :name, use: :slugged
  # mount_uploader :logo, LogoUploader
  serialize :tools_configuration, JSON
  
  validates_presence_of :name
  #validates :logo, presence: true, on: :create
  
  has_many :dashboards
  has_many :users
  has_many :customer_configurations
end
