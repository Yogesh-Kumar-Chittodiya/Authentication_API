class WidgetRecord < ApplicationRecord
end
