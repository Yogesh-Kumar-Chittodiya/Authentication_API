class DcSapAvailabilityHour < ApplicationRecord
end
