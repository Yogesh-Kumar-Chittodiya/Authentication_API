class ServicenowUser < ApplicationRecord
end
