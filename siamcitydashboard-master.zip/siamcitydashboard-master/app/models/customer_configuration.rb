class CustomerConfiguration < ApplicationRecord

  serialize :value, JSON

  belongs_to :configuration_parameter
  belongs_to :customer, :optional=>true
  
  validates_presence_of :configuration_parameter_id, :value
  validates_uniqueness_of :configuration_parameter_id, :scope=>"customer_id", :message=>"Configuration of the selected parameter has been done for the selected customer"
end
