class ServicenowFeedback < ApplicationRecord
  DATATABLE_COLUMNS = %w[workstream assignment_group assigned_user ticket_number ticket_priority user created_on state servicedesk_owner rating call_date call_successful remarks].freeze

  class << self
    def datatable_filter(search_value, search_columns)
      result = all
      search_columns.each do |key, value|
        unless value['search']['value'].blank?
          result = result.where("#{DATATABLE_COLUMNS[key.to_i]} LIKE ?", "%#{value['search']['value']}%")
        else
          result = result.all
        end
      end
      result
    end

    def datatable_order(order_column_index, order_dir)
      order("#{ServicenowFeedback::DATATABLE_COLUMNS[order_column_index]} #{order_dir}")
    end
  end
end
