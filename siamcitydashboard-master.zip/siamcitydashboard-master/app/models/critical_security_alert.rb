class CriticalSecurityAlert < ApplicationRecord
end
