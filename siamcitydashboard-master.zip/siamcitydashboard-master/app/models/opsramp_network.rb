class OpsrampNetwork < ApplicationRecord
end
