class DcDeviceUtilization < ApplicationRecord
end
