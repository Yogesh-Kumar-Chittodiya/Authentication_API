class DcDeviceDowntime < ApplicationRecord
end
