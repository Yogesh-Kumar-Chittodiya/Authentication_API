class O365Availability < ApplicationRecord
end
