class Dashboard < ApplicationRecord
  extend FriendlyId
  friendly_id :slug_candidates, use: :slugged
  
  def slug_candidates
    [:name, :name_and_sequence]
  end

  def name_and_sequence
    slug = normalize_friendly_id(name)
    sequence = Dashboard.where("slug LIKE ?","#{slug}%").count + 1
    "#{slug}--#{sequence}"
  end
  
  belongs_to :customer, :optional=>true
	has_many :dashboard_widgets, :autosave => true
	has_many :widgets, through: :dashboard_widgets
  
	has_many :dashboard_users, :autosave => true
	has_many :users, through: :dashboard_users
  
  validates :name, presence: true

  validate :presence_of_widgets
  
  def presence_of_widgets
    if self.dashboard_widgets.length == 0
      errors[:widgets] << "select atleast one widget"
    end
  end
end
