class LocalSystemAvailability < ApplicationRecord
end
