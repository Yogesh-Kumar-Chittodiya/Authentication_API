class OpsrampNetworkAvailability < ApplicationRecord
end
