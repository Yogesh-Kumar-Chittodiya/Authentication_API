class OverallSlaStatus < ApplicationRecord
  DATATABLE_COLUMNS = %w[task_number tsla_sla task_priority task_short_description sccc_sla_u_sccc_sla_text task_assignment_group workstream task_state task_sys_created_on].freeze

  class << self
    
    def datatable_filter(search_value, search_columns)
      result = all
      search_columns.each do |key, value|
        unless value['search']['value'].blank? 
          result = result.where("#{DATATABLE_COLUMNS[key.to_i]} LIKE ?", "%#{value['search']['value']}%")
        else
          result = result.all
        end
      end
      result
    end

    def datatable_order(order_column_index, order_dir)
      order("#{OverallSlaStatus::DATATABLE_COLUMNS[order_column_index]} #{order_dir}")
    end
  end 
end
