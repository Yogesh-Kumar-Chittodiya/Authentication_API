class OpsrampDetail < ApplicationRecord
end
