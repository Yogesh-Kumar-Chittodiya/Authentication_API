class SapResponseMonthly < ApplicationRecord
end
