class CriticalDevice < ApplicationRecord
    validates :ip_address, :host_name,:landscape,:priority, presence: true
end
