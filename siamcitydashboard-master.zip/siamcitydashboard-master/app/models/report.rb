class Report < ApplicationRecord
  validates :title, presence: true
  validates :link, presence: true
  validates :tool, presence: true
  validates :report_type, presence: true
end
