class SapResponseMtd < ApplicationRecord
end
