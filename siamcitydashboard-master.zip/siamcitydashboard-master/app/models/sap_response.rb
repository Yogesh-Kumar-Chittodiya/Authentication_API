class SapResponse < ApplicationRecord
end