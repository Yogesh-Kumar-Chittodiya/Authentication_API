class DcSapAvailability < ApplicationRecord
end
