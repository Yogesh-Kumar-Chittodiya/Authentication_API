class CriticalServer < ApplicationRecord
end
