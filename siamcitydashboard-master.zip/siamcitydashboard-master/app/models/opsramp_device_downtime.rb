class OpsrampDeviceDowntime < ApplicationRecord
  belongs_to :opsramp_device
end
