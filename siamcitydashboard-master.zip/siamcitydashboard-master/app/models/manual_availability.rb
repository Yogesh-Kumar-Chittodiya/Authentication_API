class ManualAvailability < ApplicationRecord
end
