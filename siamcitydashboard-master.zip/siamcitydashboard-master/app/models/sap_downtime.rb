class SapDowntime < ApplicationRecord
  belongs_to :sap_device
end
