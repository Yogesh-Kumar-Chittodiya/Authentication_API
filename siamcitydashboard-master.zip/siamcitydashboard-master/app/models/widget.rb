class Widget < ApplicationRecord
  serialize :filters, JSON
  serialize :options, JSON

	has_many :dashboard_widgets
	has_many :dashboards, through: :dashboard_widgets
    
  validates :name, :title, :file_name, :size_type, :module, :widget_type, presence: true
  
  validate :filter_presence
  
  def filter_presence
    if self.widget_type == "historical"
      if self.filters.present?
        self.filters.each_with_index do |filter,key|
          if !filter['title'].present?
            errors[:"filter_title_#{key}"] << "can't be blank"
          end
          if !filter['type'].present?
            errors[:"filter_type_#{key}"] << "can't be blank"
          end
          if !filter['count'].present?
            errors[:"filter_count_#{key}"] << "can't be blank"
          end
        end
      end
    end
  end
end
