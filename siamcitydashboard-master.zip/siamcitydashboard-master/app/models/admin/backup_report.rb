class Admin::BackupReport < ApplicationRecord
end
