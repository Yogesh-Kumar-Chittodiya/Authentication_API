class Admin::PatchManagement < ApplicationRecord
end
