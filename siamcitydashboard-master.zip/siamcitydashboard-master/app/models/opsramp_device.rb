class OpsrampDevice < ApplicationRecord
  has_many :opsramp_device_availabilities
  has_many :opsramp_device_downtimes
end
