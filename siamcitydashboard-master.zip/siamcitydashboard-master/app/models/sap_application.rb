class SapApplication < ApplicationRecord
end
