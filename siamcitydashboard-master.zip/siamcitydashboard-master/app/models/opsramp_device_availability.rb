class OpsrampDeviceAvailability < ApplicationRecord
  belongs_to :opsramp_device
end
