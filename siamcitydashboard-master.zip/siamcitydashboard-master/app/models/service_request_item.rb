class ServiceRequestItem < ApplicationRecord
end
