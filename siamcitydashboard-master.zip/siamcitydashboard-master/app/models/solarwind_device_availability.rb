class SolarwindDeviceAvailability < ApplicationRecord
end
