class SolarwindComponentDowntime < ApplicationRecord
    validates :DownEventTime, :OutageDurationInSeconds, :created_month, :created_year, presence: true
    validates :OutageDurationInSeconds, presence: true, numericality: { only_integer: true }
    validate :compnonet_name_present

    def compnonet_name_present
        if self.ComponentName.blank?
            errors.add(:ComponentName, "can't be blank")
        end
    end
end
