class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
         
	has_many :dashboard_users
	has_many :dashboards, through: :dashboard_users
  belongs_to :customer, :optional=>true
  
  # before_save :check_customer

  def check_customer
    if !self.customer.present?
      self.customer_id = 0
    end
  end
end
