class SolarwindResponseTime < ApplicationRecord
end
