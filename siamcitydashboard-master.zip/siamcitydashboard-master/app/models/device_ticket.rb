class DeviceTicket < ApplicationRecord
end
