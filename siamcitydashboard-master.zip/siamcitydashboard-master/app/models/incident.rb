class Incident < ApplicationRecord
DATATABLE_COLUMNS = %w[number category subcategory incident_state caller_id assignment_group assigned_to sys_created_on].freeze
  class << self
    def datatable_filter(search_value, search_columns)
      result = all
      search_columns.each do |key, value|
        unless value['search']['value'].blank?
          result = result.where("#{DATATABLE_COLUMNS[key.to_i]} LIKE ?", "%#{value['search']['value']}%")
        else
          result = result.all
        end
      end
      result
    end

    def datatable_order(order_column_index, order_dir)
      order("#{Incident::DATATABLE_COLUMNS[order_column_index]} #{order_dir}")
    end
  end
end
