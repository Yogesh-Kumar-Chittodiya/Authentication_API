class NonSapDowntime < ApplicationRecord
  belongs_to :non_sap_device
end
