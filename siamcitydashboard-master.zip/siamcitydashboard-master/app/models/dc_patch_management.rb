class DcPatchManagement < ApplicationRecord
end
