class ServicenowGroup < ApplicationRecord
end
