class SolarwindInterface < ApplicationRecord
end
