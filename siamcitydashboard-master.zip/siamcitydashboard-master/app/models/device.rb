class Device < ApplicationRecord
  
end
