class IncidentAgeingTicket < ApplicationRecord
end
