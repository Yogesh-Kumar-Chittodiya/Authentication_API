class RemarksModule < ApplicationRecord
end
