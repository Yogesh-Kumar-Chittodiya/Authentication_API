class DcDeviceUtilizationHour < ApplicationRecord
end
