class SapResponseDaily < ApplicationRecord
end
