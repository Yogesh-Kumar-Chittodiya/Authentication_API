class RegionalNetworkAvailability < ApplicationRecord
end
