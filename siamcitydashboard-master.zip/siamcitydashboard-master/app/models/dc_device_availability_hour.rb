class DcDeviceAvailabilityHour < ApplicationRecord
end
