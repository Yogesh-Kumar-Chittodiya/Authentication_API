class NonSapPerformanceHour < ApplicationRecord
end
