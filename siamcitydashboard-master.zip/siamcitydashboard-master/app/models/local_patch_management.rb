class LocalPatchManagement < ApplicationRecord
end
