class DashboardWidget < ApplicationRecord
	belongs_to :dashboard
	belongs_to :widget
end
