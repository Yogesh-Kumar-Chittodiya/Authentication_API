class DcDevice < ApplicationRecord
end
