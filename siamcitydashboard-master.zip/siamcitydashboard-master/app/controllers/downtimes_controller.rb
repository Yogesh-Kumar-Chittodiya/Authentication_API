class DowntimesController < ApplicationController
  before_action :set_month, :check_role
  def index
    if params.present? && params[:type].present?
      @type = params[:type]

      case params[:type]

      # NEW SAP Downtime
      when 'sap_dc_downtime_solarwind'
        host_names = ['CI URLMSG Srv URL','CI URLMSG - HBP/BW','CI URLMSG - HRP/HCM','PIP - F5 Loadbalancer URL','ADP URL','FIP CI','GRP CI','BOP URL','SPP ABAP URL']
        @sap_devices = SapDevice.where(:host_name => host_names).all
        # raise @sap_devices.inspect
        componentids = @sap_devices.map{|device| device.component_id}

        @downtimes = SolarwindComponentDowntime.where(:is_delete => [nil,false],:ComponentID => componentids,:created_month => @month,:created_year => @year).group_by{|down| down[:ComponentID]}

        @title = 'System Availability ( SAP )'
        @query_display = {}
      # END

      # NEW NON SAP Downtime
      when 'non_sap_dc_downtime_solarwind'
        @app_data = SolarwindDeviceDowntime.where(:is_delete => [nil,false],:created_month => @month,:created_year => @year,:DataCenter => 'Thailand DC').group_by{|interface| interface.NodeID}
        @devices = SolarwindDevice.where(:DataCenter => 'Thailand DC').all
        @title = 'System Availability ( NON - SAP )'
        @query_display = {}
      # END

      # Thailand Downtime
      when 'thailand_downtime'
        @app_data = SolarwindDeviceDowntime.where(:created_month => @month,:created_year => @year,:DataCenter => 'Thailand',:is_delete => [nil,false]).group_by{|interface| interface.NodeID}

        @devices = SolarwindDevice.where(:DataCenter => 'Thailand').all
        @title = 'System Downtime - Thailand'
        @query_display = {}
      # End

      # Vietnam Downtime
      when 'vietnam_downtime'
        @app_data = SolarwindDeviceDowntime.where(:created_month => @month,:created_year => @year,:DataCenter => 'Vietnam',:is_delete => [nil,false]).group_by{|interface| interface.NodeID}
        @devices = SolarwindDevice.where(:DataCenter => 'Vietnam').all
        @title = 'System Downtime - Vietnam'
        @query_display = {}
      # End

      # SriLanka Downtime
      when 'srilanka_downtime'
        @app_data = SolarwindDeviceDowntime.where(:created_month => @month,:created_year => @year,:DataCenter => 'Sri Lanka',:is_delete => [nil,false]).group_by{|interface| interface.NodeID}
        @devices = SolarwindDevice.where(:DataCenter => 'Sri Lanka').all
        @title = 'System Downtime - Sri Lanka'
        @query_display = {}
      # End

      # Bangladesh and Indonesia
      when 'bangladesh_indonesia_downtime'
        opsramp_devices = OpsrampDevice.where(:device_type => ["Server","Linux","Windows","VMware"]).all
        @device_downtime_month = OpsrampDeviceDowntime.where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:opsramp_device_id => opsramp_devices,:is_delete => [nil,false]).group_by{|down| down[:opsramp_device_id]}
        @opsramp_devices_critical = opsramp_devices
        @title = 'System Downtime - Bangladesh,Indonesia'
        @format = "%"
        @query_display = {}
      # end

      # internet downtime
      when 'internet_downtime'
        if current_user.role == 'developer'
          @downtime_data_device = SolarwindInterfaceDowntime.where(:created_month => @month,:MPLS_Details => nil,:created_year => @year).all
        else
          @downtime_data_device = SolarwindInterfaceDowntime.where(:created_month => @month,:MPLS_Details => nil,:created_year => @year,:is_delete => [nil,false]).all
        end
        @devices = SolarwindInterface.where(:MPLS_Details => nil).all
        if @downtime_data_device.count > 0
          @downtime_data_device = @downtime_data_device.group_by{|interface| interface.InterfaceID}
        else
          @downtime_data_device = []
        end
        @title = 'Internet Link Downtime'
        @query_display = {}
      # end of internet downtime

      # MPLS Downtime
      when 'mpls_downtime'
        @devices = SolarwindInterface.where(:Interface_Details => nil).all
        if current_user.role == 'developer'
          @downtime_data_device = SolarwindInterfaceDowntime.where(:created_month => @month,:created_year => @year,:Interface_Details => nil).group_by{|interface| interface.InterfaceID}
        else
          @downtime_data_device = SolarwindInterfaceDowntime.where(:created_month => @month,:created_year => @year,:Interface_Details => nil,:is_delete => [nil,false]).group_by{|interface| interface.InterfaceID}
        end
        @title = 'Network MPLS Downtime'
        @query_display = {}
      end
      # END
      @remarks = RemarksModule.where(:report_name => @title).all
    else
    end
  end

  def set_remarks
    isremove = ''
    if params.present?
      if (params[:optionsRadios].downcase == 'planned') || (params[:optionsRadios].downcase == 'false')
        isremove = true
      else
        isremove = false
      end

      if params[:downtime_type] == 'non_sap_downtime'
        NonSapDowntime.find(params[:downtime_id]).update(:remark => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'sap_downtime'
        SapDowntime.find(params[:downtime_id]).update(:remark => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'sap_downtime_solarwind'
        SolarwindComponentDowntime.find(params[:downtime_id]).update(:remarks => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'opsramp_device_downtime'
        OpsrampDeviceDowntime.find(params[:downtime_id]).update(:remark => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'solarwind_interface'
        SolarwindInterfaceDowntime.find(params[:downtime_id]).update(:remarks => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'solarwind_device'
        SolarwindDeviceDowntime.find(params[:downtime_id]).update(:remarks => params[:remarks],:isremoved => isremove)
      else
        return true
      end
      return true
    else
      return true
    end
  end

  def create_downtime
    if params.present?
      starttime = Time.zone.parse(params[:startdate])
      endtime = Time.zone.parse(params[:enddate])
      case params["timezone"]
      when 'ict','wit'
        downtime = starttime.to_time - 7.hours
      when 'ist'
        downtime = starttime.to_time - 5.hours - 30.minutes
      when 'bst'
        downtime = starttime.to_time - 6.hours
      else
         downtime = starttime.to_time - 7.hours	
      end

      if params[:downtime_type].present? && params[:downtime_type] != ''
        case params[:downtime_type]
        when 'sap_downtime_solarwind'
          devices = params[:device]
          devices.each do |dev|
            device = SapDevice.where(:component_id => dev).first
            SolarwindComponentDowntime.create ComponentName: "#{device.primary_app} - #{device.host_name}",ComponentID: dev,Message: "#{device.primary_app} Application down",DownEventTime: downtime,OutageDurationInSeconds: (endtime.to_i - starttime.to_i),created_date: starttime.beginning_of_month.to_time.strftime("%Y-%m-%d 00:00:00"),created_month: starttime.strftime("%B"),created_year: starttime.strftime("%Y"),remarks: params[:remarks],is_delete: false,isremoved: (params[:planned].downcase == 'yes') ? true : false
          end
        when 'thailand_downtime','vietnam_downtime','non_sap_dc_downtime_solarwind','solarwind_device'
          devices = params[:device]
          devices.each do |dev|
            device = SolarwindDevice.where("lower(Caption) = ?",dev.downcase).first
            SolarwindDeviceDowntime.create StatusLED: 'Up.gif',Caption: dev,NodeID: device.NodeID,DataCenter: device.DataCenter,Devicetype: device.MachineType,IPAddress: device.IPAddress,Message: "#{device.MachineType} Server down",DownEventTime: downtime,OutageDurationInSeconds: (endtime.to_i - starttime.to_i),created_date: starttime.beginning_of_month.to_time.strftime("%Y-%m-%d 00:00:00"),created_month: starttime.strftime("%B"),created_year: starttime.strftime("%Y"),remarks: params[:remarks],is_delete: false,isremoved: (params[:planned].downcase == 'yes') ? true : false
          end
        when 'internet_downtime','mpls_downtime'
          @downtime = SolarwindInterfaceDowntime.new
          device = SolarwindInterface.where("InterfaceID = ?",params[:device]).first
          SolarwindInterfaceDowntime.create StatusLED: 'Up.gif',Interface_Details: device.Interface_Details, MPLS_Details: device.MPLS_Details, NodeID: device.NodeID,InterfaceID: device.InterfaceID, DataCenter: device.DataCenter, FullName: device.FullName, Message: "#{device.FullName} internet down", DownEventTime: downtime,OutageDurationInSeconds: (endtime.to_i - starttime.to_i),created_date: starttime.beginning_of_month.to_time.strftime("%Y-%m-%d 00:00:00"),created_month: starttime.strftime("%B"),created_year: starttime.strftime("%Y"),remarks: params[:remarks],is_delete: false,isremoved: (params[:planned].downcase == 'yes') ? true : false

        when 'opsramp_device'
          devices = params[:device]
          devices.each do |dev|
            device = OpsrampDevice.find(dev)
            OpsrampDeviceDowntime.create opsramp_device_id: device.id, start_time: starttime.to_i, end_time: endtime.to_i, downtime_date: downtime.beginning_of_month.to_time.strftime("%Y-%m-%d"), total_downtime: (endtime.to_i - starttime.to_i), remark: params[:remarks], is_delete: false, isremoved: (params[:planned].downcase == 'yes') ? true : false
          end
        end
      end
    end
  end

  def remove
    if params.present?
      if params['type'].present? && params['id'].present?
        case params['type']
        when 'component'
          downtime = SolarwindComponentDowntime.find(params[:id])
          (downtime.is_delete) ? downtime.update(:is_delete => false) : downtime.update(:is_delete => true)
        when 'device'
          downtime = SolarwindDeviceDowntime.find(params[:id])
          (downtime.is_delete) ? downtime.update(:is_delete => false) : downtime.update(:is_delete => true)
        when 'interface'
          downtime = SolarwindInterfaceDowntime.find(params[:id])
          (downtime.is_delete) ? downtime.update(:is_delete => false) : downtime.update(:is_delete => true)
        when 'opsramp'
          downtime = OpsrampDeviceDowntime.find(params[:id])
          (downtime.is_delete) ? downtime.update(:is_delete => false) : downtime.update(:is_delete => true)
        end
      end
    end
  end

  private


  def set_month
    month_hash = ["january","february","march","april","may","june","july","august","september","october","november","december"]

    if params.present? && params['month'].present?
      full_month = params['month']
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    elsif params.present? && params[:query_string].present? && params[:query_string][:month].present?
      full_month = params[:query_string][:month]
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    else
      month_d = (Time.current.beginning_of_month)
      @month = month_hash[month_d.month - 1]
      @year = month_d.year
    end
    @month_date = month_d.strftime("%Y-%m-%d")
    @month_end = month_d.end_of_month.strftime("%Y-%m-%d")
    @diff = month_d.end_of_month.to_i - month_d.to_i
    @last_three_months = []
    (1..6).each do |t|
      @last_three_months.push((Time.now.utc - (7-t).month).strftime("%B-%Y").downcase)
    end
    @groups_niit = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).map{|group| group.group_name}
  end

   # def set_month
   #    month_hash = ["january","february","march","april","may","june","july","august","september","october","november","december"]
   #    if params.present? && params['month'].present?
   #      @month = params['month']
   #      month_number = month_hash.index(@month) + 1
   #      month_d = Time.new(2020,month_number,1)
   #    elsif params.present? && params[:query_string].present? && params[:query_string][:month].present?
   #      @month = params[:query_string][:month]
   #      month_number = month_hash.index(@month) + 1
   #      month_d = Time.new(2020,month_number,1)
   #    else
   #      month_d = (Time.current.beginning_of_month)
   #      @month = month_hash[month_d.month - 1]
   #    end
   #    @month_date = month_d.strftime("%Y-%m-%d")
   #    @month_end = month_d.end_of_month.strftime("%Y-%m-%d")
   #    @diff = month_d.end_of_month.to_i - month_d.to_i
   #    @last_three_months = []
   #    (1..3).each do |t|
   #      @last_three_months.push((Time.now.utc - (3-t).month).strftime("%B").downcase)
   #    end
   #    @last_three_months.delete('april')
   #    @last_three_months.delete('may')
   #    @groups_niit = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).map{|group| group.group_name}
   # end

   def check_role
     unless ['downtime_user','coforge_admin','developer','coforge_read'].include?current_user.role
       redirect_to root_path
     end
   end
end
