class DailyreportsController < ReportsController
  def index 
  end

  def device_availability_and_downtime
    device_rest_resource = File.read("public/uploads/devices.json")
    total_devices_filtered = JSON.parse(device_rest_resource)

     # if client is present
    if params[:customer].present?
      @customer = params[:customer]
    else
      @customer = "5c0f9654cc18a12b2096fdd1"
    end
    total_devices_filtered = total_devices_filtered.select{|device| device['client_id'] === @customer}.map{|y| y}
    @total_files = total_devices_filtered
  end

  def incidents_closed_daily

    incident_rest_resource = File.read("public/uploads/incidents.json")
    total_incidents = JSON.parse(incident_rest_resource)

    # Remove auto incidents
    total_incidents = total_incidents.select{|data| data['sys_created_by'].downcase.to_s != "eurostar_opsramp"}.map{|y|y}

    # if client is present
    if params[:customer].present? && params[:customer] != ''
      @customer = params[:customer]
    else
      @customer = "5c0f9654cc18a12b2096fdd1"
    end

    # if client is present
    if params[:date].present? && params[:date] != ''
      @date = params[:date]
    else
      @date = Date.today.strftime("%Y-%m-%d")
    end

    total_incidents = total_incidents.select{|device| device['client_id'] === @customer}.map{|y| y}


    total_incidents = total_incidents.select{|device| (device['closed_at'].present? && device['closed_at'].to_time.strftime("%Y-%m-%d")) === @date}.map{|y| y}

    @total_files = total_incidents
  end

  def service_items_open_backlog_daily
    service_request_rest_resource = File.read("public/uploads/service_requests.json")
    total_service_requests = JSON.parse(service_request_rest_resource)

    # if client is present
    if params[:customer].present? && params[:customer] != ''
      @customer = params[:customer]
    else
      @customer = "5c0f9654cc18a12b2096fdd1"
    end

    # if client is present
    if params[:date].present? && params[:date] != ''
      @date = params[:date]
    else
      @date = Date.today.strftime("%Y-%m-%d")
    end

    total_service_requests = total_service_requests.select{|device| device['client_id'] === @customer}.map{|y| y}

    # If Service Request is in Approved,Rejected,Awaiting Approval
    total_service_requests = total_service_requests.select{|device| (device['state'].present? && ['1','2','-5'].include?(device['state']))}.map{|y| y}

    # upto current date
    total_service_requests = total_service_requests.select{|device| (device['created_on'].present? && device['created_on'].to_time.strftime("%Y-%m-%d")) <= @date}.map{|y| y}

    @total_files = total_service_requests
  end

end
