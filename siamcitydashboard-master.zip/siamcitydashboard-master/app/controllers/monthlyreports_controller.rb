class MonthlyreportsController < ReportsController
  include ServiceNow

  def index
   
  end

  def service_requests_breached_monthly
    # start_date = Date.today.beginning_of_month
    # end_date = Date.today.end_of_month
    # query = "inc_sys_created_onBETWEEN#{start_date.strftime("%Y-%m-%d")},#{end_date.end_of_month.strftime("%Y-%m-%d")}&taskslatable_has_breached=true"
    # @service_requests_total = getincidentSLAs(query)
    @service_requests_total = ''
  end
end
