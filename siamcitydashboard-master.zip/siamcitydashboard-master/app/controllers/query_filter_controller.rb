class QueryFilterController < ApplicationController
  def get_data
    results = []
    if params.present?
      query = (params[:query].present?) ? params[:query] : ''
      table_name = (params[:table_name].present?) ? params[:table_name] : ''
      if table_name == ''
        results = []
      elsif query == ''
        

      end
    else

    end
    return results 
  end
end
