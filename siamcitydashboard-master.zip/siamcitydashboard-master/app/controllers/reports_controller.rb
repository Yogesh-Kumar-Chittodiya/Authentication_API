class ReportsController < ApplicationController
  before_action :set_month
  layout "application"
  # before_action :check_role

  def index
    @reports_modules = [
      ['System Availability (SAP) - Data Center',system_availability_sap_reports_path],
      ['System Availability (Non-SAP) - Data Center',system_availability_non_sap_reports_path],
      ['System Performance (SAP ) - Data Center',system_performance_sap_reports_path],
      ['Overall Tickets SLA Status',sla_status_report_domain_reports_path],
      ['Customer Satisfaction Score',csat_report_reports_path],
      ['Tickets Ageing',tickets_ageing_reports_path],
      ['First Call Resolution',first_call_resolution_reports_path],
      ['Patch Management Status',patch_management_status_reports_path],
      ['Patch Management Status - New',patch_management_status_new_reports_path],
      ['Backup Report',backup_reports_reports_path],
      ['Network Response Time Report',network_response_time_reports_path],
      ['Internet Link Availability',internet_link_availability_reports_path],
      ['Network MPLS Availability',network_mpls_availability_reports_path],
      ['System Availability - Thailand',system_availability_thailand_reports_path],
      ['System Availability - Vietnam',system_availability_vietnam_reports_path],
      ['System Availability - SriLanka,Bangladesh,Indonesia',system_availability_lanka_bangladesh_indonesia_reports_path]]
  end

  def network_response_time
    # devices = ['10.228.249.10','10.226.5.73','10.229.50.42','10.229.53.134','10.226.29.73','10.95.1.48','10.224.248.4','10.224.248.5']
    @response = SolarwindResponseTime.where("created_month = ? AND created_year = ?",@month,@year)
    # raise @response.count.inspect
    @title = 'Network Response Time'
    @query_display = {}
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year=>@year).all
    @labels = @response.map{|res| res.Caption}
    @data = [{"name" => "Network Response Time", "data" => @response.map{|res| res.AvgResponseTime.to_f.round(2)}},{"name" => "Monthly SLA","data" => @response.count.times.map{|d| 200}}]
    @type='network_response_time'
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('network_response_time','Landscape')
      end
    end
  end

  def internet_link_availability
    bar_data = [
      { "name" => "downtime" , "data" => []},
      { "name" => "Target SLA" , "data" => [],"type" => 'spline',"marker" => { "lineWidth" => 5,"lineColor" => "#000", "fillColor" => 'white'}},
      { "name" => "Month SLA" , "data" => [],"type" => 'column'},
      { "name" => "Number of Downtime" , "data" => []},
    ]
    @bar_labels = []
    # solarwind
    @solarwind_systems_internet = SolarwindInterface.where(:MPLS_Details => nil).all
    downtime_of_devices = SolarwindInterfaceDowntime.where(:isremoved => [nil,false]).where(:created_month => @month,:created_year => @year).where(:is_delete => [nil,false]).where(:MPLS_Details => nil).all

    if downtime_of_devices.count > 0
      downtime_month = downtime_of_devices.group_by{|down| down[:InterfaceID]}.map{|key,value| [key, value.sum{|per| per[:OutageDurationInSeconds].to_i}]}
    else
      downtime_month = []
    end

    @solarwind_systems_internet.each do |solar|
      @bar_labels.push(solar.Interface_Details)
      bar_data[1]["data"].push(99.7)
      downtime = downtime_month.select{|sap| sap[0] == solar.InterfaceID.to_s}
      if downtime.count > 0
        bar_data[2]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(3))
      else
        bar_data[2]["data"].push(100.0)
      end
    end

    @downtime_data_device = downtime_of_devices.group_by{|interface| interface.InterfaceID}
    @percentage_data = [bar_data[2],bar_data[1]]
    @downtime_data = [bar_data[3]]
    @title = 'Internet Link Availability'
    @format = "%"
    @type='internet_link_availability'
    @query_display = {}
    @disabled_months = ['june']
    @remarks = RemarksModule.where(:report_name => @title,:created_month => @month,:created_year => @year).all
    if @month == 'july' && @year.to_s == '2020'
      @percentage_data = [{ "name" => "Month SLA" , "data" => [100,100,100,41.8,100,100,98.52,100,100,100,54.93,8.3,8.3,7.26,7.26,100],"type" => 'column'},bar_data[1]]
    end
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('internet_link_availability','Landscape')
      end
    end
  end

  def network_mpls_availability
    bar_data = [
      { "name" => "SLA Met" , "data" => []},
      { "name" => "Target SLA" , "data" => [],"type" => 'spline',"marker" => { "lineWidth" => 5,"lineColor" => "#000", "fillColor" => 'white'}},
      { "name" => "Month SLA" , "data" => [],"type" => 'column'},
      { "name" => "Number of Downtime" , "data" => []},
      { "name" => "SLA Breached" , "data" => []},
    ]
    drilldown_data = []
    @bar_labels = []
    # solarwind

    @solarwind_systems_internet = SolarwindInterface.where(:Interface_Details => nil)

    downtime_of_devices = SolarwindInterfaceDowntime.where(:isremoved=> [nil,false]).where(:created_month => @month,:created_year => @year).where(:Interface_Details => nil).where(:is_delete => [nil,false]).all

    if downtime_of_devices.count > 0
      downtime_month = downtime_of_devices.group_by{|down| down[:InterfaceID]}.map{|key,value| [key, value.sum{|per| per[:OutageDurationInSeconds].to_i}]}
    else
      downtime_month = []
    end

    @solarwind_systems_internet_grouped = @solarwind_systems_internet.group_by{|sola|sola.DataCenter}

    solarwind_ids = @solarwind_systems_internet.map{|solar| solar.InterfaceID}
    solarwind_availability = SolarwindInterfaceAvailabilityHour.where("created_date BETWEEN ? AND ?",@month_date,@month_end).where(:InterfaceID => solarwind_ids).group_by{|solar|solar.InterfaceID}.map{|key,value| {key => ((value.sum{|per| per['Availability'].to_i})/value.count.to_f).round(2)}}
    @solarwind_systems_internet_grouped = @solarwind_systems_internet_grouped.each do |site,solar|
      drill_data = {"name" => site ,"id" => site, "data" => []}
      @met = 0
      @breached = 0

      solar.each do |solar_dev|
        downtime = downtime_month.select{|sap| sap[0] == solar_dev.InterfaceID.to_s}
        if downtime.count > 0
          availability = ((1 - downtime[0][1].to_f/@diff)*100).round(3)
          drill_data["data"].push([solar_dev.MPLS_Details,availability])
          solar_dev.Status = availability
          if solar_dev.Status.to_f > 99.4
            @met+= 1
          else
            @breached+= 1
          end
        else
          drill_data["data"].push([solar_dev.MPLS_Details,100.0])
          solar_dev.Status = 100.0
          @met+= 1
        end
        drilldown_data.push(drill_data)
      end
      bar_data[0]["data"].push({
        'name' => site,
        'y' => @met,
        'drilldown' => site
      })
      bar_data[4]["data"].push({
        'name' => site,
        'y' => @breached,
        'drilldown' => site
      })
    end
    @datasets_data = [bar_data[0],bar_data[4]]
    @drilldown_data = drilldown_data
    @title = 'Network MPLS Availability'
    @format = "%"
    @type='network_mpls_availability'
    @query_display = {}
    @disabled_months = ['june']
    @remarks = RemarksModule.where(:report_name => @title,:created_month => @month,:created_year => @year).all
    @downtime_data_device = downtime_of_devices.group_by{|interface| interface.InterfaceID}
    if @month == 'july' && @year.to_s == '2020'
      @datasets_data = [{"name"=>"SLA Met", "data"=>[{"name"=>"Thailand DC", "y"=>8, "drilldown"=>"Thailand DC"}, {"name"=>"Thailand", "y"=>7, "drilldown"=>"Thailand"}, {"name"=>"Vietnam", "y"=>1, "drilldown"=>"Vietnam"}, {"name"=>"Cambodia", "y"=>2, "drilldown"=>"Cambodia"}, {"name"=>"Sri Lanka", "y"=>14, "drilldown"=>"Sri Lanka"}]}, {"name"=>"SLA Breached", "data"=>[{"name"=>"Thailand DC", "y"=>1, "drilldown"=>"Thailand DC"}, {"name"=>"Thailand", "y"=>1, "drilldown"=>"Thailand"}, {"name"=>"Vietnam", "y"=>15, "drilldown"=>"Vietnam"}, {"name"=>"Cambodia", "y"=>0, "drilldown"=>"Cambodia"}, {"name"=>"Sri Lanka", "y"=>3, "drilldown"=>"Sri Lanka"}]}]
    end
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('network_mpls_availability','Landscape')
      end
    end
  end

  def system_availability_thailand
    bar_data = [
      { "name" => "downtime" , "data" => []},
      { "name" => "Target SLA" , "data" => [],"type" => 'spline',"marker" => { "lineWidth" => 5,"lineColor" => "#000", "fillColor" => 'white'}},
      { "name" => "Achieved Availability" , "data" => [],"type" => 'column'},
      { "name" => "Number of Downtime" , "data" => []},
      { "name" => "Non Critical Devices" , "data" => []}
    ]
    @bar_labels = []
    devices_cri = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical',:landscape => 'Thailand')
    devices_non = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Non-Critical',:landscape => 'Thailand')
    critical_devices = devices_cri.pluck(:ip_address)
    # critical_devices = CriticalDevice.select('ip_address').all.map{|crt|crt.ip_address}
    solarwind_systems_thailand = SolarwindDevice.where(:IsServer => true).where(:DataCenter => 'Thailand').all
    downtime_of_devices = SolarwindDeviceDowntime.where(:is_delete => [nil,false]).where(:created_month => @month,:created_year => @year).where(:DataCenter => 'Thailand')

    @critical_systems = solarwind_systems_thailand.where(:IPAddress => critical_devices).all
    solarwind_ids = @critical_systems.map{|solar| solar.NodeID}
    # calculate downtime count and total downtime
    if downtime_of_devices.count > 0
      downtime_data_device_count = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|interface| interface.NodeID}.map{|ki,val| {ki.to_i => val.count}}
      downtime_data_device_total = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|interface| interface.NodeID}.map{|key,value| [key.to_i, value.sum{|per| per[:OutageDurationInSeconds].to_i}]}
    else
      downtime_data_device_count = []
      downtime_data_device_total = []
    end
    # end

    @critical_systems = @critical_systems.each do |solar|
      device = devices_cri.select{|dec|dec.ip_address == solar.IPAddress}.first
      if device.present?
        solar.DisplayName = device.host_name
        solar.MachineType = device.logical_name
      end
      @bar_labels.push(solar.SysName.upcase)
      downtime_month = (downtime_data_device_total.select{|sap| sap[0] == solar.NodeID})[0]
      downtime_count = (downtime_data_device_count.select{|sap| sap.key? solar.NodeID})[0]
      if downtime_month.present?
        bar_data[2]["data"].push(((1 - downtime_month[1].to_f/@diff)*100).round(2))
      else
        bar_data[2]["data"].push(100)
      end
      if downtime_count.present?
        bar_data[3]["data"].push(downtime_count[solar.NodeID])
      else
        bar_data[3]["data"].push(0)
      end
    end

    # for non critical systems
    @solarwind_systems_non_critical = SolarwindDevice.where(:IsServer => true).where(:DataCenter => 'Thailand').where.not(:IPAddress => critical_devices).all
    @non_critical_labels = []
    @solarwind_systems_non_critical.each do |solar|
      device = devices_non.select{|dec|dec.ip_address == solar.IPAddress}.first
      if device.present?
        solar.DisplayName = device.host_name
        solar.MachineType = device.logical_name
      end
      @non_critical_labels.push(solar.SysName.upcase)
      downtime_month = (downtime_data_device_total.select{|sap| sap[0] == solar.NodeID})[0]
      downtime_count = (downtime_data_device_count.select{|sap| sap.key? solar.NodeID})[0]
      if downtime_month.present?
        bar_data[4]["data"].push(((1 - downtime_month[1].to_f/@diff)*100).round(2))
      else
        bar_data[4]["data"].push(100)
      end
    end
    # end

    @app_data = downtime_of_devices.where(:IPAddress => critical_devices).group_by{|interface| interface.NodeID}
    @percentage_data = [bar_data[2]]
    @percentage_data_2 = [bar_data[4]]
    @downtime_data = [bar_data[3]]
    @title = 'System Availability - Thailand'
    @format = "%"
    @type='system_availability_thailand'
    @query_display = {}
    @disabled_months = ['june']
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    if @month == 'july' && @year.to_s == '2020'
      @percentage_data = [{ "name" => "Achieved Availability" , "data" => [99.9,99.9,99.9,99.89,56.05,53.9,53.9,53.42,53.43,55.62,55.63,100,99.99,100,100,100,100,99.78,100,100],"type" => 'column'}]
    end
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('system_availability_thailand')
      end
    end
  end

  def system_availability_vietnam
    bar_data = [
      { "name" => "downtime" , "data" => []},
      { "name" => "Target SLA" , "data" => [],"type" => 'spline',"marker" => { "lineWidth" => 5,"lineColor" => "#000", "fillColor" => 'white'}},
      { "name" => "Achieved Availability" , "data" => [],"type" => 'column'},
      { "name" => "Number of Downtime" , "data" => []},
      { "name" => "Non Critical Devices" , "data" => []}
    ]
    @bar_labels = []
    devices_prod = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical',:landscape => 'Vietnam')
    devices_nonprod = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Non-Critical',:landscape => 'Vietnam')
    ip_non_address = devices_nonprod.pluck(:ip_address)
    critical_devices = devices_prod.pluck(:ip_address)
    # critical_devices = CriticalDevice.select('ip_address').all.map{|crt|crt.ip_address}
    @solarwind_devices = SolarwindDevice.where(:DataCenter => 'Vietnam').where(:IPAddress => critical_devices).all

    solarwind_ids = @solarwind_devices.map{|solar| solar.NodeID}
    downtime_of_devices = SolarwindDeviceDowntime.where(:is_delete => [nil,false]).where(:created_month => @month,:created_year => @year).where(:DataCenter => 'Vietnam').all

    if downtime_of_devices.count > 0
      downtime_month = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|down| down[:NodeID]}.map{|key,value| [key, value.sum{|per| per[:OutageDurationInSeconds].to_i}]}
      downtime_month_count = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|device| device.NodeID}.map{|ki,val| {ki.to_i => val.count}}
    else
      downtime_month = []
      downtime_month_count = []
    end

    @app_data = downtime_of_devices.where(:IPAddress => critical_devices).group_by{|interface| interface.NodeID}
    @solarwind_devices.each do |solar|
      @bar_labels.push(solar.SysName.upcase)
      device = devices_prod.select{|dec|dec.ip_address == solar.IPAddress}.first
      if device.present?
        solar.DisplayName = device.host_name
        solar.MachineType = device.logical_name
      end
      downtime_count = (downtime_month_count.select{|sap| sap.key? solar.NodeID})[0]
      downtime = downtime_month.select{|sap| sap[0] == solar.NodeID.to_s}
      if downtime.count > 0
        bar_data[2]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(2))
        bar_data[3]["data"].push(downtime_count[solar.NodeID])
      else
        bar_data[2]["data"].push(100.0)
        bar_data[3]["data"].push(0)
      end
    end

    # for non critical systems
    @solarwind_systems_non_critical = SolarwindDevice.where(:IsServer => true).where(:DataCenter => 'Vietnam').where(:IPAddress => ip_non_address).all
    @non_critical_labels = []
    @solarwind_systems_non_critical.each do |solar|
      device = devices_nonprod.select{|dec|dec.ip_address == solar.IPAddress}.first
      if device.present?
        solar.DisplayName = device.host_name
        solar.MachineType = device.logical_name
      end
      @non_critical_labels.push(solar.SysName.upcase)
      downtime = downtime_month.select{|sap| sap[0] == solar.NodeID.to_s}
      if downtime.count > 0
        bar_data[4]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(2))
      else
        bar_data[4]["data"].push(100.0)
      end
    end
    # end

    @percentage_data = [bar_data[2]]
    @percentage_data_2 = [bar_data[4]]
    @downtime_data = [bar_data[3]]
    @title = 'System Availability - Vietnam'
    @format = "%"
    @type='system_availability_vietnam'
    @query_display = {}
    @disabled_months = ['june']
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    if @month == 'july' && @year.to_s == '2020'
      @percentage_data = [{ "name" => "Achieved Availability" , "data" => [58.39,97.79,97.85,0,97.83,97.85,97.85,84.89,97.84,77.23,97.75,97.57,97.83,86.14,96.86,23.72,94.33,94.33,97.85,97.85],"type" => 'column'}]
    end
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('system_availability_vietnam','Landscape')
      end
    end
  end

  def system_availability_lanka_bangladesh_indonesia
    bar_data = [
        { "name" => "downtime" , "data" => []},
        { "name" => "Target SLA" , "data" => [],"type" => 'spline',"marker" => { "lineWidth" => 5,"lineColor" => "#000", "fillColor" => 'white'}},
        { "name" => "Achieved Availability" , "data" => [],"type" => 'column'},
        { "name" => "Number of Downtime" , "data" => []},
        { "name" => "Non Critical Devices" , "data" => []}
    ]
    @bar_labels = []
    devices_prod = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical',:landscape => 'Sri Lanka')
    devices_nonprod = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Non-Critical',:landscape => 'Sri Lanka')
    critical_devices = devices_prod.pluck(:ip_address)

    # critical_devices = CriticalDevice.select('ip_address').all.map{|crt|crt.ip_address}
    @solarwind_systems_internet = SolarwindDevice.where(:DataCenter => 'Sri Lanka').where(:IPAddress => critical_devices).all
    solarwind_ids = @solarwind_systems_internet.map{|solar| solar.NodeID}
    downtime_of_devices = SolarwindDeviceDowntime.where(:is_delete => [nil,false]).where(:created_month => @month,:created_year => @year).where(:DataCenter => 'Sri Lanka').all

    if downtime_of_devices.count > 0
      downtime_month_solarwind = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|down| down[:NodeID]}.map{|key,value| [key, value.sum{|per| per[:OutageDurationInSeconds].to_i}]}
      downtime_month_count = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|device| device.NodeID}.map{|ki,val| {ki.to_i => val.count}}
    else
      downtime_month_solarwind = []
      downtime_month_count = []
    end

    @app_data = downtime_of_devices.where(:IPAddress => critical_devices).group_by{|interface| interface.NodeID}
    @solarwind_systems_internet.each do |solar|
      device = devices_prod.select{|dec|dec.ip_address.strip == solar.IPAddress}.first
      if device.present?
        solar.DisplayName = device.host_name
        solar.MachineType = device.logical_name
      end
      @bar_labels.push(solar.DisplayName.upcase)
      downtime_count = (downtime_month_count.select{|sap| sap.key? solar.NodeID})[0]
      downtime = downtime_month_solarwind.select{|sap| sap[0] == solar.NodeID.to_s}
      if downtime.count > 0
        bar_data[2]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(2))
        bar_data[3]["data"].push(downtime_count[solar.NodeID])
      else
        bar_data[2]["data"].push(100.0)
        bar_data[3]["data"].push(0)
      end
    end


    devices_prod_lo = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical',:landscape => ['Indonesia','Bangladesh'])
    devices_nonprod_lo = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Non-Critical',:landscape => ['Indonesia','Bangladesh'])
    opsramp_devices = OpsrampDevice.where(:device_type => ["Server","Linux","Windows","VMware"],:state=>"active").all
    # calculate downtime count
    downtime_month =  OpsrampDeviceDowntime.where(:is_delete => [nil,false]).where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:opsramp_device_id => opsramp_devices).all

    #opsramp_devices = OpsrampDevice.where(:device_type => ["Server","Linux","Windows","VMware"]).all
    @device_downtime_month = OpsrampDeviceDowntime.where(:isremoved=> [nil,false]).where(:is_delete => [nil,false]).where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:opsramp_device_id => opsramp_devices).all
    if @device_downtime_month.count > 0
      non_sap_month = @device_downtime_month.group_by{|down| down[:opsramp_device_id]}.map{|key,value| [key, value.sum{|per| per[:total_downtime].to_i}]}
      downtime_count_month = @device_downtime_month.group_by{|down| down[:opsramp_device_id]}.map{|key,value| {key => value.count}}
      @device_downtime_month = @device_downtime_month.group_by{|down| down[:opsramp_device_id]}
    else
      non_sap_month = []
      downtime_count_month = []
    end
    @opsramp_devices_critical = opsramp_devices.where(:ip_address => devices_prod_lo.pluck(:ip_address)).where(:state=>"active")
    @opsramp_devices_non_critical = opsramp_devices.where(:ip_address => devices_nonprod_lo.pluck(:ip_address)).where(:state=>"active")
    @opsramp_devices_non_critical = @opsramp_devices_non_critical.each do |dev|
      device = devices_nonprod_lo.select{|dec|dec.ip_address.strip == dev.ip_address}.first
      if device.present?
        dev.host_name = device.host_name
        dev.alias_name = device.logical_name
      end
      downtime = non_sap_month.select{|sap| sap[0] == dev.id}
      if downtime.count > 0
        dev.status = ((1 - (downtime[0][1]/@diff.to_f))*100).round(2)
      else
        dev.status = 100.0
      end
    end

    @opsramp_devices_critical.each do |device|
      device1 = devices_prod_lo.select{|dec|dec.ip_address.strip == device.ip_address}.first
      if device1.present?
        device.host_name = device1.host_name
        device.alias_name = device1.logical_name
      end
      bar_data[1]["data"].push(99.99)
      @bar_labels.push(device.host_name)
      downtime = non_sap_month.select{|sap| sap[0] == device.id}
      downtime_count = downtime_month.select{|sap| sap.opsramp_device_id == device.id}
      if downtime.count > 0
        bar_data[0]["data"].push(downtime[0][1])
        bar_data[2]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(2))
        bar_data[3]["data"].push(downtime_count.count)
      else
        bar_data[0]["data"].push(0)
        bar_data[2]["data"].push(100)
        bar_data[3]["data"].push(0)
      end
    end

    @solarwind_systems_non_critical = SolarwindDevice.where(:IsServer => true).where(:DataCenter => 'Sri Lanka').where(:IPAddress => devices_nonprod.pluck(:ip_address)).all
    @solarwind_systems_non_critical = @solarwind_systems_non_critical.each do |solar|
      device = devices_nonprod.select{|dec|dec.ip_address.strip == solar.IPAddress}.first
      if device.present?
        solar.DisplayName = device.host_name
        solar.MachineType = device.logical_name
      end
      downtime = downtime_month_solarwind.select{|sap| sap[0] == solar.NodeID.to_s}
      if downtime.count > 0
        solar.Status = ((1 - downtime[0][1].to_f/@diff)*100).round(2)
      else
        solar.Status = 100.0
      end
    end

    @percentage_data = [bar_data[2]]
    @downtime_data = [bar_data[3]]
    @title = 'System Availability - Sri Lanka,Bangladesh,Indonesia'
    @format = "%"
    @type='system_availability_lanka_bangladesh_indonesia'
    @query_display = {}
    @disabled_months = ['june']
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('system_availability_lanka_bangladesh_indonesia','Landscape')
      end
    end
  end

  def system_performance_sap(month = '')
    @labels = (@month_date..@month_end).map{|d|d}
    @sap_applications = [['ECC',300],['BW',300],['HCM',500],['GRC',500],['FIORI',500]]
    @max_value = [["ECC",0],["BW",0],["HCM",0],["GRC",0],["FIORI",0]]
    @database_average = [["ECC",0],["BW",0],["HCM",0],["GRC",0],["FIORI",0]]
    @average = [["ECC",0],["BW",0],["HCM",0],["GRC",0],["FIORI",0]]
    sap_responses_monthly = SapResponseMonthly.where(:created_month => @month,:created_year => @year).all
    if sap_responses_monthly.count > 0
      @database_average = sap_responses_monthly.map{|s|[s.kpi_name,s.kpi_value,s.remarks,s.kpi_value_system]}
      @average = sap_responses_monthly.map{|s|[s.kpi_name,s.kpi_value_system,s.remarks]}
    end
    if @month_date > "2022-01-01"
      sap_responses = SapResponseDaily.where(:kpi_date => @month_date..@month_end).all
      if sap_responses.count > 0
        sap_responses = sap_responses.group_by{|res| res.kpi_name}.map{|date,val|{date => val.group_by(&:kpi_date).map{|nam,val| {nam.to_s => val[0].kpi_value}}}}
        sap_responses = sap_responses.reduce Hash.new, :merge
        sap_responses = sap_responses.map{|key,value| {key => (value.reduce Hash.new, :merge)}}
        sap_responses = sap_responses.reduce Hash.new, :merge
        @sap_responses = sap_responses.map{|key,vale|{"name" => key,"data" => @labels.map{|lab|(vale.key?(lab) ? vale[lab].split(" ")[0].to_i : 0 )}}}
        @max_value = @sap_responses.map{|res| [res['name'],res['data'].max]}
      else
        @sap_responses = []
      end
    else
      sap_responses = SapResponse.where.not(:kpi_value => '0 ms').where(:kpi_date => @month_date..@month_end).all
      if sap_responses.count > 0
        sap_responses = sap_responses.group_by{|res| res.kpi_name}
        @sap_responses = sap_responses.map{|y,i| [y,i.group_by{|dae| dae.kpi_date}.sort.map{|y,i| [y,(i.sum{|kpi| (kpi.kpi_value.split)[0].to_i})/i.count]}]}
        @sap_responses = @sap_responses.map{|key| { "name" => key[0], "data" => key[1].map{|arr|arr[1]}}}
        if @month_date == '2020-07-01'
          @max_value = [["ECC",537],["BW",319],["HCM",2855],["GRC",243],["FIORI",40]]
        elsif @month_date == '2020-06-01'
          @max_value = [["ECC",574],["BW",1984],["HCM",612],["GRC",139],["FIORI",55]]
        elsif @month_date == '2020-08-01'
          @max_value = [["ECC",644],["BW",1333],["HCM",716],["GRC",859],["FIORI",40]]
        elsif @month_date == '2020-09-01'
          @max_value = [["ECC",534],["BW",12433],["HCM",584],["GRC",303],["FIORI",51]]
        elsif @month_date == '2020-10-01'
          @max_value = [["ECC",504],["BW",1276],["HCM",517],["GRC",364],["FIORI",52]]
        else
          @max_value = @sap_responses.map{|res| [res['name'],res['data'].max]}
        end
      end
    end
    @title = 'Application Performance DINOGUI Response Time'
    @query_display = {}
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all

    @type='system_performance_sap'
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('system_performance_sap','Landscape')
      end
    end
  end

  def system_availability_sap
    @sap_applications = SapApplication.all
    @downtime_devices = []
    downtime_data = [
        { "name" => "downtime" , "data" => []},
        { "name" => "Target SLA" , "data" => [],"type" => 'spline',"marker" => { "lineWidth" => 5,"lineColor" => "#000", "fillColor" => 'white'}},
        { "name" => "Month SLA" , "data" => [],"type" => 'column'},
        { "name" => "Number of Downtime" , "data" => []},
    ]
    if @year.to_s == '2020'
      partial = 'system_availability_sap'
      # Opsramp instance Code
      host_names = ['CI URLMSG Srv URL','CI URLMSG - HBP/BW','CI URLMSG - HRP/HCM','PIP - F5 Loadbalancer URL','ADP URL','FIP CI','GRP CI','BOP URL','SPP ABAP URL']
      sap_devices = SapDevice.where(:host_name => host_names).all
      @sap_downtime_month = SapDowntime.where(:is_delete => [nil,false]).where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:sap_device_id => sap_devices).all
      # calculate downtime count
      downtime_count =  SapDowntime.where(:is_delete => [nil,false]).where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:sap_device_id => sap_devices).where(:isremoved=> [nil,false]).all
      if @sap_downtime_month.count > 0
        sap_month = @sap_downtime_month.where(:isremoved=> [nil,false]).group_by{|down| down[:sap_device_id]}.map{|key,value| [key, value.sum{|per| per[:total_downtime].to_i}]}
        @downtime_data_month = @sap_downtime_month.group_by{|down| down[:sap_device_id]}
      else
        sap_month = []
        @downtime_data_month = []
      end
      @sap_applications.each do |app|
        if app.sla_category == 'gold'
          downtime_data[1]["data"].push(99.99)
        elsif app.sla_category == 'silver'
          downtime_data[1]["data"].push(99.50)
        else
        end

        @downtime_devices.push(app.name)
        downtime = sap_month.select{|sap| app.devices.include? sap[0]}
        count_down = downtime_count.select{|down| app.devices.include? down.sap_device_id }
        if downtime.count > 0
          downtime_data[0]["data"].push(downtime[0][1])
          downtime_data[2]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(2))
          downtime_data[3]["data"].push(count_down.count)
        else
          downtime_data[0]["data"].push(0)
          downtime_data[2]["data"].push(100)
          downtime_data[3]["data"].push(0)
        end
      end
    else

      partial = 'system_availability_sap_solarwinds'
      host_names = ['CI URLMSG Srv URL','CI URLMSG - HBP/BW','CI URLMSG - HRP/HCM','PIP - F5 Loadbalancer URL','ADP URL','FIP CI','GRP CI','BOP URL','SPP ABAP URL']
      @sap_devices = SapDevice.where(:host_name => host_names).all
      componentids = @sap_devices.map{|device| device.component_id}
      @sap_downtime_month = SolarwindComponentDowntime.where(:is_delete => [nil,false]).where(:ComponentID => componentids).where(:created_month => @month,:created_year => @year)

      downtime_count =  SolarwindComponentDowntime.where(:is_delete => [nil,false]).where(:created_month => @month,:created_year => @year).where(:ComponentID => componentids).where(:isremoved=> [nil,false]).all
      if @sap_downtime_month.count > 0
        @downtimes = @sap_downtime_month.group_by{|down| down[:ComponentID]}
        sap_month = @sap_downtime_month.where(:isremoved=> [nil,false]).group_by{|down| down[:ComponentID]}.map{|key,value| [key, value.sum{|per| per[:OutageDurationInSeconds].to_i}]}
        @downtime_data_month = @sap_downtime_month.group_by{|down| down[:ComponentID]}
      else
        sap_month = []
        @downtime_data_month = []
      end

      @sap_applications.each do |app|
        if app.sla_category == 'gold'
          downtime_data[1]["data"].push(99.99)
        elsif app.sla_category == 'silver'
          downtime_data[1]["data"].push(99.50)
        else
        end
        @downtime_devices.push(app.name)
        device = @sap_devices.select{|dev|dev.primary_app == app.name}.first
        downtime = sap_month.select{|sap| device.component_id == sap[0].to_i}
        count_down = downtime_count.select{|down| device.component_id == down.ComponentID }
        if downtime.count > 0
          downtime_data[0]["data"].push(downtime[0][1])
          downtime_data[2]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(2))
          downtime_data[3]["data"].push(count_down.count)
        else
          downtime_data[0]["data"].push(0)
          downtime_data[2]["data"].push(100)
          downtime_data[3]["data"].push(0)
        end
      end
    end
    @downtime_devices

    @percentage_data = [downtime_data[2],downtime_data[1]]
    @downtime_data = [downtime_data[3]]
    @title = 'System Availability ( SAP )'
    @format = "%"
    @query_display = {}
    @disabled_months = []
    @type='system_availability_sap'
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    @is_download = false
    respond_to do |format|
      format.html { render partial}
      format.json do
        @is_download = true
        if @year == '2020'
          save_pdf_file('system_availability_sap','Portrait','system_availability_sap')
        else
          save_pdf_file('system_availability_sap','Portrait','system_availability_sap_solarwinds')
        end
      end
    end
  end

  def system_availability_non_sap
    downtime_data = [{ "name" => "downtime" , "data" => []},{ "name" => "Target SLA" , "data" => [],"type" => 'spline',"marker" => { "lineWidth" => 5,"lineColor" => "#000", "fillColor" => 'white'}},{ "name" => "Month SLA" , "data" => [],"type" => 'column'},{ "name" => "Number of Downtime" , "data" => []},]
    @non_sap_devices = NonSapDevice.where(:device_type => 'prod').all
    @non_sap_applications = NonSapApplication.all
    if @year.to_s == '2020'
      # calculate downtime count
      downtime_count =  NonSapDowntime.where(:is_delete => [nil,false]).where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:non_sap_device_id => @non_sap_devices).where(:isremoved=> [nil,false]).all.group_by{|down| down[:non_sap_device_id]}.sort
      if downtime_count.count > 0
        downtime_count_month = downtime_count.map{|key,value| {key => value.count}}
      else
        downtime_count_month = []
      end
      @non_sap_downtime_month_avail = NonSapDowntime.where(:is_delete => [nil,false]).where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:non_sap_device_id => @non_sap_devices).where(:isremoved=> [nil,false]).all.group_by{|down| down[:non_sap_device_id]}
      @non_sap_downtime_month = NonSapDowntime.includes(:non_sap_device).where("downtime_date BETWEEN ? AND ?",@month_date,@month_end).where(:non_sap_device_id => @non_sap_devices).all.group_by{|down| down[:non_sap_device_id]}.sort
      if @non_sap_downtime_month.count > 0
        non_sap_month = @non_sap_downtime_month_avail.map{|key,value| [key, value.sum{|per| per[:total_downtime].to_i}]}
      else
        non_sap_month = []
      end
      @downtime_devices = []
      @non_sap_devices.each do |device|
        downtime_data[1]["data"].push(99.50)
        @downtime_devices.push(device.host_name)
        downtime = non_sap_month.select{|sap| sap[0] == device.id}
        downtime_count = downtime_count_month.select{|sap| sap.key?device.id}
        if downtime.count > 0
          downtime_data[0]["data"].push(downtime[0][1])
          downtime_data[2]["data"].push(((1 - downtime[0][1].to_f/@diff)*100).round(2))
          downtime_data[3]["data"].push(downtime_count[0][device.id])
        else
          downtime_data[0]["data"].push(0)
          downtime_data[2]["data"].push(100)
          downtime_data[3]["data"].push(0)
        end
      end
      partial = 'system_availability_non_sap_opsramp'
    else
      @critical_devices = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical',:landscape => 'DataCenter').all
      ip_address = @critical_devices.pluck(:ip_address)

      downtime_of_devices = SolarwindDeviceDowntime.where(:is_delete => [nil,false],:created_month => @month,:created_year => @year,:DataCenter => 'Thailand DC',:IPAddress => ip_address)


      @app_data = downtime_of_devices.group_by{|down| down[:NodeID]}
      @critical_systems = SolarwindDevice.where("IPAddress IN (?)",ip_address).all

      # calculate downtime count and total downtime
      if downtime_of_devices.count > 0
        downtime_data_device_count = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|interface| interface.NodeID}.map{|ki,val| {ki.to_i => val.count}}
        downtime_data_device_total = downtime_of_devices.where(:isremoved=> [nil,false]).group_by{|interface| interface.NodeID}.map{|key,value| [key.to_i, value.sum{|per| per[:OutageDurationInSeconds].to_i}]}
      else
        downtime_data_device_count = []
        downtime_data_device_total = []
      end
      # end
      @bar_labels = []
      # raise @app_data.inspect
      @critical_systems.each do |solar|
        @bar_labels.push(solar.NodeName.upcase)
        downtime_month = (downtime_data_device_total.select{|sap| sap[0] == solar.NodeID})[0]
        downtime_count = (downtime_data_device_count.select{|sap| sap.key? solar.NodeID})[0]
        if downtime_month.present?
          downtime_data[2]["data"].push(((1 - downtime_month[1].to_f/@diff)*100).round(3))
        else
          downtime_data[2]["data"].push(100)
        end
        if downtime_count.present?
          downtime_data[3]["data"].push(downtime_count[solar.NodeID])
        else
          downtime_data[3]["data"].push(0)
        end
      end
      partial = 'system_availability_non_sap_solarwind'
    end
    @percentage_data = [downtime_data[2],downtime_data[1]]
    @downtime_data = [downtime_data[3]]

    @title = 'System Availability ( NON - SAP )'
    @format = "%"
    @query_display = {}
    @disabled_months = []
    @type='system_availability_non_sap'
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    @is_download = false
    respond_to do |format|
      format.html { render partial}
      format.json do
        @is_download = true
        if @year == '2020'
          save_pdf_file('system_availability_non_sap','Portrait','system_availability_non_sap_opsramp')
        else
          save_pdf_file('system_availability_non_sap','Portrait','system_availability_non_sap_solarwind')
        end

      end
    end
  end

  def sla_status_report_domain
    start_date = @month_date.to_s + " 00:00:00"
    end_date = @month_end.to_s + " 23:59:59"
    @response_data = {}
    @resolution_data = {}
    @response_ritm_data = {}
    @response_change_data = {}
    @resolution_ritm_data = {}
    @resolution_change_data = {}
    @type='sla_status_report_domain'
    @is_download = false
    @query_display = {
        "Response SLA" => ["Created(task_sys_created_on) At OR After 2020-03-25 00:00:00","SLA Closed(tsla_end_time) BETWEEN #{start_date} AND #{end_date}","Task Type(task_sys_class_name) is Incident OR Requested Item OR Change Request","SLA LIKE Response","INC State(inc_state) OR RITM State(ritm_state) is not Cancelled","Task Stage(tsla_stage) is Completed","Assignment Group(task_assignment_group.grouping) is one of Application OR Infrastructure"],
        "Resolution SLA" => ["Created(task_sys_created_on) At OR After 2020-03-25 00:00:00","Task Closed(task_closed_at) BETWEEN #{start_date} AND #{end_date}","Task Type(task_sys_class_name) is Incident OR Requested Item OR Change Request","SLA LIKE Resolve OR Resolution","INC State(inc_state) OR RITM State(ritm_state) is not Cancelled","Task Stage(tsla_stage) is Completed","Assignment Group(task_assignment_group.grouping) is one of Application OR Infrastructure"]
      }
    @table = 'Incident, RITM, Catalog Task, CHG SLAs(u_incident_request_sla)'

    @groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure'],:active => true).where.not("group_name LIKE '%ruby%'").all
    groups_name = @groups.map{|group| group.group_name}

    @total_data = []

    # response data method

    @overall_response_sla = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",start_date,end_date).where(:task_sys_class_name => "Incident").where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:tsla_stage=>'Completed').where(:pillar => ['Application','Infrastructure']).where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all

    # raise overall_response_sla.count.inspect
    @overall_ritm_response = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ?","Requested Item").where("tsla_sla LIKE ?","%response%").where("task_sys_created_on >= ?","2020-03-25 00:00:00").where(:tsla_stage=>'Completed').where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:pillar => ['Application','Infrastructure']).where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all

    @overall_change_response = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ?","Change Request").where("tsla_sla LIKE ?","%response%").where("task_sys_created_on >= ?","2020-03-25 00:00:00").where(:tsla_stage=>'Completed').where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:pillar => ['Application','Infrastructure']).where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all

    if @overall_response_sla.count > 0
      overall_response_sla = @overall_response_sla.group_by{|sla| sla.task_assignment_group}.map{|y,i| [y ,i.group_by{|sla| sla.task_priority}]}.map{|y,i| [ y,i.map{|key,value| [key, value.count,(value.select{|val| val.tsla_has_breached == true}).count]}]}

      overall_response_sla.each do |sla|
        group = @groups.select{|group| group.group_name == sla[0]}
        if group.count > 0
          workstream = group[0].u_workstream
          unless @response_data[workstream].present?
            @response_data[workstream] = {}
            @response_data[workstream]['P1 Incidents'] = [0,0]
            @response_data[workstream]['P2 Incidents'] = [0,0]
            @response_data[workstream]['P3 Incidents'] = [0,0]
            @response_data[workstream]['P4 Incidents'] = [0,0]
          end
          sla[1].each do |inner_sla|
            if inner_sla[0] == '4 - Low'
              @response_data[workstream]['P4 Incidents'][0] +=  inner_sla[1]
              @response_data[workstream]['P4 Incidents'][1] +=  inner_sla[2]
            elsif inner_sla[0] == '3 - Moderate'
              @response_data[workstream]['P3 Incidents'][0] +=  inner_sla[1]
              @response_data[workstream]['P3 Incidents'][1] +=  inner_sla[2]
            elsif inner_sla[0] == '2 - High'
              @response_data[workstream]['P2 Incidents'][0] +=  inner_sla[1]
              @response_data[workstream]['P2 Incidents'][1] +=  inner_sla[2]
            elsif inner_sla[0] == '1 - Critical'
              @response_data[workstream]['P1 Incidents'][0] +=  inner_sla[1]
              @response_data[workstream]['P1 Incidents'][1] +=  inner_sla[2]
            end
          end
        end
      end
    end

    if @overall_ritm_response.count > 0
      ritm_response_sla = @overall_ritm_response.group_by{|sla| sla.task_assignment_group}.map{|y,i| [ y,i.count,i.select{|val| val.tsla_has_breached == true}.count]}
      ritm_response_sla.each do |sla|
        group = @groups.select{|group| group.group_name == sla[0]}
        if group.count > 0
          workstream = group[0].u_workstream
          unless @response_ritm_data[workstream].present?
            @response_ritm_data[workstream] = [0,0]
          end
            @response_ritm_data[workstream][0] += sla[1]
            @response_ritm_data[workstream][1] += sla[2]
        end
      end
    end

    if @overall_change_response.count > 0
      ritm_response_sla = @overall_change_response.group_by{|sla| sla.task_assignment_group}.map{|y,i| [ y,i.count,i.select{|val| val.tsla_has_breached == true}.count]}
      ritm_response_sla.each do |sla|
        group = @groups.select{|group| group.group_name == sla[0]}
        if group.count > 0
          workstream = group[0].u_workstream
          unless @response_change_data[workstream].present?
            @response_change_data[workstream] = [0,0]
          end
            @response_change_data[workstream][0] += sla[1]
            @response_change_data[workstream][1] += sla[2]
        end
      end
    end
    # end---------------->



    # resolution data method
    @overall_resolution_sla = OverallSlaStatus.where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ?","Incident").where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where(:pillar => ['Application','Infrastructure']).where(:tsla_stage=>'Completed').where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all

    @overall_ritm_resolution = OverallSlaStatus.where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ?","Requested Item").where(:pillar => ['Application','Infrastructure']).where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all

    @overall_change_resolution = OverallSlaStatus.where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ?","Change Request").where(:pillar => ['Application','Infrastructure']).where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all

    if @overall_resolution_sla.count > 0
      overall_resolution_sla = @overall_resolution_sla.group_by{|sla| sla.task_assignment_group}.map{|y,i| [y ,i.group_by{|sla| sla.task_priority}]}.map{|y,i| [y,i.map{|key,value| [key, value.count,(value.select{|val| val.tsla_has_breached == true}).count]}]}

      overall_resolution_sla.each do |sla|
        # raise overall_resolution_sla.inspect
        group = @groups.select{|group| group.group_name == sla[0]}
        if group.count > 0
          workstream = group[0].u_workstream
          unless @resolution_data[workstream].present?
            @resolution_data[workstream] = {}
            @resolution_data[workstream]['P1 Incidents'] = [0,0]
            @resolution_data[workstream]['P2 Incidents'] = [0,0]
            @resolution_data[workstream]['P3 Incidents'] = [0,0]
            @resolution_data[workstream]['P4 Incidents'] = [0,0]
          end
          sla[1].each do |inner_sla|
            if inner_sla[0] == '4 - Low'
              @resolution_data[workstream]['P4 Incidents'][0] +=  inner_sla[1]
              @resolution_data[workstream]['P4 Incidents'][1] +=  inner_sla[2]
            elsif inner_sla[0] == '3 - Moderate'
              @resolution_data[workstream]['P3 Incidents'][0] +=  inner_sla[1]
              @resolution_data[workstream]['P3 Incidents'][1] +=  inner_sla[2]
            elsif inner_sla[0] == '2 - High'
              @resolution_data[workstream]['P2 Incidents'][0] +=  inner_sla[1]
              @resolution_data[workstream]['P2 Incidents'][1] +=  inner_sla[2]
            else
              @resolution_data[workstream]['P1 Incidents'][0] +=  inner_sla[1]
              @resolution_data[workstream]['P1 Incidents'][1] +=  inner_sla[2]
            end
          end
        end
      end
    end
    # end------------------>

    if @overall_ritm_resolution.count > 0
      ritm_resolution_sla =  @overall_ritm_resolution.group_by{|sla| sla.task_assignment_group}.map{|y,i| [ y,i.count,i.select{|val| val.tsla_has_breached == true}.count]}
      ritm_resolution_sla.each do |sla|
        group = @groups.select{|group| group.group_name == sla[0]}
        if group.count > 0
          workstream = group[0].u_workstream
          unless @resolution_ritm_data[workstream].present?
            @resolution_ritm_data[workstream] = [0,0]
          end
            @resolution_ritm_data[workstream][0] += sla[1]
            @resolution_ritm_data[workstream][1] += sla[2]
        end
      end
    end

    if @overall_change_resolution.count > 0
      ritm_resolution_sla = @overall_change_resolution.group_by{|sla| sla.task_assignment_group}.map{|y,i| [ y,i.count,i.select{|val| val.tsla_has_breached == true}.count]}
      ritm_resolution_sla.each do |sla|
        group = @groups.select{|group| group.group_name == sla[0]}
        if group.count > 0
          workstream = group[0].u_workstream
          unless @resolution_change_data[workstream].present?
            @resolution_change_data[workstream] = [0,0]
          end
            @resolution_change_data[workstream][0] += sla[1]
            @resolution_change_data[workstream][1] += sla[2]
        end
      end
    end
    @query = {'query_string' => {'report_method' => 'sla','month' => @month+'-'+@year.to_s,'query_paramterers' => {}}}
    @title = 'Overall SLA Performance - Domain Wise'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month, :created_year => @year).all
    @is_download = false
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('sla_status_report_domain','Landscape')
      end
    end
  end

  def csat_report
    @is_download = false
    start_date = @month_date.to_s + " 00:00:00"
    end_date = @month_end.to_s + " 23:59:59"
    @type='csat_report'
    @query_display = {
      "Total Assessments" => [
          "Created On(sys_created_on) BETWEEN #{start_date} AND #{end_date}",
          "Created On(sys_created_on) At or After 2020-03-25 00:00:00",
          "Metric Type is Satisfaction Survey",
          "Task Type is Incident OR Task Type is Requested Item",
          "Grouping is one of Application OR Infrastructure" ],
      "Received Assessments" => [
          "Taken On (taken_on) BETWEEN #{start_date} AND #{end_date}",
          "Created On(sys_created_on) At or After 2020-03-25 00:00:00",
          "Metric Type is Satisfaction Survey",
          "Task Type is Incident OR Task Type is Requested Item",
          "State(state) is Complete",
          "Grouping is one of Application OR Infrastructure"],
      "CSAT Score" => [
          "Actual Value (mr_actual_value) is not -1 OR 6",
          "Taken On (taken_on) BETWEEN #{start_date} AND #{end_date}",
          "Grouping is one of Application and Infrastructure",
          "Task Type is Incident OR Task Type is Requested Item",
          "Metric Question Starts With : Please Give",
          "Metric Type is Satisfaction Survey"
          ]
    }
    @CSAT_Random_call = ServicenowFeedback.where.not("assignment_group LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').where("call_date BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:feedback_updated => true).group(:workstream).group(:call_successful).count
    # @CSAT_Random_call = {["BI&BPC", "no"]=>1, ["BI&BPC", "yes"]=>7, ["GRC & Authorization", "no"]=>31, ["GRC & Authorization", "yes"]=>95, ["Non-SAP", "no"]=>42, ["Non-SAP", "yes"]=>45, ["SAP", "no"]=>49, ["SAP", "yes"]=>148}

    @groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).all
    @table = 'Assessment(asmt_assessment_instance) and INDG Survey Reports(u_indg_survey_report)'
    @total_assesments = Assessment.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).where.not("assignment_group LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').where(:pillar => ['Application','Infrastructure']).group(:assignment_group).count
    all_received_assessments = Assessment.where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure'],:state => 'Complete').where.not("assignment_group LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').all
    @this_month_assessments = all_received_assessments.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
    @last_month_assessments = all_received_assessments.where.not("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
    @received_assesments = all_received_assessments.count
    @csat_score = CustomerSatisfactionScore.where.not("mr_actual_value = ? OR mr_actual_value = ? ","-1","6").where("ai_taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where.not("ai_related_id_1 LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').all

    if @csat_score.count > 0
      @total_score = @csat_score.group_by{|sla| sla.mr_actual_value}.map{|y,i| {y => [i.count,(y.to_i*i.count)]}}
      @overall_csat_score = @csat_score.group_by{|sla| sla.ai_related_id_1}.map{|y,i| [y.remove("Group: ") ,i.group_by{|sla| sla.mr_actual_value}]}.map{|y,i| [ y,i.map{|key,value| {key => value.count}}]}
      group_wise = @csat_score.group_by{|sla| sla.ai_related_id_1}.map{|y,i| [y.remove("Group: "),i.count]}
    end
    @survey_sent = @total_assesments
    workstream_hash_send = Assessment.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where.not("assignment_group LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').group(:workstream).count.sort
    workstream_hash_received = @csat_score.group(:workstream).count.sort

    @labels = workstream_hash_send.map{|val| val[0]}
    @data_set =  [{"name" => "Survey Sent","data" => workstream_hash_send.map{|val| val[1]}},{"name" => "Survey Received","data" => workstream_hash_received.map{|val| val[1]}}]
    @title = 'Customer Satisfaction Survey'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    # raise @remarks.inspect
    @query = {'query_string' => {'report_method' => 'csat','month' => @month+'-'+@year.to_s,'query_paramterers' => {}}}
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('csat_report','Landscape')
      end
    end
  end

  def first_call_resolution
    start_date = @month_date.to_s + " 00:00:00"
    end_date = @month_end.to_s + " 23:59:59"
    @query_display = {
      "Tickets Received" => ["Created On (sys_created_on) BETWEEN #{start_date} AND #{end_date}","Indg Service Desk Counter is 1","Assignment Group (assignment_group.grouping) is one of Application or Infrastructure"],
      "Tickets Closed" => ["Created On (sys_created_on) BETWEEN #{start_date} AND #{end_date}","State (incident_state) is one of Resolved or Closed","Reassignment Count is 0","Assignment Group (assignment_group) LIKE Service Desk"]
    }
    @table = 'Incident (incident)'
    @groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).all
    groups_name = @groups.map{|group| group.group_name}
    @all_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',start_date,end_date).where(:u_indg_service_desk_counter=> '1').where(:assignment_group => groups_name).all
    @closed_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',start_date,end_date).where(:incident_state => ['Resolved','Closed']).where(:reassignment_count => 0).where("assignment_group LIKE ?","%SERVICE DESK%").all
    @query = {'query_string' => {'report_method' => 'fcr','month' => @month+'-'+@year.to_s,'query_paramterers' => {}}}
    @title = 'INDG Service Desk Tickets'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    @is_download = false
    @type = 'first_call_resolution'
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('first_call_resolution','Landscape')
      end
    end
  end

  def incidents_ageing
    @type='incidents_ageing'
    @query_display = { "Open incidents" => ["Incident State(incident_state) is not one of Resolved,Closed and Cancelled","Created on (sys_created_on) is at or after 2020-03-25 00:00:00","Assignment Group (assignment_group.grouping) is one of Application or Infrastructure"]}
    @table = 'Incident (incident)'
    incidents = IncidentAgeingTicket.where(:created_month => @month).all
    @groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).all
    @data_hash = {}
    @workstream_hash = {}
    @total = {"<1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @groups.each do |group|
      @data_hash[group.group_name] = {"workstream" => group.u_workstream,"<1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @workstream_hash[group.u_workstream] = {"<1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    end
    groups = @groups.map{|group| group.group_name}
    @incidents = incidents.select{|inc| groups.include?(inc.assignment_group)}
    inc_state_hash = []
    if @incidents.count > 0
      @incidents.each do |sla|
        if sla.assignment_group.present? && sla.assignment_group != ''
          group = sla.assignment_group
          workstream = sla.workstream
          diff = ((Time.parse(sla.created_date + " 00:00:00 UTC") - sla.sys_created_on.to_time)/86400.0).round(2)
          if @data_hash[group].present?
            if diff >= 0.0 && diff < 7.0
              @data_hash[group]["<1 day to 7 days"] += 1
              @workstream_hash[workstream]["<1 day to 7 days"] += 1
              @total["<1 day to 7 days"] += 1
            elsif diff >= 7.0 && diff < 15.0
              @data_hash[group]["7 to 15 days"] += 1
              @total["7 to 15 days"] += 1
              @workstream_hash[workstream]["7 to 15 days"] += 1
            elsif diff >= 15.0 && diff < 30.0
              @data_hash[group]["15 to 30 days"] += 1
              @total["15 to 30 days"] += 1
              @workstream_hash[workstream]["15 to 30 days"] += 1
            elsif diff >= 30.0
              inc_state_hash.push(sla)
              @data_hash[group][">30 days"] += 1
              @total[">30 days"] += 1
              @workstream_hash[workstream][">30 days"] += 1
            end
          end
        end
      end
    end
    inc_state_hash = inc_state_hash.group_by{|inc|inc.incident_state}.map{|y,i| [y,i.count]}
    @state_labels = inc_state_hash.map{|inc_s| inc_s[0]}
    @statedata = [{
      "name" => "Tickets",
      "data" => inc_state_hash.map{|inc_s| inc_s[1]}
    }]
    # @statedata = inc_state_hash.map{|inc| {"name" => inc[0],"y" => inc[1]}}
    @labels = @workstream_hash.map{|workstream,value| workstream}
    @age_labels = ["<1 day to 7 days","7 to 15 days","15 to 30 days",">30 days"]
    @piedata = [{
      "name" => "Tickets",
      "data" => @total.values,
      "colorByPoint" => true
    }]
    @labels = @workstream_hash.map{|workstream,value| workstream}
    barchart_labels = (@workstream_hash.map{|workstream,value| value.keys })[0]
    barchart_data = @workstream_hash.map{|workstream,value| value.values }
    @bar_data = []
    barchart_labels.each_with_index do |data,index|
       @bar_data.push({"name" => barchart_labels[index], "data" => barchart_data.map{|data| data[index]}})
    end
    @title = 'Incident Ageing'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month).all
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        html = render_to_string(:action => 'incidents_ageing.html.erb',:layout => "pdf_layout")
        pdf = WickedPdf.new.pdf_from_string(html,javascript_delay: 5000, orientation: 'landscape')
        send_data pdf, :filename => "incidents_ageing.pdf", :disposition => 'inline'
      end
    end
  end

  def patch_management_status
    @last_three_months = ['june-2020','july-2020','august-2020']
    @year = '2020'
    if @month == 'august' && @year.to_s == '2020'
      @month = 'august'
    else
      @month = 'july'
    end
    @local_data = LocalPatchManagement.where(:month => @month,:created_year => @year)
    @local_labels = @local_data.map{|grp| grp.devices }
    @local_barchart_data =  [
      {"name" => "update" , "data" => @local_data.map{|grp| grp.u_green.to_i }},
      {"name" => "update pending" , "data" => @local_data.map{|grp| (grp.u_red.to_i + grp.u_amber.to_i)}}
    ]
    @dc_data = DcPatchManagement.where(:month => @month,:created_year => @year)
    @dc_labels = @dc_data.map{|grp| grp.devices }
    @dc_barchart_data =  [
      {"name" => "update" , "data" => @dc_data.map{|grp| grp.u_green.to_i }},
      {"name" => "update pending" , "data" => @dc_data.map{|grp| (grp.u_red.to_i + grp.u_amber.to_i)}}
    ]
    @colors = ['#2eb85a','#fdbc02']
    @title = 'Patch Management Status'
    @disabled_months = ['june']
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    @query_display = {}
    @is_download = false
    @type = 'patch_management_status'
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('patch_management_status', 'Landscape')
      end
    end
  end

  def patch_management_status_new
    patch_data = Admin::PatchManagement.where(:month => @month,:created_year => @year).all
    @labels_country = []
    @countrys = {'Thailand' => 'TH','Vietnam' => 'VN','SriLanka' => 'LK','Thailand' => 'TH','Bangladesh' => 'BD','Indonesia' => 'ID'}
    @data_country = {}
    if patch_data.count > 0
      @countrys.each do |name,code|
        @data_country[name] = {}
        data = patch_data.select{|da| da.device.include?(code)}
        data.each do |ds|
          device = ds.device.split("-")[0].strip()
          @data_country[name][device] = {"update" => ds.update_devices.to_i,"update pending" => ds.update_pending_devices.to_i,"end of life" => ds.end_of_life.to_i,}
          (!@labels_country.include?(device)) ? @labels_country.push(device) : ''
        end
      end

      # thailand_data =
      vietnam_data = patch_data.select{|da| da.device.include?('VN')}
      lanka_data = patch_data.select{|da| da.device.include?('LK')}
      bangladesh_data = patch_data.select{|da| da.device.include?('BD')}
      indonesia_data = patch_data.select{|da| da.device.include?('ID')}

    else
      @data_country = {"Thailand" => {"MS Servers"=>{"update"=>0, "update pending"=>0,"end of life"=>0}}}
    end
    @dc_data = DcPatchManagement.where(:month => @month,:created_year => @year)
    @dc_labels = @dc_data.map{|grp| grp.devices }
    @dc_barchart_data =  [
        {"name" => "Updated" , "data" => @dc_data.map{|grp| grp.u_green.to_i }},
        {"name" => "Update Pending" , "data" => @dc_data.map{|grp| grp.u_amber.to_i }},
        {"name" => "End of Life" , "data" => @dc_data.map{|grp| grp.u_red.to_i }},
        {"name" => "Behind 5 Patch" , "data" => @dc_data.map{|grp| grp.behind_patch.to_i }},
        # {"name" => "update pending" , "data" => @dc_data.map{|grp| (grp.u_red.to_i + grp.u_amber.to_i)}}
    ]
    @colors = ['#2eb85a','#fdbc02','red','#007bff']
    @title = 'Patch Management Status New'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title, :created_month => @month,:created_year => @year).all
    @query_display = {}
    @labels_country = ['MS Servers','Linux Servers','Virtual Hosts / Others',"Database", "Non_SQL Database",'Network' ]
    @is_download = false
    @type = 'patch_management_status_new'
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('patch_management_status_new')
      end
    end
  end

  def requests_ageing
    @query_display = { "Open Requests" => ["Request State(state) is not one of Pending Approval,Closed,Completed and Cancelled","Created on (sys_created_on) is at or after 2020-03-25 00:00:00","Assignment Group (assignment_group.grouping) is one of Application or Infrastructure"]}
    @table = 'Request Item (sc_req_item)'
    @groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where.not(:u_workstream => nil).where(:active => true).all
    @data_hash = {}
    @workstream_hash = {}
    @total = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @groups.each do |group|
      @data_hash[group.group_name] = {"workstream" => group.u_workstream,"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @workstream_hash[group.u_workstream] = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    end
    groups = @groups.map{|group| group.group_name}
    @service_request_items = ServiceRequestAgeingTicket.where(:created_month => @month).all
    inc_state_hash = []
    if @service_request_items.count > 0
      @service_request_items.each do |sla|
        if sla.assignment_group.present? && sla.assignment_group != ''
          group = sla.assignment_group
          workstream =sla.workstream
          diff = ((Time.parse(sla.created_date + " 23:59:59 UTC") - sla.sys_created_on.to_time)/86400.0).round(1)
          if @data_hash[group].present?
            if diff >= 0.0 && diff <= 7.0
              @data_hash[group]["> 1 day to 7 days"] += 1
              @workstream_hash[workstream]["> 1 day to 7 days"] += 1
              @total["> 1 day to 7 days"] += 1
            elsif diff > 7.0 && diff <= 15.0
              @data_hash[group]["7 to 15 days"] += 1
              @total["7 to 15 days"] += 1
              @workstream_hash[workstream]["7 to 15 days"] += 1
            elsif diff > 15.0 && diff <= 30.0
              @data_hash[group]["15 to 30 days"] += 1
              @total["15 to 30 days"] += 1
              @workstream_hash[workstream]["15 to 30 days"] += 1
            elsif diff > 30.0
              inc_state_hash.push(sla)
              @data_hash[group][">30 days"] += 1
              @total[">30 days"] += 1
              @workstream_hash[workstream][">30 days"] += 1
            end
          end
        end
      end
    end
    inc_state_hash = inc_state_hash.group_by{|inc|inc.state}.map{|y,i| [y,i.count]}
    @state_labels = inc_state_hash.map{|inc_s| inc_s[0]}
    @statedata = [{
      "name" => "Tickets",
      "data" => inc_state_hash.map{|inc_s| inc_s[1]}
    }]
    # @statedata = inc_state_hash.map{|inc| {"name" => inc[0],"y" => inc[1]}}
    @labels = @workstream_hash.map{|workstream,value| workstream}
    @age_labels = ["<1 day to 7 days","7 to 15 days","15 to 30 days",">30 days"]
    @piedata = [{
      "name" => "Tickets",
      "data" => @total.values,
      "colorByPoint" => true
    }]
    @labels = @workstream_hash.map{|workstream,value| workstream}
    barchart_labels = (@workstream_hash.map{|workstream,value| value.keys })[0]

    barchart_data = @workstream_hash.map{|workstream,value| value.values }
    @bar_data = []
    barchart_labels.each_with_index do |data,index|
       @bar_data.push({"name" => barchart_labels[index], "data" => barchart_data.map{|data| data[index]}})
    end
    @title = 'Service Request Ageing'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month).all
  end

  def tickets_ageing
    @query_display = { "Open incidents" => ["Incident State(incident_state) is not one of Resolved,Closed and Cancelled","Created on (sys_created_on) is at or after 2020-03-25 00:00:00","Assignment Group (assignment_group.grouping) is one of Application or Infrastructure"],"Open Requests" => ["Request State(state) is not one of Pending Approval,Closed,Completed and Cancelled","Created on (sys_created_on) is at or after 2020-03-25 00:00:00","Assignment Group (assignment_group.grouping) is one of Application or Infrastructure"]}
    @table = 'Incident (incident) AND Request Item (sc_req_item)'
    @data_hash_req = {}
    @workstream_hash_req = {}
    @data_hash_inc = {}
    @workstream_hash_inc = {}
    @req_total = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @inc_total = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}

    @groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where.not(:u_workstream => nil).where(:active => true).all
    @groups.each do |group|
      @data_hash_req[group.group_name] = {"workstream" => group.u_workstream,"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
      @workstream_hash_req[group.u_workstream] = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
      @data_hash_inc[group.group_name] = {"workstream" => group.u_workstream,"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
      @workstream_hash_inc[group.u_workstream] = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    end
    groups = @groups.map{|group| group.group_name}
    # service requests
    @service_request_items = ServiceRequestAgeingTicket.where.not(:assigned_company => ['INSEE DIGITAL','FreeWill Solotions','Orangemantra','','Siam City Cement (Lanka)'],:assignment_group => ['OMG Application (INSEE Plus)','OMG Application (P2P RPA)']).where(:created_month => @month,:created_year => @year).all

    req_state_hash = []
    if @service_request_items.count > 0
      @service_request_items.each do |sla|
        if sla.assignment_group.present? && sla.assignment_group != ''
          group = sla.assignment_group
          group_workstream = (@groups.select{|gro| gro.group_name == group})[0]
          if group_workstream.present? && group_workstream.u_workstream.present?
            workstream = group_workstream.u_workstream
            unless sla.u_fulfillment_start_time_stamp.nil?
            	diff = ((Time.parse(sla.created_date + " 23:59:59 UTC") - sla.u_fulfillment_start_time_stamp.to_time)/86400.0).round(1)
            else
                diff = 0.0
            end
	    if @data_hash_req[group].present?
              if diff >= 0.0 && diff <= 7.0
                @data_hash_req[group]["> 1 day to 7 days"] += 1
                @workstream_hash_req[workstream]["> 1 day to 7 days"] += 1
                @req_total["> 1 day to 7 days"] += 1
              elsif diff > 7.0 && diff <= 15.0
                @data_hash_req[group]["7 to 15 days"] += 1
                @req_total["7 to 15 days"] += 1
                @workstream_hash_req[workstream]["7 to 15 days"] += 1
              elsif diff > 15.0 && diff <= 30.0
                @data_hash_req[group]["15 to 30 days"] += 1
                @req_total["15 to 30 days"] += 1
                @workstream_hash_req[workstream]["15 to 30 days"] += 1
              elsif diff > 30.0
                req_state_hash.push(sla)
                @data_hash_req[group][">30 days"] += 1
                @req_total[">30 days"] += 1
                @workstream_hash_req[workstream][">30 days"] += 1
              end
            end
          end
        end
      end
    end

    #incidents
    @incidents = IncidentAgeingTicket.where.not(:assigned_company => ['','INSEE DIGITAL','FreeWill Solotions','Orangemantra','Siam City Cement (Lanka)'],:assignment_group => ['OMG Application (INSEE Plus)','OMG Application (P2P RPA)']).where(:created_month => @month,:created_year => @year).all
    inc_state_hash = []
    if @incidents.count > 0
      @incidents.each do |sla|
        if sla.assignment_group.present? && sla.assignment_group != ''
          group = sla.assignment_group
          group_workstream = (@groups.select{|gro| gro.group_name == group})[0]
          if group_workstream.present? && group_workstream.u_workstream.present?
            workstream = group_workstream.u_workstream
            diff = ((Time.parse(sla.created_date + " 23:59:59 UTC") - sla.sys_created_on.to_time)/86400.0).round(2)
            if @data_hash_inc[group].present?
              if diff >= 0.0 && diff < 7.0
                @data_hash_inc[group]["> 1 day to 7 days"] += 1
                @workstream_hash_inc[workstream]["> 1 day to 7 days"] += 1
                @inc_total["> 1 day to 7 days"] += 1
              elsif diff >= 7.0 && diff < 15.0
                @data_hash_inc[group]["7 to 15 days"] += 1
                @inc_total["7 to 15 days"] += 1
                @workstream_hash_inc[workstream]["7 to 15 days"] += 1
              elsif diff >= 15.0 && diff < 30.0
                @data_hash_inc[group]["15 to 30 days"] += 1
                @inc_total["15 to 30 days"] += 1
                @workstream_hash_inc[workstream]["15 to 30 days"] += 1
              elsif diff >= 30.0
                inc_state_hash.push(sla)
                @data_hash_inc[group][">30 days"] += 1
                @inc_total[">30 days"] += 1
                @workstream_hash_inc[workstream][">30 days"] += 1
              end
            end
          end
        end
      end
    end
    #inc charts data ------------------------------------------------------------->

    @inc_30 = inc_state_hash
    inc_state_hash = inc_state_hash.group_by{|inc|inc.incident_state}.map{|y,i| [y,i.count]}
    @inc_state_labels = inc_state_hash.map{|inc_s| inc_s[0]}
    @inc_statedata = [{
                      "name" => "Tickets",
                      "data" => inc_state_hash.map{|inc_s| inc_s[1]}
                  }]
    # @statedata = inc_state_hash.map{|inc| {"name" => inc[0],"y" => inc[1]}}
    @inc_labels = @workstream_hash_inc.map{|workstream,value| workstream}
    @inc_age_labels = ["<1 day to 7 days","7 to 15 days","15 to 30 days",">30 days"]

    inc_barchart_labels = (@workstream_hash_inc.map{|workstream,value| value.keys })[0]
    inc_barchart_data = @workstream_hash_inc.map{|workstream,value| value.values }

    @inc_piedata = [{
                    "name" => "Tickets",
                    "data" => @inc_total.values,
                    "colorByPoint" => true
                }]

        @inc_bar_data = []
    inc_barchart_labels.each_with_index do |data,index|
      @inc_bar_data.push({"name" => inc_barchart_labels[index], "data" => inc_barchart_data.map{|data| data[index]}})
    end
    #----------------------END------------------------------------------------------->


    #req charts data ------------------------------------------------------------->
    @req_30 = req_state_hash
    req_state_hash = req_state_hash.group_by{|inc|inc.state}.map{|y,i| [y,i.count]}

    @req_state_labels = req_state_hash.map{|inc_s| inc_s[0]}
    @req_statedata = [{
                          "name" => "Tickets",
                          "data" => req_state_hash.map{|inc_s| inc_s[1]}
                      }]
    @req_labels = @workstream_hash_req.map{|workstream,value| workstream}
    @req_age_labels = ["<1 day to 7 days","7 to 15 days","15 to 30 days",">30 days"]

    req_barchart_labels = (@workstream_hash_req.map{|workstream,value| value.keys })[0]
    req_barchart_data = @workstream_hash_req.map{|workstream,value| value.values }
    @req_bar_data = []
    req_barchart_labels.each_with_index do |data,index|
      @req_bar_data.push({"name" => req_barchart_labels[index], "data" => req_barchart_data.map{|data| data[index]}})
    end

    @req_piedata = [{
                    "name" => "Tickets",
                    "data" => @req_total.values,
                    "colorByPoint" => true
                }]
    #----------------------END------------------------------------------------------->

    @title = 'Tickets Ageing'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    @pie_total_data = [{:name => '> 1 day to 7 days',:y => @req_total['> 1 day to 7 days'] + @inc_total['> 1 day to 7 days'] },{:name => '7 to 15 days',:y => @req_total['7 to 15 days'] + @inc_total['7 to 15 days'] },{:name => '15 to 30 days',:y => @req_total['15 to 30 days'] + @inc_total['15 to 30 days'] },{:name => '>30 days',:y => @req_total['>30 days'] + @inc_total['>30 days'] }]
    @is_download = false
    @type = 'tickets_ageing'
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('tickets_ageing')
      end
    end
  end

  def backup_reports
    @query_display = {}
    @title = 'Backup Report'
    @disabled_months = []
    @remarks = RemarksModule.where(:report_name => @title,:created_month=>@month,:created_year => @year).all
    @admin_backup_reports = Admin::BackupReport.where(:month => @month,:created_year => @year).all
    @is_download = false
    @type = 'backup_reports'
    respond_to do |format|
      format.html { }
      format.json do
        @is_download = true
        save_pdf_file('backup_reports','Landscape')
      end
    end
  end

  def get_data_json
    groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).map{|group| group.group_name}
    start_date = @month_date.to_s + " 00:00:00"
    end_date = @month_end.to_s + " 23:59:59"

    if params[:query_string].present? && params[:query_string] != ''
      report_method = params[:query_string][:report_method]
      case report_method

      when 'fcr'
        total_data = Incident.where('sys_created_on BETWEEN ? AND ?',start_date,end_date).where(:incident_state => ['Resolved','Closed']).where(:reassignment_count => 0).where("assignment_group LIKE ?","%SERVICE DESK%").all
        total_count = total_data.count
        table_data = total_data.datatable_filter(params['search']['value'], params['columns'])
        lines_filtered = table_data.count
        table_data = table_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        table_data = table_data.offset(params['start'].to_i).limit(params['length'])
        table_data = table_data.each{|inc| inc.number = "<a href='https://scccpcl.service-now.com/incident.do?sys_id=#{inc.sys_id}' target='_blank'>#{inc.number}</a>"}
      when 'surveythismonth'
        all_received_assessments = Assessment.where.not("assignment_group LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:state=>'Complete').all
        getting_data = all_received_assessments.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['sys_created_on'] = inc['sys_created_on'].strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['taken_on'].present?) ? inc['taken_on'] = inc['taken_on'].strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      when 'surveylastmonth'
        all_received_assessments = Assessment.where.not("assignment_group LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:state=>'Complete').all
        getting_data = all_received_assessments.where.not("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['sys_created_on'] = inc['sys_created_on'].strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['taken_on'].present?) ? inc['taken_on'] = inc['taken_on'].strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      when 'assessment'
        getting_data = Assessment.where.not("assignment_group LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').where("sys_created_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['sys_created_on'] = inc['sys_created_on'].strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['taken_on'].present?) ? inc['taken_on'] = inc['taken_on'].strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      when 'csatreceived'
        getting_data = CustomerSatisfactionScore.where.not("mr_actual_value = ? OR mr_actual_value = ? ","-1","6").where.not("ai_related_id_1 LIKE ? OR ?",'%RUBY%','%OMG Application (P2P RPA)%').where("ai_taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['ai_created_on'] = inc['ai_created_on'].to_time.strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['ai_taken_on'].present?) ? inc['ai_taken_on'] = inc['ai_taken_on'].to_time.strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      when 'sla'
        total_response = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ? ","Incident","Requested Item","Change Request").where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:tsla_stage=>'Completed').where(:pillar => ['Application','Infrastructure']).where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all
        total_resolution = OverallSlaStatus.where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:pillar => ['Application','Infrastructure']).where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all
        total_count = total_response.count + total_resolution.count
        total_data = total_response.or(total_resolution)
        table_data = total_data.datatable_filter(params['search']['value'], params['columns'])
        lines_filtered = table_data.count
        table_data = table_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])

        table_data = table_data.offset(params['start'].to_i).limit(params['length'])
        table_data = table_data.each do |inc|
            if inc.task_number.start_with?('INC')
              inc.task_number = "<a href='https://scccpcl.service-now.com/incident.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            elsif inc.task_number.start_with?('RITM')
              inc.task_number = "<a href='https://scccpcl.service-now.com/sc_req_item.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            else
              inc.task_number = "<a href='https://scccpcl.service-now.com/change_request.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            end
          end
      end
      render json: { table_data: table_data,draw: params['draw'].to_i,recordsTotal: total_count,recordsFiltered: lines_filtered}
    else
      render json: {}
    end
  end

  def set_remarks
    isremove = ''
    if params.present?
      if (params[:optionsRadios].downcase == 'planned') || (params[:optionsRadios].downcase == 'false')
        isremove = true
      else
        isremove = false
      end

      if params[:downtime_type] == 'non_sap_downtime'
        NonSapDowntime.find(params[:downtime_id]).update(:remark => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'sap_downtime'
        SapDowntime.find(params[:downtime_id]).update(:remark => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'sap_downtime_solarwind'
        SolarwindComponentDowntime.find(params[:downtime_id]).update(:remarks => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'opsramp_device_downtime'
        OpsrampDeviceDowntime.find(params[:downtime_id]).update(:remark => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'solarwind_interface'
        SolarwindInterfaceDowntime.find(params[:downtime_id]).update(:remarks => params[:remarks],:isremoved => isremove)
      elsif params[:downtime_type] == 'solarwind_device'
        SolarwindDeviceDowntime.find(params[:downtime_id]).update(:remarks => params[:remarks],:isremoved => isremove)
      else
        return true
      end
      return true
    else
      return true
    end
  end

  def set_extra_remarks
    if params.present?
      if params[:report_name].present?
        @dashboard = RemarksModule.new(:report_name => params[:report_name],:remarks=> params[:remarks],:created_date => Time.current.strftime("%Y-%m-%d"),:created_month=>params[:created_month],:created_year=>params[:created_year])
        @dashboard.save
      else
      end
      return true
    else
      return false
    end
  end

  def remove_extra_remarks
    if params.present?
      if params[:id].present?
        remark = RemarksModule.where(:id => params[:id]).first
        if remark.present?
         remark.delete
        end
      end
    end
  end

  def remove_downtime
    if params.present?
      if params[:downtime_type] == 'non_sap_downtime'
        downtime = NonSapDowntime.find(params[:id])
      elsif params[:downtime_type] == 'sap_downtime'
        downtime = SapDowntime.find(params[:id])
      elsif params[:downtime_type] == 'sap_downtime_solarwind'
        downtime = SolarwindComponentDowntime.find(params[:id])
      elsif params[:downtime_type] == 'opsramp_device_downtime'
        downtime = OpsrampDeviceDowntime.find(params[:id])
      elsif params[:downtime_type] == 'solarwind_interface'
        downtime = SolarwindInterfaceDowntime.find(params[:id])
      elsif params[:downtime_type] == 'solarwind_device'
        downtime = SolarwindDeviceDowntime.find(params[:id])
      else
        return true
      end
      if downtime.is_delete
        downtime.update(:is_delete => false)
      else
        downtime.update(:is_delete => true)
      end
      return true
    else
      return true
    end
  end

  def export_data_excel
    groups_niit = ServicenowGroup.where.not(:u_workstream => nil).where(:u_group_type => ['Application','Infrastructure']).where(:active => true).map{|group| "Group: "+group.group_name}
    start_date = @month_date.to_s + " 00:00:00"
    end_date = @month_end.to_s + " 23:59:59"
    if params[:record_type].present? && params[:record_type] != ''
      case params[:record_type]
      when 'sla_overall'
        overall_response_sla = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ? ","Incident","Requested Item","Change Request").where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:tsla_stage=>'Completed').where(:pillar => ['Application','Infrastructure']).where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all
        overall_resolution_sla = OverallSlaStatus.where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:pillar => ['Application','Infrastructure']).where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE '%ruby%' OR task_assignment_group = 'OMG Application (P2P RPA)'").all
        @fields = OverallSlaStatus.column_names
        @sheets = {'Response Data' => overall_response_sla,'Resolution Data'=>overall_resolution_sla}
        @header = OverallSlaStatus.column_names
        @name = "SLA"
      when 'csatreceived'
        csat_score = CustomerSatisfactionScore.where.not("ai_related_id_1 LIKE ?",'%RUBY%').where.not("mr_actual_value = ? OR mr_actual_value = ? ","-1","6").where("ai_taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where.not("ai_related_id_1 = 'Group: OMG Application (P2P RPA)'").all
        assessments = Assessment.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        @fields = CustomerSatisfactionScore.column_names
        @sheets = {'CSAT Score' => csat_score}
        @header = CustomerSatisfactionScore.column_names
        @name = "Customer Satisfaction Score"
      when 'assessmentsent'
        assessment = Assessment.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).where.not("assignment_group LIKE ?",'%RUBY%').where(:pillar => ['Application','Infrastructure']).where.not("assignment_group = 'OMG Application (P2P RPA)'").all
        @fields = Assessment.column_names
        @sheets = {'Assessments' => assessment}
        @header = Assessment.column_names
        @name = "Surveys Sent"
      when 'surveyreceivedcurrent'
        assessment = Assessment.where.not("assignment_group LIKE ?",'%RUBY%').where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:state=>'Complete').where.not("assignment_group = 'OMG Application (P2P RPA)'").all
        assessment = assessment.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        @fields = Assessment.column_names
        @sheets = {'Assessments' => assessment}
        @header = Assessment.column_names
        @name = "Surveys Received Current Month"
      when 'surveyreceivedprevious'
        assessment = Assessment.where.not("assignment_group LIKE ?",'%RUBY%').where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:state=>'Complete').where.not("assignment_group = 'OMG Application (P2P RPA)'").all
        assessment = assessment.where.not("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        @fields = Assessment.column_names
        @sheets = {'Assessments' => assessment}
        @header = Assessment.column_names
        @name = "Surveys Received Previous Month"
      when 'assessment_received'
        assessment = Assessment.where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:state=>'Complete').where.not("assignment_group = 'OMG Application (P2P RPA)'").all
        @fields = Assessment.column_names
        @sheets = {'Assessments' => assessment}
        @header = Assessment.column_names
        @name = "Customer Satisfaction Score"
      when 'P1 Tickets'
        all_tickets = Incident.where(:incident_state => ['Closed','Resolved','Cancelled']).where(:priority => "1 - Critical").all
        @fields = ['number','category','subcategory','caller_id','assignment_group','assigned_to','incident_state','sys_created_on']
        @sheets = {'Last 3 Month Data' => all_tickets}
        @header = ['Number','Category','Sub Category','Raised By','Assignment Group','Assigned To','State','Created On']
        @name = "P1 Tickets"
      when 'fcr'
        all_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',start_date,end_date).where(:u_indg_service_desk_counter=> '1').where(:assignment_group => @groups_niit).all
        closed_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',start_date,end_date).where(:incident_state => ['Resolved','Closed']).where(:reassignment_count => 0).where("assignment_group LIKE ?","%SERVICE DESK%").all
        @fields = ['number','category','subcategory','caller_id','assignment_group','assigned_to','incident_state','sys_created_on']
        @sheets = {'Tickets Assigned' => all_tickets,'Tickets Closed' => closed_tickets}
        @header = ['Number','Category','Sub Category','Raised By','Assignment Group','Assigned To','State','Created On']
        @name = "Tickets Closed by Service Desk"
      when 'open incidents'
        all_tickets = IncidentAgeingTicket.where(:created_month => @month,:created_year => @year).where(:assignment_group => @groups_niit).where.not(:assigned_company => ['','INSEE DIGITAL','FreeWill Solotions','Orangemantra','Siam City Cement (Lanka)'],:assignment_group => ['OMG Application (INSEE Plus)','OMG Application (P2P RPA)'])
        @fields = IncidentAgeingTicket.column_names
        @sheets = {'Incident Tickets' => all_tickets}
        @header = IncidentAgeingTicket.column_names.map{|u|u.upcase}
        @name = "Open Incident Tickets"
      when 'open requests'
        all_tickets = ServiceRequestAgeingTicket.where(:created_month => @month,:created_year => @year).where.not(:assigned_company => ['INSEE DIGITAL','FreeWill Solotions','Orangemantra','','Siam City Cement (Lanka)'],:assignment_group => ['OMG Application (INSEE Plus)','OMG Application (P2P RPA)']).where(:assignment_group => @groups_niit).all
        @fields = ServiceRequestAgeingTicket.column_names
        @sheets = {'Service Request Tickets' => all_tickets}
        @header = ServiceRequestAgeingTicket.column_names.map{|u|u.upcase}
        @name = "Open Service Requests Tickets"
      end
      respond_to do |format|
        format.xlsx {
          response.headers['Content-Disposition'] = "attachment; filename=#{params[:record_type]}.xlsx"
        }
      end
    end
  end

  def export_data
    start_date = @month_date.to_s + " 00:00:00"
    end_date = @month_end.to_s + " 23:59:59"
    if params[:record_type].present? && params[:record_type] != ''
      report_method = params[:record_type]
      case report_method
      when 'assessment'
        # assessment = table_name.singularize.classify.constantize.where(params[:query]).all
        assessment = Assessment.where("sys_created_on BETWEEN ? AND ?",start_date,end_date)
        @fields = Assessment.column_names
        @sheets = {'Assessment' => assessment}
        @name = "Assessment"
      end
    else
      @fields = []
      @sheets = {'Assessment' => []}
      @name = "Customer Satisfaction Score"
    end
    respond_to do |format|
      format.xlsx {
        response.headers['Content-Disposition'] = "attachment; filename=#{params[:record_type]}.xlsx"
      }
    end
  end

  def save_pdf_file(report_name = '',orientation = 'Portrait',report_partial = '')
    if report_partial != ''
      html = render_to_string(:action => report_partial + '.html.erb',:layout => "pdf_layout")
    else
      html = render_to_string(:action => report_name + '.html.erb',:layout => "pdf_layout")
    end

    header_content = render_to_string(:template => 'reports/header_pdf_report.html.erb',:layout => false)
    pdf = WickedPdf.new.pdf_from_string(
        html,
        javascript_delay: 1000,
        orientation: orientation,
        raise_on_all_errors: true,
        log_level: 'error',
        header:  { content: header_content ,spacing: 7,line: true,})
    save_path = Rails.root.join('public/downloads/reports',"#{report_name}_#{@month}_#{@year.to_s}.pdf")
    File.open(save_path, 'wb') do |file|
      file << pdf
    end
    new_report = PdfReport.where(:month => @month,:created_year => @year.to_s,:report_name=> report_name).first
    if new_report.present?
      report_pdf = new_report
    else
      report_pdf = PdfReport.new
    end
    report_pdf.month = @month
    report_pdf.created_year = @year
    report_pdf.report_name = report_name
    report_pdf.is_delete = false
    report_pdf.is_published = false
    report_pdf.path = save_path.to_s
    if report_pdf.save
      render :json => 'Report Published Successfully'
    else
      puts "#{report_pdf.errors}"
    end
  end

  private

  def set_month
    month_hash = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    if params.present? && params['month'].present?
      full_month = params['month']
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    elsif params.present? && params[:query_string].present? && params[:query_string][:month].present?
      full_month = params[:query_string][:month]
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    else
      month_d = (Time.current.beginning_of_month - 1.month)
      @month = month_hash[month_d.month - 1]
      @year = month_d.year
    end
    @month_date = month_d.strftime("%Y-%m-%d")
    @month_end = month_d.end_of_month.strftime("%Y-%m-%d")
    @diff = month_d.end_of_month.to_i - month_d.to_i
    @last_three_months = []
    (1..6).each do |t|
      @last_three_months.push((Time.now.utc - (7-t).month).strftime("%B-%Y").downcase)
    end
    @last_three_months.delete('april-2020')
    @last_three_months.delete('may-2020')
    @last_three_months.delete('june-2020')
    @groups_niit = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).map{|group| group.group_name}
  end

  def set_customer
    # check for customer
    if params[:customer].present?
      @customer = Customer.where(:api_customer_id => params[:customer]).first
    else
      @customer = Customer.first
    end
    #raise current_user.customer_id.inspect
    if current_user.customer_id == 0 or current_user.customer.api_customer_id == @customer.api_customer_id
      return true
    else
      redirect_to root_url
    end
  end

  def check_role
     unless ['coforge_admin','developer','end_user'].include?current_user.role
       redirect_to root_path
     end
   end
end
