class ServiceNowReportsController < ApplicationController
  before_action :set_dates_new
  include ServiceNow

  def assessment_feedbacks
    check_role
    current_time = Time.current
    @start_of_month = (current_time - 31.days).strftime("%Y-%m-%d 00:00:00")
    @end_of_month = current_time.strftime("%Y-%m-%d 23:59:59")
    if params[:country].present?
      @country = params[:country].capitalize
    else
      @country = 'Thailand'
    end
    @query = {'query_string' => {'report_method' => 'feedbacks','country' => @country,'query_paramterers' => {}}}
    @feedback_query = {'query_string' => {'report_method' => 'feedbacks_2','country' => @country,'query_paramterers' => {}}}
  end

  def set_feedback_data
    check_role
    if params.present?
      feedback = ServicenowFeedback.where(:id => params[:feedback_id]).first
      feedback.rating = params[:rating]
      feedback.feedback_updated = true
      feedback.call_date = params[:calldate]
      feedback.remarks = params[:remarks]
      feedback.servicedesk_owner = params[:servicedeskuser]
      feedback.call_successful = params[:successful]
      if feedback.save
        return true
      else
        return false
      end
    end
  end

  def first_call_resolution
    @all_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:u_indg_service_desk_counter=> '1').all
    @closed_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:incident_state => ['Resolved','Closed']).where(:reassignment_count => 0).where("assignment_group LIKE ?","%SERVICE DESK%").all
    @query = {'query_string' => {'report_method' => 'fcr','query_paramterers' => {}}}
  end

  def overall_sla_status
    @data_array_two = []
    @data_array_three = []

    response_chart_data = {"Meet SLA" => {"Requested Item" => 0,"Incident" => 0, "Change Request" => 0 },"Exceed SLA" => {"Requested Item" => 0,"Incident" => 0, "Change Request" => 0 }}

    @overall_response_sla = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').all

    @overall_response_sla.group_by{|sla| sla.task_sys_class_name}.map{|meet,i| { meet => i.group_by{|sla| sla.sccc_sla_u_sccc_sla_text}.map{|y,i| response_chart_data[y][meet] = i.count}}}

    resolution_chart_data = {"Meet SLA" => {"Requested Item" => 0,"Incident" => 0,"Change Request" => 0 },"Exceed SLA" => {"Requested Item" => 0,"Incident" => 0,"Change Request" => 0 }}
    @overall_resolution_sla = OverallSlaStatus.where("task_closed_at BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:tsla_stage=>'Completed').all
    @overall_resolution_sla.group_by{|sla| sla.task_sys_class_name}.map{|meet,i| { meet => i.group_by{|sla| sla.sccc_sla_u_sccc_sla_text}.map{|y,i| resolution_chart_data[y][meet] = i.count}}}

    @labels = ['Requested Item','Incident','Change Request']
    @response_chart = response_chart_data.map{|y,i| {"name" => y,"data" => i.values}}
    @resolution_chart = resolution_chart_data.map{|y,i| {"name" => y,"data" => i.values}}
    @piedata = response_chart_data.map{|y,i| {"name" => y,"y" => i.values.sum{|s|s}}}
    @colors = ['#2eb85a','#ff5d5d']
    @query = {'query_string' => {'report_method' => 'sla_overall','query_paramterers' => {}}}
    # @max_respose = (@response_chart.map{|i| i.values[1].max{|y|y}})[0] + 20
    # @max_resolution = (@resolution_chart.map{|i| i.values[1].max{|y|y}})[0] + 20
  end

  def l2_sla_status
    @data_array_two = []
    @data_array_three = []
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d 00:00:00")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d 23:59:59")

    response_chart_data = {"Meet SLA" => {"Requested Item" => 0,"Incident" => 0, "Change Request" => 0 },"Exceed SLA" => {"Requested Item" => 0,"Incident" => 0, "Change Request" => 0 }}
    @overall_response_sla = OverallSlaStatus.where("task_sys_created_on BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where.not("task_assignment_group LIKE ?","%SERVICE DESK%").all
    @overall_response_sla.group_by{|sla| sla.task_sys_class_name}.map{|meet,i| { meet => i.group_by{|sla| sla.sccc_sla_u_sccc_sla_text}.map{|y,i| response_chart_data[y][meet] = i.count}}}

    resolution_chart_data = {"Meet SLA" => {"Requested Item" => 0,"Incident" => 0, "Change Request" => 0 },"Exceed SLA" => {"Requested Item" => 0,"Incident" => 0, "Change Request" => 0 }}
    @overall_resolution_sla = OverallSlaStatus.where("task_closed_at BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where.not("inc_state = ? OR ritm_state = ? OR chg_state = ?",'Cancelled','Cancelled','Cancelled').where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE ?","%SERVICE DESK%").all
    @overall_resolution_sla.group_by{|sla| sla.task_sys_class_name}.map{|meet,i| { meet => i.group_by{|sla| sla.sccc_sla_u_sccc_sla_text}.map{|y,i| resolution_chart_data[y][meet] = i.count}}}

    @labels = ['Requested Item','Incident','Change Request']
    @response_chart = response_chart_data.map{|y,i| {"name" => y,"data" => i.values}}
    @resolution_chart = resolution_chart_data.map{|y,i| {"name" => y,"data" => i.values}}
    @piedata = response_chart_data.map{|y,i| {"name" => y,"y" => i.values.sum{|s|s}}}
    @colors = ['#2eb85a','#ff5d5d']
    @query = {'query_string' => {'report_method' => 'sla_l2','query_paramterers' => {}}}
  end

  def customer_satisfaction_score
    workstreams = ["BI&BPC","Data Center & SAP Basis","GRC & Authorization","Network & Security","Non-SAP","Others","SAP","ServiceDesk & EUS"]

    column_data = {} #"incident" => {"5" => 0,"4" => 0,"1" => 0,"0" => 0},"sc_req_item" => {"5" => 0,"4" => 0,"1" => 0,"0" => 0}}

    column_data_1 = { "Survey Sent" => {"BI&BPC" => 0,"Data Center & SAP Basis" => 0,"GRC & Authorization" => 0,"Network & Security" => 0,"Non-SAP" => 0, "Others" => 0, "SAP" => 0,"ServiceDesk & EUS" => 0},"Survey Recieved" => {"BI&BPC" => 0,"Data Center & SAP Basis" => 0,"GRC & Authorization" => 0,"Network & Security" => 0,"Non-SAP" => 0, "Others" => 0, "SAP" => 0,"ServiceDesk & EUS" => 0}}

    @total_assesments = Assessment.where("sys_created_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
    @received_assesments = Assessment.where("sys_created_on >= ?","2020-03-25 00:00:00").where("taken_on BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:state=>'Complete').all

    @csat_score = CustomerSatisfactionScore.where.not("mr_actual_value = ? OR mr_actual_value = ? ","-1","6").where("ai_taken_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all

    if @csat_score.count > 0
      csat_score_group = @csat_score.group(:workstream).group(:mr_actual_value).count
    else
      csat_score_group = {}
    end

    if @total_assesments.count > 0
      group_wise_total_assessments = @total_assesments.group(:workstream).count
    else
      group_wise_total_assessments = {}
    end

    if @received_assesments.count > 0
      group_wise_received_assessments = @received_assesments.group(:workstream).count
    else
      group_wise_received_assessments = {}
    end

    workstreams.each do |work|
      {'Very Satisfied(5)' => '5','Satisfied(4)' => '4','Not Satisfied(1)' => '1','Un Acceptable(0)' => '0'}.each do |index,score|
        unless column_data[index].present?
          column_data[index] = {}
        end
        unless column_data[index][work].present?
          column_data[index][work] = 0
        end
        if csat_score_group.key?([work,score])
          column_data[index][work] = csat_score_group[[work,score]]
        end
      end
      if group_wise_total_assessments.key?(work)
        column_data_1["Survey Sent"][work] = group_wise_total_assessments[work]
      end
      if group_wise_received_assessments.key?(work)
        column_data_1["Survey Recieved"][work] = group_wise_received_assessments[work]
      end
    end

    @cssr_data = column_data_1.map{|y,i| {"name" => y , "data" => i.values}}
    @cssr_labels = workstreams

    @csat_chart_data = column_data.map{|y,i| {"name" => y , "data" => i.values}}

    @groups = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).all
    groups = @groups.map{|group| "Group: "+group.group_name}

    if @csat_score.count > 0
      @total_score = @csat_score.group_by{|sla| sla.mr_actual_value}.map{|y,i| {y => [i.count,(y.to_i*i.count)]}}
      # @csat_score.group_by{|sla| sla.ai_trigger_table}.map{|y,i| [y.remove("Group: ") ,i.group_by{|sla| sla.mr_actual_value}]}.map{|y,i| i.map{|key,value| column_data[y][key] = value.count}}
    end
    @barchart_data = column_data.map{|y,i| {"name" => y , "data" => i.values}}
    @labels = workstreams
    @colors = ['#2eb85a','#0070C0','#ffbf00','red']
    @piedata = [{"name" => "Survey Not Received" ,"y"=> (@total_assesments.count - @received_assesments.count)},{"name" => "Survey Received" ,"y"=> @received_assesments.count}]
    if @total_score.present?
      score = @total_score.map{|total| (total.values)[0][1]}.sum{|y|y}
      total = @total_score.map{|total| (total.values)[0][0]}.sum{|y|y}
      @ranking = (score/total.to_f).round(2)
    else
      @ranking = 5
    end
  end

  def critical_priority_tickets
    @priority_tickets = Incident.where.not(:incident_state => ['Closed','Resolved','Cancelled']).where(:priority => "1 - Critical").all
    @all_tickets = Incident.where(:incident_state => ['Closed','Resolved','Cancelled']).where(:priority => "1 - Critical").all
  end

  def critical_security_alerts
    @start_of_month = DateTime.now.utc.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = DateTime.now.utc.end_of_month.strftime("%Y-%m-%d")
    @priority_tickets = Incident.where(:u_alert_type => 'Critical').where(:correlation_display => 'BluSapphire').where.not(:incident_state => ['Closed','Resolved','Cancelled'])
    @all_tickets = Incident.where('closed_at BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:u_alert_type => 'Critical').where(:correlation_display => 'BluSapphire').all
  end

  def open_incidents
    incidents = Incident.where.not(:incident_state => ['Resolved','Closed','Cancelled']).where("sys_created_on >= ?","2020-03-25 00:00:00" ).all
    @groups = ServicenowGroup.where.not(:u_workstream => '').where(:active => true).all
    groups = @groups.map{|group| group.group_name}
    @incidents = incidents.select{|inc| groups.include?(inc.assignment_group)}
    @data_hash = {}
    @workstream_hash = {}

    @total = {"<1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @groups.each do |group|
      @data_hash[group.group_name] = {"workstream" => group.u_workstream,"<1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @workstream_hash[group.u_workstream] = {"<1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    end

    inc_state_hash = @incidents.group_by{|inc|inc.incident_state}.map{|y,i| [y,i.count]}
    if @incidents.count > 0
      @incidents.each do |sla|
        if sla.assignment_group.present? && sla.assignment_group != ''
          group = sla.assignment_group
          group_workstream = (@groups.select{|gro| gro.group_name == group})[0]
          workstream = group_workstream.u_workstream
          diff = ((Time.current - (sla.sys_created_on - 7.hour))/86400.0).round(1)
          if @data_hash[group].present?
            if diff >= 0.0 && diff < 7.0
              @data_hash[group]["<1 day to 7 days"] += 1
              @workstream_hash[workstream]["<1 day to 7 days"] += 1
              @total["<1 day to 7 days"] += 1
            elsif diff >= 7.0 && diff < 15.0
              @data_hash[group]["7 to 15 days"] += 1
              @total["7 to 15 days"] += 1
              @workstream_hash[workstream]["7 to 15 days"] += 1
            elsif diff >= 15.0 && diff < 30.0
              @data_hash[group]["15 to 30 days"] += 1
              @total["15 to 30 days"] += 1
              @workstream_hash[workstream]["15 to 30 days"] += 1
            elsif diff >= 30.0
              @data_hash[group][">30 days"] += 1
              @total[">30 days"] += 1
              @workstream_hash[workstream][">30 days"] += 1
            end
          end
        end
      end
    end
    @state_labels = inc_state_hash.map{|inc_s| inc_s[0]}
    @statedata = [{
      "name" => "Tickets",
      "data" => inc_state_hash.map{|inc_s| inc_s[1]}
    }]
    # @statedata = inc_state_hash.map{|inc| {"name" => inc[0],"y" => inc[1]}}
    @labels = @workstream_hash.map{|workstream,value| workstream}
    @age_labels = ["<1 day to 7 days","7 to 15 days","15 to 30 days",">30 days"]
    @piedata = [{
      "name" => "Tickets",
      "data" => @total.values,
      "colorByPoint" => true
    }]
    barchart_labels = (@workstream_hash.map{|workstream,value| value.keys })[0]
    barchart_data = @workstream_hash.map{|workstream,value| value.values }
    @bar_data = []
    barchart_labels.each_with_index do |data,index|
       @bar_data.push({"name" => barchart_labels[index], "data" => barchart_data.map{|data| data[index]}})
    end
  end

  def open_requests
    @groups = ServicenowGroup.where(:active => true).where.not(:u_workstream => '').all
    @data_hash = {}
    @workstream_hash = {}
    @total = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @groups.each do |group|
      @data_hash[group.group_name] = {"workstream" => group.u_workstream,"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    @workstream_hash[group.u_workstream] = {"> 1 day to 7 days" => 0,"7 to 15 days" => 0,"15 to 30 days" => 0,">30 days" => 0}
    end
    groups = @groups.map{|group| group.group_name}
    @service_request_items = ServiceRequestItem.where.not(:state => ['Pending Approval','Closed','Completed','Cancelled']).where(:assignment_group => groups).where("sys_created_on >= ?","2020-03-25 00:00:00").all
    inc_state_hash = @service_request_items.group_by{|inc|inc.state}.map{|y,i| [y,i.count]}
    if @service_request_items.count > 0
      @service_request_items.each do |sla|
        if sla.assignment_group.present? && sla.assignment_group != ''
          group = sla.assignment_group
          group_workstream = (@groups.select{|gro| gro.group_name == group})[0]
          workstream = group_workstream.u_workstream
          if (sla.sys_created_on.to_i > Time.parse('2020-09-02 23:59:59 UTC').to_i) && sla.u_fulfillment_start_time_stamp.present?
            diff = ((Time.current - (sla.u_fulfillment_start_time_stamp - 7.hour))/86400.0).round(1)
          else
            diff = ((Time.current - (sla.sys_created_on - 7.hour))/86400.0).round(1)
          end
          if @data_hash[group].present?
            if diff >= 0.0 && diff <= 7.0
              @data_hash[group]["> 1 day to 7 days"] += 1
              @workstream_hash[workstream]["> 1 day to 7 days"] += 1
              @total["> 1 day to 7 days"] += 1
            elsif diff > 7.0 && diff <= 15.0
              @data_hash[group]["7 to 15 days"] += 1
              @total["7 to 15 days"] += 1
              @workstream_hash[workstream]["7 to 15 days"] += 1
            elsif diff > 15.0 && diff <= 30.0
              @data_hash[group]["15 to 30 days"] += 1
              @total["15 to 30 days"] += 1
              @workstream_hash[workstream]["15 to 30 days"] += 1
            elsif diff > 30.0
              @data_hash[group][">30 days"] += 1
              @total[">30 days"] += 1
              @workstream_hash[workstream][">30 days"] += 1
            end
          end
        end
      end
    end
    @state_labels = inc_state_hash.map{|inc_s| inc_s[0]}
    @statedata = [{
      "name" => "Tickets",
      "data" => inc_state_hash.map{|inc_s| inc_s[1]}
    }]
    # @statedata = inc_state_hash.map{|inc| {"name" => inc[0],"y" => inc[1]}}
    @labels = @workstream_hash.map{|workstream,value| workstream}
    @age_labels = ["<1 day to 7 days","7 to 15 days","15 to 30 days",">30 days"]
    @piedata = [{
      "name" => "Tickets",
      "data" => @total.values,
      "colorByPoint" => true
    }]
    @labels = @workstream_hash.map{|workstream,value| workstream}
    barchart_labels = (@workstream_hash.map{|workstream,value| value.keys })[0]
    barchart_data = @workstream_hash.map{|workstream,value| value.values }
    @bar_data = []
    barchart_labels.each_with_index do |data,index|
       @bar_data.push({"name" => barchart_labels[index], "data" => barchart_data.map{|data| data[index]}})
    end
  end

  def get_data_json
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d")
    start_date = @start_of_month.to_s + " 00:00:00"
    end_date = @end_of_month.to_s + " 23:59:59"
    current_time = Time.current
    if params[:query_string].present? && params[:query_string] != ''
      report_method = params[:query_string][:report_method]
      country = params[:query_string][:country]
      case report_method
      when 'feedbacks_2'
        start_date = (current_time - 31.days).strftime("%Y-%m-%d 00:00:00")
        end_date = current_time.strftime("%Y-%m-%d 23:59:59")
        total_data = ServicenowFeedback.where(:country => country).where("created_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:state => ['Ready to take','Complete']).where(:feedback_updated => true).all
        total_count = total_data.count
        table_data = total_data.datatable_filter(params['search']['value'], params['columns'])
        lines_filtered = table_data.count
        table_data = table_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        table_data = table_data.offset(params['start'].to_i).limit(params['length'])
        table_data = table_data.each do |inc|
          if inc.ticket_number.start_with?('INC')
            inc.ticket_number = "<a href='https://scccpcl.service-now.com/incident.do?sys_id=#{inc.trigger_sys_id}' target='_blank'>#{inc.ticket_number}</a>"
          elsif inc.ticket_number.start_with?('RITM')
            inc.ticket_number = "<a href='https://scccpcl.service-now.com/sc_req_item.do?sys_id=#{inc.trigger_sys_id}' target='_blank'>#{inc.ticket_number}</a>"
          else
          end
        end
      when 'feedbacks'
        start_date = (current_time - 31.days).strftime("%Y-%m-%d 00:00:00")
        end_date = current_time.strftime("%Y-%m-%d 23:59:59")
        total_data = ServicenowFeedback.where(:country => country).where("(created_on BETWEEN ? AND ?) AND state = ?",start_date,end_date,'Ready to take').where(:pillar => ['Application','Infrastructure']).where(:feedback_updated => false)
        total_count = total_data.count
        table_data = total_data.datatable_filter(params['search']['value'], params['columns'])
        lines_filtered = table_data.count
        table_data = table_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        table_data = table_data.offset(params['start'].to_i).limit(params['length'])
        table_data = table_data.each do |inc|
          if inc.ticket_number.start_with?('INC')
            inc.ticket_number = "<a href='https://scccpcl.service-now.com/incident.do?sys_id=#{inc.trigger_sys_id}' target='_blank'>#{inc.ticket_number}</a>"
          elsif inc.ticket_number.start_with?('RITM')
            inc.ticket_number = "<a href='https://scccpcl.service-now.com/sc_req_item.do?sys_id=#{inc.trigger_sys_id}' target='_blank'>#{inc.ticket_number}</a>"
          else
          end
        end
      when 'sla_overall'
        total_response = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ?",'Cancelled','Cancelled').where(:tsla_stage=>'Completed').all
        total_resolution = OverallSlaStatus.where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where(:tsla_stage=>'Completed').all
        total_count = total_response.count + total_resolution.count
        total_data = total_response.or(total_resolution)
        table_data = total_data.datatable_filter(params['search']['value'], params['columns'])
        lines_filtered = table_data.count
        table_data = table_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])

        table_data = table_data.offset(params['start'].to_i).limit(params['length'])
        table_data = table_data.each do |inc|
            if inc.task_number.start_with?('INC')
              inc.task_number = "<a href='https://scccpcl.service-now.com/incident.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            elsif inc.task_number.start_with?('RITM')
              inc.task_number = "<a href='https://scccpcl.service-now.com/sc_req_item.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            else
              inc.task_number = "<a href='https://scccpcl.service-now.com/change_request.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            end
          end
      when 'sla_l2'
        total_response = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ?",'Cancelled','Cancelled').where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE ?","%SERVICE DESK%").all
        total_resolution = OverallSlaStatus.where("task_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",start_date,end_date).where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE ?","%SERVICE DESK%").all
        total_count = total_response.count + total_resolution.count
        total_data = total_response.or(total_resolution)
        table_data = total_data.datatable_filter(params['search']['value'], params['columns'])
        lines_filtered = table_data.count
        table_data = table_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])

        table_data = table_data.offset(params['start'].to_i).limit(params['length'])
        table_data = table_data.each do |inc|
            if inc.task_number.start_with?('INC')
              inc.task_number = "<a href='https://scccpcl.service-now.com/incident.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            elsif inc.task_number.start_with?('RITM')
              inc.task_number = "<a href='https://scccpcl.service-now.com/sc_req_item.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            else
              inc.task_number = "<a href='https://scccpcl.service-now.com/change_request.do?sys_id=#{inc.task_sys_id}' target='_blank'>#{inc.task_number}</a>"
            end
          end
      when 'fcr'
        total_data = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:incident_state => ['Resolved','Closed']).where(:reassignment_count => 0).where("assignment_group LIKE ?","%SERVICE DESK%").all
        total_count = total_data.count
        table_data = total_data.datatable_filter(params['search']['value'], params['columns'])
        lines_filtered = table_data.count
        table_data = table_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        table_data = table_data.offset(params['start'].to_i).limit(params['length'])
        table_data = table_data.each{|inc| inc.number = "<a href='https://scccpcl.service-now.com/incident.do?sys_id=#{inc.sys_id}' target='_blank'>#{inc.number}</a>"}
      when 'surveythismonth'
        all_received_assessments = Assessment.where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:state=>'Complete').all
        getting_data = all_received_assessments.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['sys_created_on'] = inc['sys_created_on'].strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['taken_on'].present?) ? inc['taken_on'] = inc['taken_on'].strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      when 'surveylastmonth'
        all_received_assessments = Assessment.where("taken_on BETWEEN ? AND ?",start_date,end_date).where(:state=>'Complete').all
        getting_data = all_received_assessments.where.not("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['sys_created_on'] = inc['sys_created_on'].strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['taken_on'].present?) ? inc['taken_on'] = inc['taken_on'].strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      when 'assessment'
        getting_data = Assessment.where("sys_created_on BETWEEN ? AND ?",start_date,end_date).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['sys_created_on'] = inc['sys_created_on'].strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['taken_on'].present?) ? inc['taken_on'] = inc['taken_on'].strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      when 'csatreceived'
        getting_data = CustomerSatisfactionScore.where.not("mr_actual_value = ? OR mr_actual_value = ? ","-1","6").where("ai_taken_on BETWEEN ? AND ?",start_date,end_date).all
        total_count = getting_data.count
        getting_data = getting_data.datatable_filter(params['search']['value'],params['columns'])
        lines_filtered = getting_data.count
        getting_data = getting_data.datatable_order(params['order']['0']['column'].to_i,params['order']['0']['dir'])
        getting_data = getting_data.offset(params['start'].to_i).limit(params['length'])
        table_data = getting_data.as_json
        table_data = table_data.each{ |inc| inc['ai_created_on'] = inc['ai_created_on'].to_time.strftime('%Y-%m-%d %H:%M:%S')}
        table_data = table_data.each{ |inc| (inc['ai_taken_on'].present?) ? inc['ai_taken_on'] = inc['ai_taken_on'].to_time.strftime('%Y-%m-%d %H:%M:%S') : inc['taken_on']}
      end
      render json: { table_data: table_data,draw: params['draw'].to_i,recordsTotal: total_count,recordsFiltered: lines_filtered}
      else
        render json: {}
      end
  end

  def export_data_excel
    groups = ServicenowGroup.where.not(:u_workstream => '').where(:active => true).all
    groups = groups.map{|group| group.group_name}
    if params[:record_type].present? && params[:record_type] != ''
      case params[:record_type]
      when 'csatreceived'
        csat_score = CustomerSatisfactionScore.where.not("mr_actual_value = ? OR mr_actual_value = ? ","-1","6").where("ai_taken_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
        assessments = Assessment.where("sys_created_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
        @fields = CustomerSatisfactionScore.column_names
        @sheets = {'CSAT Score' => csat_score}
        @header = CustomerSatisfactionScore.column_names
        @name = "Customer Satisfaction Score"
      when 'assessmentsent'
        assessment = Assessment.where("sys_created_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
        @fields = Assessment.column_names
        @sheets = {'Assessments' => assessment}
        @header = Assessment.column_names
        @name = "Surveys Sent"
      when 'surveyreceivedcurrent'
        assessment = Assessment.where("taken_on BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:state=>'Complete').all
        assessment = assessment.where("sys_created_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
        @fields = Assessment.column_names
        @sheets = {'Assessments' => assessment}
        @header = Assessment.column_names
        @name = "Surveys Received Current Month"
      when 'surveyreceivedprevious'
        assessment = Assessment.where("taken_on BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:state=>'Complete').all
        assessment = assessment.where.not("sys_created_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
        @fields = Assessment.column_names
        @sheets = {'Assessments' => assessment}
        @header = Assessment.column_names
        @name = "Surveys Received Previous Month"
      when 'incidents_ageing'
        total_data = Incident.where.not(:incident_state => ['Resolved','Closed','Cancelled']).where("sys_created_on >= ?","2020-03-25 00:00:00" ).all
        @fields = ['number','category','subcategory','caller_id','assignment_group','assigned_to','incident_state','sys_created_on']
        @sheets = {'Open Incidents' => total_data}
        @header = ['Number','Category','Sub Category','Raised By','Assignment Group','Assigned To','State','Created On']
        @name = "Incidents"
      when 'sr_ageing'
        total_data = ServiceRequestItem.where.not(:state => ['Pending Approval','Closed','Completed','Cancelled']).where(:assignment_group => groups).where("sys_created_on >= ?","2020-03-25 00:00:00").all
        @fields = ['number','opened_by','assignment_group','cat_item','state','sys_created_on','short_description']
        @sheets = {'Incident Tickets' => total_data}
        @header = ['Number','Requested By','Assignment Group','Item','State','Created On','Short Description']
        @name = "Open Service Requests Tickets"
      when 'feedback_get'
      country = params[:country]
      current_time = Time.current
      start_date = (current_time - 31.days).strftime("%Y-%m-%d 00:00:00")
      end_date = current_time.strftime("%Y-%m-%d 23:59:59")
       total_data =  ServicenowFeedback.where(:country => country).where("(created_on BETWEEN ? AND ?) AND state = ?",start_date,end_date,'Ready to take').where(:pillar => ['Application','Infrastructure']).where(:feedback_updated => false).all
       @fields = ['ticket_number', 'workstream', 'assignment_group','assigned_user','country', 'state', 'resolved_at', 'created_on', 'servicedesk_owner', 'pillar', 'rating', 'is_updated', 'call_date', 'call_successful', 'remarks', 'created_at', 'updated_at', 'trigger_sys_id', 'user', 'feedback_updated']
        @header = ['Number','Workstream','Assignment Group','Assigned To','Country','State','Resolved at','Created on','Service Desk Owner','Pillar','Rating','Updated','Call Date','Call Successful','Remarks','Created At','Updated At','Ticket Sys ID','User','Feedback Updated by User']
        @sheets = {'Feedbacks' => total_data}
        @name = "Feedbacks"


      when 'feedback_updated'
        country = params[:country]
        current_time = Time.current
        start_date = (current_time - 31.days).strftime("%Y-%m-%d 00:00:00")
        end_date = current_time.strftime("%Y-%m-%d 23:59:59")
        total_data = ServicenowFeedback.where(:country => country).where("created_on BETWEEN ? AND ?",start_date,end_date).where(:pillar => ['Application','Infrastructure']).where(:state => ['Ready to take','Complete']).where(:feedback_updated => true).all
        @fields = ['ticket_number', 'workstream','assignment_group','assigned_user', 'country', 'state', 'resolved_at', 'created_on', 'servicedesk_owner', 'pillar', 'rating', 'is_updated', 'call_date', 'call_successful', 'remarks', 'created_at', 'updated_at', 'trigger_sys_id', 'user', 'feedback_updated']
        @header = ['Number','Workstream','Assignment Group','Assigned To','Country','State','Resolved at','Created on','Service Desk Owner','Pillar','Rating','Updated','Call Date','Call Successful','Remarks','Created At','Updated At','Ticket Sys ID','User','Feedback Updated by User']
        @sheets = {'Feedbacks Updated' => total_data}
        @name = "Feedbacks_updated"
      when 'sla_overall'
        overall_response_sla = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ?",'Cancelled','Cancelled').where(:tsla_stage=>'Completed').all
        overall_resolution_sla = OverallSlaStatus.where("task_closed_at BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").all
        @fields = ['task_number','tsla_sla','task_priority','task_short_description','sccc_sla_u_sccc_sla_text','task_assignment_group','task_assigned_to','task_sys_created_on']
        @sheets = {'Response Data' => overall_response_sla,'Resolution Data'=>overall_resolution_sla}
        @header = ['Number','SLA','Priority','Short Description','SCCC SLA Text','Assignment Group','Assigned To','Created On']
        @name = "SLA"
      when 'sla_l2'
        overall_response_sla = OverallSlaStatus.where("tsla_end_time BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ?","%Response%").where.not("inc_state = ? OR ritm_state = ?",'Cancelled','Cancelled').where(:tsla_stage=>'Completed').where.not("task_assignment_group LIKE ?","%SERVICE DESK%").all
        overall_resolution_sla = OverallSlaStatus.where("task_closed_at BETWEEN ? AND ?",@start_of_month,@end_of_month).where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%resolution%","%resolve%").where.not("task_assignment_group LIKE ?","%SERVICE DESK%").all
        @fields = ['task_number','tsla_sla','task_priority','task_short_description','sccc_sla_u_sccc_sla_text','task_assignment_group','task_assigned_to','task_sys_created_on']
        @sheets = {'Response Data' => overall_response_sla,'Resolution Data'=>overall_resolution_sla}
        @header = ['Number','SLA','Priority','Short Description','SCCC SLA Text','Assignment Group','Assigned To','Created On']
        @name = "SLA"
      when 'csat'
        csat_score = CustomerSatisfactionScore.where.not("mr_actual_value = ? OR mr_actual_value = ?","-1","6").where("ai_taken_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
        @fields = ['ai_taken_on','ai_task_id','mr_user','md_display','ai_related_id_1','u_module','workstream','country']
        @sheets = {'CSAT Score' => csat_score}
        @header = ['Taken On','Trigger ID','Assigned To','String value','Assignment Group','Module','Workstream','Country']
        @name = "Customer Satisfaction Score"
      when 'P1 Tickets'
        all_tickets = Incident.where(:incident_state => ['Closed','Resolved','Cancelled']).where(:priority => "1 - Critical").all
        @fields = ['number','category','subcategory','caller_id','assignment_group','assigned_to','incident_state','sys_created_on']
        @sheets = {'Last 3 Month Data' => all_tickets}
        @header = ['Number','Category','Sub Category','Raised By','Assignment Group','Assigned To','State','Created On']
        @name = "P1 Tickets"
      when 'fcr'
        all_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:u_indg_service_desk_counter=> '1').all
        closed_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:incident_state => ['Resolved','Closed']).where(:reassignment_count => 0).where("assignment_group LIKE ?","%SERVICE DESK%").all
        @fields = ['number','category','subcategory','caller_id','assignment_group','assigned_to','incident_state','sys_created_on']
        @sheets = {'Tickets Assigned' => all_tickets,'Tickets Closed' => closed_tickets}
        @header = ['Number','Category','Sub Category','Raised By','Assignment Group','Assigned To','State','Created On']
        @name = "Tickets Closed by Service Desk"
      end
      respond_to do |format|
        format.xlsx {
          response.headers['Content-Disposition'] = "attachment; filename=#{params[:record_type]}.xlsx"
        }
      end
    end
  end

  def set_dates_new
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d 00:00:00")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d 23:59:59")
  end

  # new reports
  def incidents
    @showfilter = true
    if params[:status].present? && params[:status] != ''
      @status = params[:status].downcase
      @report_url = root_url + 'service_now_reports/incidents?status='+@status
    end
    # refactor function
    set_start_and_end_dates

    if @status.downcase == "logged"
      query = [
        {'name' => 'sys_created_on','value' => @day_type.to_time, 'operator' => 'equal', 'type' => 'date', 'joinoperator' => 'none' },
      ]
    else
      query = [
        {'name' => 'closed_at','value' => @day_type.to_time, 'operator' => 'equal', 'type' => 'date', 'joinoperator' => 'none' },
      ]
    end
    @incidents_total_open = get_data(query,APP_CONFIG['incident_table'],'sys_id,number,priority,category,subcategory,sys_created_by,sys_created_on,closed_at')
  end

  private

  def set_labels_and_graph_type
    @labels,@data_get,@sdate,@edate = set_dates('last_five_days','')
    @graph_type= 'day'
  end

  def check_role
    unless ['servicedesk_user','coforge_admin','developer','coforge_read'].include?current_user.role
      redirect_to root_path
    end
  end

  def set_start_and_end_dates
    if params[:day_type].present? && params[:day_type] != ''
      @day_type = params[:day_type]
      if @day_type.count('-') == 2
        @start_date = Time.parse(@day_type)
        @end_date = @start_date

      else
        @start_date = Time.parse("1-"+@day_type)
        @end_date = @start_date.end_of_month
      end
    else
      @day_type = ''
    end
    if params[:sdate].present? && params[:edate].present?
      @start_date = Time.parse(params[:sdate])
      @end_date = Time.parse(params[:edate])
    end
  end
end
