class WidgetsController < ApplicationController
  
  
end
