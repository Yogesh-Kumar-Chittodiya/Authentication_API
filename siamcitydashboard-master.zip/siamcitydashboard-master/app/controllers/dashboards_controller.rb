class DashboardsController < ApplicationController
  
  def index

    # check for dashboard
    if params[:type].present?
      @type = params[:type]
      if current_user.role == "developer"
        @dashboard = Dashboard.where(:slug=>params[:type], :is_active=>true).first
      elsif current_user.role == "admin"
        @dashboard = Dashboard.where(:customer_id=>current_user.customer_id, :slug=>params[:type], :is_active=>true).first
      else
        @dashboard = current_user.dashboards.where(:slug=>params[:type], :is_active=>true).first
      end
      if !@dashboard.present?
        redirect_to root_url
      end
    else
      @dashboard = current_user.dashboards.where(:is_active=>true).first
    end

    if !@dashboard.present?
      if current_user.role == "developer"
          @dashboard = Dashboard.where(:is_active=>true).first
      elsif current_user.role == "admin"
          @dashboard = Dashboard.where(customer_id: current_user.customer_id, :is_active=>true).first
      end
    end
    #  find dashboard and their widgets

    if @dashboard.present?
      @widgets = @dashboard.widgets.order("sort_order ASC")
    end
    # check for customer

    # Get total customers list
    @total_customers = Customer.where(:is_active=>true)
    # end
  end

  def formatData(type,type_value,data)
    if type == 'customer'
      data = data.select{|device| device['client_id'] === type_value.to_s}.map{|y| y}
    end
    return data
  end
  
  def bottom_scroll
    render :partial=>"bottom_scroll"
  end
  
end
