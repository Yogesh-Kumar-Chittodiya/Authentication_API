class ServiceNowWidgetsController < ApplicationController

  before_action :set_type_and_count,  only: [:incidents_data,:change_requests_data,:service_requests_data,:problems_data,:resolution_automation_index,:incident_origin_index,:auto_resolved_incidents,:sla_resolution_met,:sla_resolution_breached]

  include ServiceNow


  def overall_ticket_management
    @data_array_two = []
    @data_array_three = []
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d")
    # overall sla status array
      overall_sla_status
    #  End of Overall SLA Status

    #  First call Resolution
      get_fcr
    # END

    # SLA L2/L3
      l2_l3_sla
    #  END of SLA L2/L3

    #  CSAT Score
      csat_score
    # END

    #  Priority 1 Tickets
      priority_tickets
    # END

    incident_ageing

    requests_ageing

    render partial: "overall_ticket_management"
  end

  def overall_sla_status
    overall_sla_status = OverallSlaStatus.where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%Resolution%","%Resolve%").where("tsla_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:tsla_stage => "Completed")

    # Overall SLA Status
    total_count = overall_sla_status.count
    status = 'Green'
    border_status = 'success'
    if total_count > 0
      meet_sla_count = overall_sla_status.select{|st| st.sccc_sla_u_sccc_sla_text == "Meet SLA"}.count
      percentage = (meet_sla_count * 100.00/total_count).round(2)
      if percentage >= 99.00
      status = 'Green'
      border_status = 'success'
      elsif percentage < 99.00 && percentage >= 98.00
        status = '#ffbf00'
        border_status = 'warning'
      else
        status = 'Red'
        border_status = 'danger'
      end
    end
    overall_sla_status_data = {:status=>status,:availability=>percentage.to_s + '%',:color=>border_status ,:title=> 'Overall SLA Status',:url=>overall_sla_status_service_now_reports_path,:icon=>'dashboard' }
    @data_array_two.push(overall_sla_status_data)
  end

  def get_fcr
    all_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:u_indg_service_desk_counter=> '1').all
    closed_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where(:incident_state => ['Resolved','Closed']).where(:reassignment_count => 0).where("assignment_group LIKE ?","%SERVICE DESK%").all
    percentage = 0.00
    status = 'Green'
    border_status = 'success'
    if all_tickets.count > 0
      percentage = (closed_tickets.count * 100.00/all_tickets.count).round(2)
      if percentage >= 75.00
        status = 'Green'
        border_status = 'success'
      else
        status = 'Red'
        border_status = 'danger'
      end
    end
    @data_array_two.push({:status=>status,:availability=>percentage.to_s + '%',:color=>border_status ,:title=> 'First call Resolution',:url=>first_call_resolution_service_now_reports_path,:icon=>'dashboard' })
  end

  def l2_l3_sla
    l2_sla_status = OverallSlaStatus.where("task_sys_class_name = ? OR task_sys_class_name = ? OR task_sys_class_name = ?","Incident","Requested Item","Change Request").where("tsla_sla LIKE ? OR tsla_sla LIKE ?","%Resolution%","%Resolve%").where("tsla_sys_created_on >= ?","2020-03-25 00:00:00").where("task_closed_at BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:tsla_stage => "Completed").where.not("task_assignment_group LIKE ?","%SERVICE DESK%")
    total_count_l2 = l2_sla_status.count
    status = 'Green'
    border_status = 'success'
    if total_count_l2 > 0
      meet_sla_count_l2 = l2_sla_status.select{|st| st.sccc_sla_u_sccc_sla_text == "Meet SLA"}.count
      percentage = (meet_sla_count_l2 * 100.00/total_count_l2).round(2)
      if percentage >= 99.00
        status = 'Green'
        border_status = 'success'
      elsif percentage < 99.00 && percentage >= 98.00
        status = '#ffbf00'
        border_status = 'warning'
      else
        status = 'Red'
        border_status = 'danger'
      end
    end
    l2_sla_status_data = {:status=>status,:availability=>percentage.to_s + '%',:color=>border_status ,:title=> 'L2/L3 - SLA Status',:url=>l2_sla_status_service_now_reports_path,:icon=>'dashboard' }
    @data_array_two.push(l2_sla_status_data)
  end

  def csat_score
    csat_score = CustomerSatisfactionScore.where.not("mr_actual_value = ? OR mr_actual_value = ?","-1","6").where("ai_taken_on BETWEEN ? AND ?",@start_of_month,@end_of_month).all
    ranking = 0
    if csat_score.count > 0
      total_score = csat_score.group_by{|sla| sla.mr_actual_value}.map{|y,i| {y => [i.count,(y.to_i*i.count)]}}
      score = total_score.map{|total| (total.values)[0][1]}.sum{|y|y}
      total = total_score.map{|total| (total.values)[0][0]}.sum{|y|y}
      ranking = (score/total.to_f).round(2)
    end

    status = 'Green'
    border_status = 'success'
    if ranking < 4.5
      status = 'Red'
      border_status = 'danger'
    end
    @data_array_three.push({:status=>status,:availability=>ranking,:color=>border_status ,:title=> 'CSAT Score',:url=>customer_satisfaction_score_service_now_reports_path,:icon=>'dashboard' })
  end

  def priority_tickets
    @priority_tickets = Incident.where.not(:incident_state => ['Closed','Resolved','Cancelled']).where(:priority => "1 - Critical").all
    status = 'Green'
    border_status = 'success'
    if @priority_tickets.count > 0
      status = 'Red'
      border_status = 'danger'
    else
      status = 'Green'
      border_status = 'success'
    end

    @data_array_three.push({:status=>status,:availability=>@priority_tickets.count,:color=>border_status ,:title=> 'Priority 1 Tickets',:url=>critical_priority_tickets_service_now_reports_path,:icon=>'dashboard' })
  end

  def incident_ageing
    incidents = Incident.where.not(:incident_state => ['Resolved','Closed','Cancelled']).where("sys_created_on >= ?","2020-03-25 00:00:00" ).all.count
    status = 'Green'
    border_status = 'success'
    @data_array_three.push({:status=>status,:availability=>incidents,:color=>border_status ,:title=> 'Open Incidents',:url=>open_incidents_service_now_reports_path,:icon=>'dashboard' })
  end

  def requests_ageing
    service_request_items = ServiceRequestItem.where.not(:state => ['Pending Approval','Closed','Completed','Cancelled']).where("sys_created_on >= ?","2020-03-25 00:00:00").all.count
    status = 'Green'
    border_status = 'success'
    @data_array_three.push({:status=>status,:availability=>service_request_items,:color=>border_status ,:title=> 'Open Service Requests',:url=>open_requests_service_now_reports_path,:icon=>'dashboard' })
  end

  def service_request_ageing
  end

  def incident_current_status
    query = [
      {'name' => 'inc_sys_created_by','value' => 'Eurostar_opsramp', 'operator' => 'notequal', 'type' => 'normal', 'joinoperator' => 'and' },
      {'name' => 'inc_sys_created_on','value' => Date.today, 'operator' => 'equal', 'type' => 'date', 'joinoperator' => 'or' },
      {'name' => 'inc_closed_at','value' => Date.today, 'operator' => 'equal', 'type' => 'date', 'joinoperator' => 'none' }
    ]
    @total_incident_sla =  get_data(query,APP_CONFIG['incident_table'],'inc_sys_created_on,inc_closed_at,inc_priority')
    render partial: "incident_current_status"
  end

  def incident_status
    query = [
      {'name' => 'sys_created_on','value' => Date.today, 'operator' => 'lessthenequal', 'type' => 'date', 'joinoperator' => 'and' },
      {'name' => 'state','value' => [1,2,3,10], 'operator' => 'in', 'type' => 'normal', 'joinoperator' => 'none' }
    ]
    @total_incident_current =  get_data(query,APP_CONFIG['incident_table'])
    render partial: "incident_status"
  end

  def incidents_data
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = [
      {'name' => 'sys_created_on','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'or' },
      {'name' => 'closed_at','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'none' }
    ]
    @total_incident_current =  get_data(query,APP_CONFIG['incident_table'],'sys_created_on,closed_at')
    render partial: "incidents_data"
  end

  def problems_data
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = [
    {'name' => 'sys_created_on','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'or' },
    {'name' => 'closed_at','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'none' }
    ]
    @problems_data =  get_data(query,APP_CONFIG['problem_table'],'sys_created_on,closed_at')
    render partial: "problems_data"
  end

  def service_requests_data
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = [
      {'name' => 'sys_created_on','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'or' },
      {'name' => 'closed_at','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'none' }
    ]
    @service_requests_data =  get_data(query,APP_CONFIG['service_request_table'],'sys_created_on,closed_at')
    render partial: "service_requests_data"
  end

  def change_requests_data
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = [
      {'name' => 'sys_created_on','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'or' },
      {'name' => 'closed_at','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'none' }
    ]

    @change_requests_data =  get_data(query,APP_CONFIG['change_request_table'],'sys_created_on,closed_at')
    render partial: "change_requests_data"
  end

  def incidents_ageing
    query = [
      {'name' => 'sys_created_on','value' => Date.today, 'operator' => 'lessthenequal', 'type' => 'date', 'joinoperator' => 'and' },
      {'name' => 'state','value' => [1,2,3,10], 'operator' => 'in', 'type' => 'normal', 'joinoperator' => 'none' }
    ]
    @total_incident_current =  get_data(query,APP_CONFIG['incident_table'])
    render partial: "incidents_ageing"
  end

  def live_incidents_scroll
    @total_incident_current = @total_incident_current_marquee
    render partial: "live_incidents_scroll"
  end

  def open_tickets_by_resolver_group
    query = [
      {'name' => 'inc_sys_created_by','value' => 'Eurostar_opsramp', 'operator' => 'notequal', 'type' => 'normal', 'joinoperator' => 'and' },
      {'name' => 'inc_sys_created_on','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'or' },
      {'name' => 'inc_state','value' => [1,2,3,10], 'operator' => 'in', 'type' => 'normal', 'joinoperator' => 'none' }
    ]
    @total_incident_current =  get_data(query,'u_es_incident_location')
    query = "sys_updated_on<=#{Date.today.strftime("%Y-%m-%d")}&sys_created_by!=Eurostar_OpsRamp&stateIN1,2,3,10"
    @total_incident_current =  get_incidents(query)
    render partial: "open_tickets_by_resolver_group"
  end

  def open_change_request_by_team
    query = "updated_on<=#{Date.today.strftime("%Y-%m-%d")}&stateNOTIN3,4"
    @change_requests_data =  get_change_requests(query)
    render partial: "open_change_request_by_team"
  end

  def change_request_stats
    query = "sys_domain%3D#{CUSTOMER_SYS_ID}%5Esys_created_by!%3DEurostar_opsramp%5Esys_created_onBETWEENjavascript%3Ags.dateGenerate(%27#{@start_date.strftime("%Y-%m-%d")}%27%2C'00%3A00%3A00')%40javascript%3Ags.dateGenerate(%27#{@end_date.strftime("%Y-%m-%d")}%27%2C'23%3A59%3A59')%5EORclosed_atBETWEENjavascript%3Ags.dateGenerate(%27#{@start_date.strftime("%Y-%m-%d")}%27%2C'00%3A00%3A00')%40javascript%3Ags.dateGenerate(%27#{@end_date.strftime("%Y-%m-%d")}%27%2C'23%3A59%3A59')"
    @change_requests_data =  get_change_requests(query)
    render partial: "change_request_stats"
  end

  def sla_resolution_met
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = "taskslatable_sys_updated_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}&taskslatable_has_breached=false"
    @total_incidents_slas =  getincidentSLAs(query)
    render partial: "sla_resolution_met"
  end

  def sla_resolution_breached
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = [
      {'name' => 'inc_sys_created_on','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'and' },
      {'name' => 'taskslatable_has_breached','value' => false, 'operator' => 'equal', 'type' => 'normal', 'joinoperator' => 'none' },

    ]
    @total_incidents_slas =  get_data(query,APP_CONFIG['incident_sla_table'])
    raise @total_incidents_slas[1].inspect
    render partial: "sla_resolution_breached"
  end

  def incident_origin_index
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = "sys_created_on>=#{@start_date.strftime("%Y-%m-%d")}&sys_updated_on<=#{@end_date.strftime("%Y-%m-%d")}"
    @total_incident_current =  get_incidents(query)
    render partial: "incident_origin_index"
  end

  def open_tickets_by_priority
    query = "sys_updated_on<=#{Date.today.strftime("%Y-%m-%d")}&sys_created_by!=Eurostar_OpsRamp&stateIN1,2,3,10"
    @total_incident_current =  get_incidents(query)
    render partial: "open_tickets_by_priority"
  end

  def open_tickets_by_status
    query = "sys_updated_on<=#{Date.today.strftime("%Y-%m-%d")}&sys_created_by!=Eurostar_OpsRamp&stateIN1,2,3,10"
    @total_incident_current =  get_incidents(query)
    render partial: "open_tickets_by_status"
  end

  def open_tickets_by_category
    query = "sys_updated_on<=#{Date.today.strftime("%Y-%m-%d")}&sys_created_by!=Eurostar_OpsRamp&stateIN1,2,3,10"
    @total_incident_current =  get_incidents(query)
    render partial: "open_tickets_by_category"
  end

  def auto_resolved_incidents
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = "sys_updated_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}ORresolved_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @total_incident_current =  get_incidents(query)
    render partial: "auto_resolved_incidents"
  end

  def resolution_automation_index
    incident_sla_table
    @labels,@start_date,@end_date,@graph_type = set_date_range(@type,@date_count)
    query = "resolved_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @total_incident_current =  get_incidents(query)
    render partial: "resolution_automation_index"
  end

  def open_change_request_by_status
    query = "updated_on<=#{Date.today.strftime("%Y-%m-%d")}&stateNOTIN3,4"
    @change_requests_data =  get_change_requests(query)
    render partial: "open_change_request_by_status"
  end

  def open_change_request_by_type
    query = "updated_on<=#{Date.today.strftime("%Y-%m-%d")}&stateNOTIN3,4"
    @change_requests_data =  get_change_requests(query)
    render partial: "open_change_request_by_type"
  end

  def customer_satisfaction
    type = 'monthly'
    date_count = 0
    if (params[:type].present?)
      type = params[:type]
    end
    if (params[:count].present?)
      date_count = params[:count]
    end
    @labels,@start_date,@end_date,@graph_type = set_date_range(type,date_count)
    query = "created_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    # raise "#{@start_date}-------#{@end_date}"
    @CSAT_data =  get_csat_count(query)
    # raise @CSAT_data.inspect
    # raise @CSAT_data.inspect
    render partial: "customer_satisfaction"
  end

  def customer_responses
    type = 'monthly'
    date_count = 0
    if (params[:type].present?)
      type = params[:type]
    end
    if (params[:count].present?)
      date_count = params[:count]
    end
    @labels,@start_date,@end_date,@graph_type = set_date_range(type,date_count)
    query = "created_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    # raise "#{@start_date}-------#{@end_date}"
    @CSAT_data =  get_csat_count(query)
    # raise @CSAT_data.inspect
    render partial: "customer_responses"
  end

  def customer_satisfaction_rate
    type = 'month'
    date_count = 3
    if (params[:type].present?)
      type = params[:type]
    end
    if (params[:count].present?)
      date_count = params[:count]
    end
    @labels,@start_date,@end_date,@graph_type = set_date_range(type,date_count)
    query = [
      {'name' => 'mr_sys_updated_on','value' => [@start_date,@end_date], 'operator' => 'between', 'type' => 'date', 'joinoperator' => 'none' }
    ]
    fields_required = 'mr_metric_definition,mr_sys_updated_on'
    @CSAT_data =  get_data(query,'u_csat_assessment_metric_user',fields_required)
    render partial: "customer_satisfaction_rate"
  end

  def set_type_and_count
    @type = 'day'
    @date_count = 5
    if (params[:type].present?)
      @type = params[:type]
    end

    if (params[:count].present?)
      @date_count = params[:count]
    end
  end


end
