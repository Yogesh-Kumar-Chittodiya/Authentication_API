class ErrorsController < ApplicationController
  def catch_404
    #render 
    # raise ActionController::RoutingError.new(params[:path])
  end
end
