class WeeklyreportsController < ReportsController
  def index
   
  end

  def incidents_closed_weekly

    incident_rest_resource = File.read("public/uploads/incidents.json")
    total_incidents = JSON.parse(incident_rest_resource)

    # Remove auto incidents
    total_incidents = total_incidents.select{|data| data['sys_created_by'].downcase.to_s != "eurostar_opsramp"}.map{|y|y}

    # if client is present
    if params[:customer].present?
      @customer = params[:customer]
    else
      @customer = "5c0f9654cc18a12b2096fdd1"
    end

    total_incidents = total_incidents.select{|device| device['client_id'] === @customer}.map{|y| y}


    total_incidents = total_incidents.select{|device| (device['closed_at'].present? && device['closed_at'].to_time.strftime("%Y-%m-%d")) === Date.today.strftime("%Y-%m-%d")}.map{|y| y}

    @total_files = total_incidents
  end
end
