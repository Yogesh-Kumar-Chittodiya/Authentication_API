class SapResponseMtdsController < ApplicationController
  before_action :set_sap_response_mtd, only: %i[ show edit update destroy ]

  # GET /sap_response_mtds or /sap_response_mtds.json
  def index
    @sap_response_dailies = SapResponseMtd.all.group_by(&:kpi_date).map{|y,value| {y => {"kpi_name" => value.map{|y| y.kpi_name + " : " + y.kpi_value + " - " + y.kpi_rating}}}}
    @sap_response_dailies = @sap_response_dailies.reduce Hash.new, :merge
  end

  # GET /sap_response_mtds/1 or /sap_response_mtds/1.json
  def show
  end

  # GET /sap_response_mtds/new
  def new
    @sap_response_mtd = SapResponseMtd.new
  end

  # GET /sap_response_mtds/1/edit
  def edit
  end

  def delete_respones
    @sap_response_daily = SapResponseMtd.where(:kpi_date => params[:date]).delete_all
    respond_to do |format|
      format.html { redirect_to sap_response_mtds_url, notice: "Sap response mtd was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  # POST /sap_response_mtds or /sap_response_mtds.json
  def create
    @sap_response_mtd = SapResponseMtd.new(sap_response_mtd_params)

    respond_to do |format|
      if @sap_response_mtd.save
        format.html { redirect_to sap_response_mtd_url(@sap_response_mtd), notice: "Sap response mtd was successfully created." }
        format.json { render :show, status: :created, location: @sap_response_mtd }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @sap_response_mtd.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /sap_response_mtds/1 or /sap_response_mtds/1.json
  def update
    respond_to do |format|
      if @sap_response_mtd.update(sap_response_mtd_params)
        format.html { redirect_to sap_response_mtd_url(@sap_response_mtd), notice: "Sap response mtd was successfully updated." }
        format.json { render :show, status: :ok, location: @sap_response_mtd }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @sap_response_mtd.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /sap_response_mtds/1 or /sap_response_mtds/1.json
  def destroy
    @sap_response_mtd.destroy

    respond_to do |format|
      format.html { redirect_to sap_response_mtds_url, notice: "Sap response mtd was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_sap_response_mtd
      @sap_response_mtd = SapResponseMtd.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def sap_response_mtd_params
      params.require(:sap_response_mtd).permit(:kpi_date, :kpi_time, :kpi_name, :kpi_value, :kpi_rating)
    end
end
