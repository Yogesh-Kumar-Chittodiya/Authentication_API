class OpsrampWidgetsController < ApplicationController

  include Opsramp

  #<--DC Center, SAP and Non-SAP ----------------------------->
  def dc_center_sap_and_non_sap
    NonSapApplication.update_all(:sla_breached => false,:status => 'green')
    SapApplication.update_all(:sla_breached => false,:status => 'green')

    @data_array = []
    # dinogui response array
    @sap_responses = SapResponse.select('kpi_rating').where(:record_type => 'old')

    # START------------------------------------------------------>
    applications = NonSapApplication.all
    non_sap_applications_check(applications)
    non_sap_status = ''
    border_nonsap = ''
    applications.each do |app|
      if app.sla_breached || app.status == 'red'
        non_sap_status = 'red'
        border_nonsap = 'danger'
      elsif app.status == 'amber'
        border_nonsap = 'warning'
        non_sap_status = 'amber'
      else
        non_sap_status = 'green'
        border_nonsap = 'success'
      end
    end
    non_prod_devices = NonSapDevice.select('id').where(:device_type=>'non-prod').all.map{|p|p.id}
    non_avail = NonSapAvailability.select('currentState').where(:record_type=>'old').where(:non_sap_device_id => non_prod_devices).map{|p|p.currentState}

    if non_avail.include?"down"
      non_sap_status = 'amber'
      border_nonsap = 'warning'
    end
    @data_array.push({:status=>non_sap_status,:color=>border_nonsap ,:title=> 'System Availability (Non-SAP)',:url=>system_availability_non_sap_opsramp_reports_path,:icon=>'database' })
    # ------------------END OF NON SAP AVAILABILITY-------------->


    #system_performance_non_sap
    prod_devices = NonSapDevice.select('id').where(:device_type=>'prod').all.map{|p|p.id}
    non_sap_cpu = NonSapPerformance.select('usage').where(:record_type=>'old').where(:non_sap_device_id => prod_devices).map{|p|p.usage}
    @non_sap_status = []
    @non_sap_color = []
    non_sap_cpu.each do |non_sap|
      if (non_sap['cpu'] >= 90.0) or (non_sap['memory'] >= 90.0)
        @non_sap_status.push('red')
        @non_sap_color.push('danger')
      elsif (non_sap['cpu'] >= 80.0) or (non_sap['memory'] >= 80.0)
        @non_sap_status.push('amber')
        @non_sap_color.push('warning')
      else
        @non_sap_status.push('green')
        @non_sap_color.push('success')
      end
    end

    if @non_sap_status.include?('red')
      status = 'red'
      color = 'danger'
    elsif @non_sap_status.include?('amber')
      status = 'amber'
      color = 'warning'
    else
      status = 'green'
      color = 'success'
    end
    system_performance_non_sap = {:color=>color,:status=>status, :title=> 'System Performance (Non-SAP)',:url=>system_performance_non_sap_opsramp_reports_path,:icon=>'dashboard' }
    @data_array.push(system_performance_non_sap)
    render partial: "dc_center_sap_and_non_sap"
  end
  # end

  #<--System Operations, Network and End User Services ---------->
  def system_op_network_and_end_user
    @data_array = []

    # Regional Infrastructure – System Availability
    local_system_availability
    # end----------------------------------------->

    # Regional Infrastructure – Network Availability
    local_network_availability
    # end----------------------------------------->


    # 0365 availability
    o365_data = O365Availability.where(:record_type => 'old').all
    service_amber = o365_data.reject{|avail| avail.today_value == 'ServiceOperational'}
    if service_amber.present?
      border_success = '#ffbf00'
      color = 'warning'
    else
      border_success = 'green'
      color = 'success'
    end
    o365_availability = { :color=>color,:status=>border_success, :title=> 'O365 Status',:icon=>'envelope', :url=>o365_availability_opsramp_reports_path }
    @data_array.push(o365_availability)
    render partial: "system_op_network_and_end_user"
  end
  # end

  #<----------IT Security---------------------->
  def it_security
    # manual_avail = ManualAvailability.last
    @data_array = []
    # datcenter patch management status
    dc_patch_management = {:color=>'warning',:status=>'#ffbf00', :title=> 'Data Center - Patch Management Status',:icon=>'clipboard',:url=>dc_patch_management_opsramp_reports_path }
    @data_array.push(dc_patch_management)

    # Network availability
    local_patch_management = {:color=>'danger',:status=>'red', :title=> 'Regional - Patch Management Status',:icon=>'clipboard',:url=>local_patch_management_opsramp_reports_path }
    @data_array.push(local_patch_management)

    # critical security alert availability
    critical_alerts = Incident.where(:u_alert_type => 'Critical').where(:correlation_display => 'BluSapphire').where.not(:incident_state => ['Closed','Resolved','Cancelled']).all
    if critical_alerts.present?
      count = critical_alerts.count
      color = 'warning'
      status = '#ffbf00'
    else
      count = 0
      color = 'success'
      status = 'green'
    end
    @critical_security_alerts = {:color=>color,:status=>status, :title=> 'Critical Security Alerts',:icon=>'exclamation-circle', :url=>critical_security_alerts_service_now_reports_path,:availability=>count}

    render partial: "it_security"
  end

  def export_sap_data
    if params[:start].present? and params[:end].present?
     start_of_month = params[:start]
     end_of_month = params[:end]
    else
     start_of_month = (DateTime.now.beginning_of_month - 1.month).strftime("%Y-%m-%d")
     end_of_month = (DateTime.now.end_of_month - 1.month).strftime("%Y-%m-%d")
    end
    @items = SapResponse.where("kpi_date BETWEEN ? AND ?",start_of_month,end_of_month).all.group_by{|resp| resp[:kpi_name]}
    respond_to do |format|
    format.xlsx {
      response.headers[
        'Content-Disposition'
      ] = "attachment; filename=items.xlsx"
    }
    end
  end

  def export_non_sap_downtime
    start_of_month = DateTime.now.beginning_of_month.strftime("%Y-%m-%d")
    end_of_month = DateTime.now.end_of_month.strftime("%Y-%m-%d")
    @non_sap_downtimes = NonSapDevice.includes(:non_sap_downtimes).where("non_sap_downtimes.downtime_date BETWEEN ? AND ?",start_of_month,end_of_month).references(:non_sap_downtimes)
    respond_to do |format|
    format.xlsx {
      response.headers[
        'Content-Disposition'
      ] = "attachment; filename=non_sap_downtime.xlsx"
    }
    end
  end

  def local_system_availability
    # Regional Infrastructure – System Availability
    local_system_status = 'green'
    local_system_border = 'success'
    critical_devices = CriticalDevice.select('ip_address').all.map{|crt|crt.ip_address}
    opsramp_devices = OpsrampDevice.where(:ip_address => critical_devices).where(:device_type => ["Server","Linux","Windows","VMware"]).includes(:opsramp_device_availabilities).where("opsramp_device_availabilities.record_type = ?",'old').references(:opsramp_device_availabilities).all
    opsramp_availabilities = opsramp_devices.map{|loc| loc.opsramp_device_availabilities[0]["currentState"]}

    # Solarwind Devices
    solarwind_devices = SolarwindDevice.where("DataCenter != ?",'Thailand DC').where(:IPAddress => critical_devices).map{|dev| dev.NodeID}
    solarwind_availabilities = SolarwindDeviceAvailability.where(:NodeID => solarwind_devices).where(:record_type => 'old').map{|avail| ((avail.AvailabilityToday == "0.0") || (avail.AvailabilityToday == "0")) ? "down" : "up"}

    # check for any down device
    state_array = opsramp_availabilities + solarwind_availabilities
    if state_array.include? ("down")
      local_system_status = 'amber'
      local_system_border = 'warning'
    else
      local_system_status = 'green'
      local_system_border = 'success'
    end

    @data_array.push({:status=>local_system_status,:color=>local_system_border ,:title=> 'Local – System Availability',:url=>local_system_availability_opsramp_reports_path,:icon=>'database' })
    # end
  end

  def local_network_availability
    local_network_status = 'green'
    local_network_border = 'success'

    solarwind_interfaces = SolarwindInterface.where("Interface_Details = ? OR MPLS_Details = ?",nil,nil).map{|inter| inter.InterfaceID}
    state_array = SolarwindInterfaceAvailability.where(:record_type=>'old').where(:InterfaceID => solarwind_interfaces).map{|inter| ((inter.AvailabilityToday == "0.0") || (avail.AvailabilityToday == "0")) ? "down" : "up"}

    if state_array.include? ("down")
      local_network_status = 'amber'
      local_network_border = 'warning'
    else
      local_network_status = 'green'
      local_network_border = 'success'
    end
    @data_array.push({:status=>local_network_status,:color=>local_network_border ,:title=> 'Network - Availability',:url=>local_network_availability_opsramp_reports_path,:icon=>'wifi' })
  end

  #  Dc Center New Widget
  def dc_sap_non_sap
    NonSapApplication.update_all(:sla_breached => false,:status => 'green')
    SapApplication.update_all(:sla_breached => false,:status => 'green')
    @non_sap_devices = NonSapDevice.where(:device_type => 'prod').all
    @data_array = []

    # System Performance SAP
    @sap_responses = SapResponse.select('kpi_rating').where(:record_type => 'old')
    # End

    # System Availability SAP
    sap_applications = SapApplication.all
    sap_check(sap_applications)
    sap_status = ''
    border_sap = ''
    sap_applications.each do |app|
      if app.sla_breached || app.status == 'red'
        sap_status = 'red'
        border_sap = 'danger'
      elsif app.status == 'amber'
        sap_status = 'amber'
        border_sap = 'warning'
      else
        sap_status = 'green'
        border_sap = 'success'
      end
    end
    data = {:status=>sap_status,:color=>border_sap, :title=> 'System Availability (SAP)',:url=>system_availability_sap_devices_opsramp_reports_path,:icon=>'database' }
    @data_array.push(data)
    # END

    # System Availability NON SAP
    applications = NonSapApplication.all
    non_sap_check(applications)
    non_sap_status = ''
    border_nonsap = ''
    applications.each do |app|
      if app.sla_breached || app.status == 'red'
        non_sap_status = 'red'
        border_nonsap = 'danger'
      elsif app.status == 'amber'
        border_nonsap = 'warning'
        non_sap_status = 'amber'
      else
        non_sap_status = 'green'
        border_nonsap = 'success'
      end
    end
    non_prod_devices = NonSapDevice.where(:device_type=>'non-prod').pluck(:host_name)
    non_avail = DcDeviceAvailability.where("lower(NodeName) IN (?) AND record_type = ?",non_prod_devices,'old').pluck(:Status)
    if non_avail.include? ("down")
      non_sap_status = 'amber'
      border_nonsap = 'warning'
    end
    @data_array.push({:status=>non_sap_status,:color=>border_nonsap ,:title=> 'System Availability (Non-SAP)',:url=>system_availability_non_sap_devices_opsramp_reports_path,:icon=>'database' })
    # END ------------------------->

    # System Performance Non Sap
    devices_with_utilization = DcDeviceUtilization.where("lower(node_name) IN (?) AND record_type = ?",non_prod_devices,'old').pluck(:memory_percent,:cpu_percent)
    non_sap_status = []
    non_sap_color = []
    devices_with_utilization.each do |non_sap|
      if (non_sap[0].to_f >= 90.0) or (non_sap[1].to_f >= 90.0)
        non_sap_status.push('red')
        non_sap_color.push('danger')
      elsif (non_sap[0].to_f >= 80.0) or (non_sap[1].to_f >= 80.0)
        non_sap_status.push('amber')
        non_sap_color.push('warning')
      else
        non_sap_status.push('green')
        non_sap_color.push('success')
      end
    end
    if non_sap_status.include?('red')
      status = 'red'
      color = 'danger'
    elsif non_sap_status.include?('amber')
      status = 'amber'
      color = 'warning'
    else
      status = 'green'
      color = 'success'
    end
    @data_array.push({:color=>color,:status=>status, :title=> 'System Performance (Non-SAP)',:url=>non_sap_performance_opsramp_reports_path,:icon=>'dashboard' })
    render partial: "dc_sap_non_sap"
  end

  # new OpsrampWidgetsController
  def sap_application_availability
    @bar_data = [
      { "name" => "Availability (%)" , "data" => [100,100,100,100,100],"type" => 'column'},
    ]
    @bar_labels = ['BW Application','ECC Application','FIORI Application','GRC Application','HCM Application']
    render partial: "sap_application_availability"
  end

  def sap_response_status
    @bar_data = [
      { "name" => "Response (ms)" , "data" => [171,51,20,15,89],"type" => 'column'},
    ]
    @bar_labels = ['BW Application','ECC Application','FIORI Application','GRC Application','HCM Application']
    render partial: "sap_response_status"
  end

  def inventory
    devices = SolarwindDevice.where(:IsServer => true).pluck(:Status)
    @data = [{"name" => "UP" , "y" => devices.count("1"), "color" => 'green'},{"name" => "DOWN" , "y" => devices.count("2"),"color" => "red"},{"name" => "DEGRADED" , "y" => devices.count("14")}]
    render partial: "inventory"
  end
end
