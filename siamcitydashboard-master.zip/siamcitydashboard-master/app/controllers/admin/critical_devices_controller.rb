class Admin::CriticalDevicesController < ApplicationController
  before_action :find_critical_device , :only=> [:edit, :update, :destroy]

  def index
    @critical_devices = CriticalDevice.order(created_at: :desc).all
  end

  def new
    @critical_device = CriticalDevice.new
    @url = admin_critical_devices_path
  end

  def create
    @critical_device= CriticalDevice.new(critical_device_params)
    @critical_device.is_delete = true
    if @critical_device.save
      redirect_to admin_critical_devices_path
    else
      @url= admin_critical_devices_path
      render :new
    end     
  end

  def edit
    @url= admin_critical_device_path
  end
  
  def update
    if @critical_device.update(critical_device_params)
      redirect_to admin_critical_devices_path
    else
      @url = admin_critical_device_path
      render "edit"
    end
  end

  def destroy
    if @critical_device.is_delete
      @critical_device.update(is_delete: false)
    else
      @critical_device.update(is_delete: true)
    end
    
    redirect_to admin_critical_devices_path
  end

  def upload
    @critical_device = CriticalDevice.new
  end

  def excel_upload
    @errors = []
    spreadsheets = []
    # raise params["file"].inspect
    if params[:file].present? && !params[:file].nil?
      read_file = params[:file]
      spreadsheet = case File.extname(read_file.original_filename)
                    when ".xls" then Roo::Excel.new(read_file.path, nil, :ignore)
                    when ".xlsx" then Roo::Excelx.new(read_file.path)
                    else @errors.push("Unknown file type: #{read_file.original_filename}")
                    end
      spreadsheet.each_with_pagename do |name,_sheet|
        landscape = name
        records = []
        header = _sheet.row(1)
        (2.._sheet.last_row).map do |i|
          row = Hash[[header, _sheet.row(i)].transpose]
          if row.present?
            if row["IP Address"].present?
              check_device = CriticalDevice.where(:ip_address => row["IP Address"]).first
              if check_device.present?
                check_device.update(:ip_address => row["IP Address"],:host_name => row["HostName"],:logical_name => row["Logical Name"],:server_type => row["Server Type"],:vm_cluster => row["VM cluster"],:device_type => row["Device Type"],:priority => row["Priority"],:location => row["Site"],:landscape => landscape)
              else
                _device = CriticalDevice.create(:ip_address => row["IP Address"],:host_name => row["HostName"],:logical_name => row["Logical Name"],:server_type => row["Server Type"],:vm_cluster => row["VM cluster"],:device_type => row["Device Type"],:priority => row["Priority"],:location => row["Site"],:landscape => landscape)
              end
            end
          end
        end
      end
      redirect_to admin_critical_devices_path
    else
      redirect_to upload_admin_critical_devices_path
    end
  end
  
  private

  def find_critical_device
    @critical_device = CriticalDevice.find_by(:id=>params[:id])
  end
  def critical_device_params
    params.require(:critical_device).permit(:ip_address,:host_name, :logical_name, :server_type, :vm_cluster,:landscape,:location, :device_type,:priority)
  end
end
