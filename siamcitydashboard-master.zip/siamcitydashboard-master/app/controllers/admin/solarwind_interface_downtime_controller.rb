class Admin::SolarwindInterfaceDowntimeController < ApplicationController
  before_action :set_data
  before_action :set_interface, only: [:edit,:update,:show,:destroy]
  def index
    @downtimes_interface = SolarwindInterfaceDowntime.order(created_at: :desc).where(is_delete: false, is_delete: nil)
  end

  def new
    @downtime_interface = SolarwindInterfaceDowntime.new
    @url = admin_solarwind_interface_downtime_index_path
  end

  def edit
    @downtime_interface = SolarwindInterfaceDowntime.find_by(:id=>params[:id])
    @hosts = SolarwindInterface.all
    @url= admin_solarwind_interface_downtime_path
  end

  def update
    @downtime_interface = SolarwindInterfaceDowntime.find_by(:id=>params[:id])
    @hosts = SolarwindInterface.all
    params[:solarwind_interface_downtime][:DownEventTime] = DateTime.parse(params[:solarwind_interface_downtime][:DownEventTime])#.strftime("%y-%e-%m %H:%M")
    if @downtime_interface.update(solar_wind_interface_params)
      redirect_to admin_solarwind_interface_downtime_index_path
    else
      @url= admin_solarwind_interface_downtime_path
      render :edit
    end
  end

  def create
     @solarwind_interface = SolarwindInterface.find_by(id: params[:mpls_interface].to_i)
    if @solarwind_interface.present?
      if @solarwind_interface.MPLS_Details.present?
        params[:solarwind_interface_downtime][:MPLS_Details] = @solarwind_interface.MPLS_Details
      else
        params[:solarwind_interface_downtime][:Interface_Details] = @solarwind_interface.Interface_Details
      end
      params[:solarwind_interface_downtime][:NodeID] = @solarwind_interface.NodeID
      params[:solarwind_interface_downtime][:InterfaceID] = @solarwind_interface.InterfaceID
      params[:solarwind_interface_downtime][:FullName] = @solarwind_interface.FullName
      params[:solarwind_interface_downtime][:StatusLED] = "Up.gif"
      params[:solarwind_interface_downtime][:DataCenter] = @solarwind_interface.DataCenter
      params[:solarwind_interface_downtime][:Message] = @solarwind_interface.Caption + " Down"
      params[:solarwind_interface_downtime][:DownEventTime] = DateTime.parse(params[:solarwind_interface_downtime][:DownEventTime]) - 7.hours
    end
    @downtime_interface = SolarwindInterfaceDowntime.new(solar_wind_interface_params)
    if @downtime_interface.save
      redirect_to admin_solarwind_interface_downtime_index_path
    else
      @url= admin_solarwind_interface_downtime_index_path
      render :new
  end
  end
  def destroy
    downtime = SolarwindInterfaceDowntime.find_by(id: params[:id].to_i)
    if downtime.update(is_delete: true)
      redirect_to admin_solarwind_interface_downtime_index_path
    end
  end

  private
    def solar_wind_interface_params
      params.require(:solarwind_interface_downtime).permit(:StatusLED,:MPLS_Details,:Interface_Details,:DataCenter, :Message, :DownEventTime, :FullName, :OutageDurationInSeconds, :created_month, :remarks, :created_year, :NodeID, :isremoved )
    end
    def set_interface
      @user = SolarwindInterfaceDowntime.find(params[:id])
    end

    def set_data
      @months = {'january' => 'January','febuary' => 'February','march' => 'March','april' => 'April','may' => 'May', 'june' => 'June', 'july' => 'July', 'August' => 'August', 'september' => 'September', 'october' => 'October', 'november' => 'November', 'december' => 'December'}
      @years = {'2020'=> '2020', '2021' => '2021', '2022' => '2022', '2023' => '2023', '2024' => '2024', '2025' => '2025'}
      @interface_details = SolarwindInterface.where.not(interface_details: nil).pluck(:interface_details, :id)
      @mpls_details = SolarwindInterface.where.not(mpls_details: nil).pluck(:mpls_details, :id)
      @all_details = @interface_details + @mpls_details
    end
end
