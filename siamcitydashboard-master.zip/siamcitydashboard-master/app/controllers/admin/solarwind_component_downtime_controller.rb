class Admin::SolarwindComponentDowntimeController < ApplicationController
  before_action :set_data
  def index
    @downtimes = SolarwindComponentDowntime.order(created_at: :desc).where(is_delete: false, is_delete: nil)
  end

  def new
    @downtime_component = SolarwindComponentDowntime.new
    @url = admin_solarwind_component_downtime_index_path
  end

  def edit
    @downtime_component = SolarwindComponentDowntime.find_by(:id=>params[:id])
    @url= admin_solarwind_component_downtime_path
  end

  def update
    @downtime_component = SolarwindComponentDowntime.find_by(:id=>params[:id])
    params[:solarwind_component_downtime][:DownEventTime] = DateTime.parse(params[:solarwind_component_downtime][:DownEventTime])
    if @downtime_component.update(solar_wind_component_params)
      redirect_to admin_solarwind_component_downtime_index_path
    else
      @url= admin_solarwind_component_downtime_path
      render :edit
    end  
  end

  def create
		@sap_device = SapDevice.find_by(id: params[:solarwind_component_downtime][:ComponentName].to_i)
		if @sap_device.present?
			date_detail = DateTime.parse(params[:solarwind_component_downtime][:DownEventTime]) - 7.hours
			params[:solarwind_component_downtime][:DownEventTime] = date_detail
			params[:solarwind_component_downtime][:Message] = @sap_device.primary_app + " Down"
			params[:solarwind_component_downtime][:ComponentName] = @sap_device.primary_app
      params[:solarwind_component_downtime][:ComponentID] = @sap_device.component_id
		end	
		@downtime_component= SolarwindComponentDowntime.new(solar_wind_component_params)  
		if @downtime_component.save
			redirect_to admin_solarwind_component_downtime_index_path
		else
			@url= admin_solarwind_component_downtime_index_path
			render :new
		end
  end
  def destroy
    downtime_component = SolarwindComponentDowntime.find_by(id: params[:id].to_i)
    if downtime_component.update(is_delete: true)
      redirect_to admin_solarwind_component_downtime_index_path, notice: "Book not found"
    end
  end  

  private
    def solar_wind_component_params
      params.require(:solarwind_component_downtime).permit(:ComponentName,:ComponentID, :Message, :DownEventTime, :OutageDurationInSeconds, :created_month, :remarks, :created_year, :isremoved )
    end  

    def set_data
      @months = {'january' => 'January','febuary' => 'February','march' => 'March','april' => 'April','may' => 'May', 'june' => 'June', 'july' => 'July', 'August' => 'August', 'september' => 'September', 'october' => 'October', 'november' => 'November', 'december' => 'December'}
      @years = {'2020'=> '2020', '2021' => '2021', '2022' => '2022', '2023' => '2023', '2024' => '2024', '2025' => '2025'}
      names =  SapDevice.group(:primary_app)
      @component_names = names
    end  
end