class Admin::CustomerConfigurationsController < ApplicationController
    load_resource except: :create
    authorize_resource
  
	  def index
      if current_user.customer_id == 0
        @customer_configurations = CustomerConfiguration.all
      else
        @customer_configurations = customer.customer_configurations
      end
	  end
	  
	  def new
      @customer_configuration = CustomerConfiguration.new
      @url_path =  admin_customer_configurations_path 
	  end

	  def create
      @options = Array.new
      params[:options].each do |key,filter_data|
        option = Hash.new
        option[:key] = filter_data[:key]
        option[:value] = filter_data[:value]
        @options << option
      end
     
		 	@customer_configuration = CustomerConfiguration.new(customer_configuration_param)
      @customer_configuration.value = @options
      
		 	if @customer_configuration.save
        redirect_to admin_customer_configurations_path
      else
        @url_path =  admin_customer_configurations_path
				render :new
			end
	  end
	  
	  def edit
      @customer_configuration = CustomerConfiguration.where(:id=>params[:id]).first
      @url_path = admin_customer_configuration_path
	  end
	  
	  def update
      options = Array.new
      params[:options].each do |index,filter_data|
        option = Hash.new
        option[:key] = filter_data[:key]
        option[:value] = filter_data[:value]
        options << option
      end
      @customer_configuration = CustomerConfiguration.where(:id=>params[:id]).first
      if @customer_configuration.update(:value => options)
        redirect_to admin_customer_configurations_path
      else
        @url_path = admin_customer_configuration_path
        render :edit
      end
	  end 
    
	  def destroy
      @customer_configuration = CustomerConfiguration.where(:id=>params[:id]).first
      @customer_configuration.destroy
      redirect_to admin_customer_configurations_path
	  end
        
    private
    
	  def customer_configuration_param
      params.require(:customer_configuration).permit(:configuration_parameter_id, :customer_id, :value)
	  end
    
	  def edit_customer_configuration_param
      params.require(:customer_configuration).permit(:value)
	  end
    
end
