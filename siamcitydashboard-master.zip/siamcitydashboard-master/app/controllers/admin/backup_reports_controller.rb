class Admin::BackupReportsController < ApplicationController
  require 'roo'
  before_action :check_role
  # GET /admin/backup_reports
  # GET /admin/backup_reports.json
  def index
    @admin_backup_reports = Admin::BackupReport.all
  end

  # GET /admin/backup_reports/1
  # GET /admin/backup_reports/1.json
  def show
  end

  # GET /admin/backup_reports/new
  def new
    @url_path = admin_backup_reports_path
    @admin_backup_report = Admin::BackupReport.new
    @months = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @countries = ['Thailand-DC','Thailand','Sri Lanka','Vietnam','Indonesia','Bangladesh']
    @years = ["2020","2021","2022","2023","2024","2025"]
  end

  # GET /admin/backup_reports/1/edit
  def edit
  end

  # POST /admin/backup_reports
  # POST /admin/backup_reports.json
  def create
    location = params[:country]
    month = params[:month]
    year = params[:year]
    report_check = Admin::BackupReport.where("month = ? AND created_year = ? AND country = ?",month,year,location).first
    if report_check.present?
      backup_report= report_check
    else
      backup_report = Admin::BackupReport.new
    end
    @errors = []
    spreadsheets = []
    params[:file].each do |file|
      read_file = file[1]
      spreadsheet = case File.extname(read_file.original_filename)
                    when ".xls" then Roo::Excel.new(read_file.path, nil, :ignore)
                    when ".xlsx" then Roo::Excelx.new(read_file.path)
                    else @errors.push("Unknown file type: #{read_file.original_filename}")
                    end
      records = load_imported_items(spreadsheet)
      backup_report.country = location
      backup_report.month = month.downcase
      backup_report.created_year = year
      backup_report.data = records
      backup_report.save
    end
    @url_path = admin_backup_reports_path
    @months = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @countries = ['Thailand-DC','Thailand','Sri Lanka','Vietnam','Indonesia','Bangladesh']
    @years = ["2020","2021","2022","2023","2024","2025"]
    @admin_backup_report = Admin::BackupReport.new
    render :new
  end

  def update
    respond_to do |format|
      if @admin_backup_report.update(admin_backup_report_params)
        format.html { redirect_to @admin_backup_report, notice: 'Backup report was successfully updated.' }
        format.json { render :show, status: :ok, location: @admin_backup_report }
      else
        format.html { render :edit }
        format.json { render json: @admin_backup_report.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /admin/backup_reports/1
  # DELETE /admin/backup_reports/1.json
  def destroy
    @admin_backup_report.destroy
    respond_to do |format|
      format.html { redirect_to admin_backup_reports_url, notice: 'Backup report was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def load_imported_items(spreadsheet)
    records = []
    header = spreadsheet.row(2)
    (3..spreadsheet.last_row).map do |i|
      row = Hash[[header, spreadsheet.row(i)].transpose]
      records.push(row)
    end
    return records
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_admin_backup_report
      @admin_backup_report = Admin::BackupReport.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def admin_backup_report_params
      params.require(:admin_backup_report).permit(:country, :month, :data)
    end

    def check_role
      unless ['developer'].include?current_user.role
        redirect_to root_path
      end
    end
end
