class Admin::UsersController < ApplicationController

  before_action :check_role
  before_action :set_user, only: [:edit,:update,:show,:destroy]
  before_action :set_roles, only: [:new, :edit, :create, :update]


  def index
    if current_user.customer_id == 0
      @users = User.where("id != ?",current_user.id).all
    else
      @users = User.where("id != ? and customer_id = ?",current_user.id,current_user.customer_id).all
    end
  end

  def new
    @user = User.new
    @url = admin_users_path
  end

  def create
    @user = User.new(users_param)
    if @user.save
      redirect_to admin_users_path
    else
      @url = admin_users_path
      render :new
    end
  end

  def edit
    @url = admin_user_path
  end

  def update
    if @user.update(users_param)
      redirect_to admin_users_path
    else
      @url = admin_user_path
      render :edit
    end
  end

  def customer_wise
    customer = params[:dashboard][:customer]
    @users = Hash.new
    @users = User.select(:email, :name, :id).where(:customer_id=>customer.id).all
    respond_to do |format|
      format.json { render :customer_wise }
    end
  end

  def destroy
    if @user.present?
      @user.delete
    end
    @url = admin_users_path
  end

  private

  def users_param
    if (params[:id].present?)
      if (params[:user][:password].present?)
        params.require(:user).permit(:email,:name,:role,:customer_id,:password,:password_confirmation)
      else
        params.require(:user).permit(:email,:name,:role,:customer_id)
      end
    else
      params.require(:user).permit(:email,:name,:role,:customer_id,:password,:password_confirmation)
    end
  end

  def set_user
    @user = User.find(params[:id])
  end

  def set_roles
    @roles = {'superadmin' => 'Super Admin','end_user' => 'End user','downtime_user' => 'Downtime User','servicedesk_user' => 'ServiceDesk User','coforge_admin' => 'Coforge Admin','coforge_read' => 'Coforge (Read Only)'}
    if current_user.role.to_s != "superadmin"
      @roles.delete("superadmin")
    end
  end

  def check_role
    unless ['developer'].include?current_user.role
      redirect_to root_path
    end
  end
end
