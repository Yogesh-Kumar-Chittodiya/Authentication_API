class Admin::DowntimeController < ApplicationController

  before_action :set_month,:check_role
  def index
    if params.present? && params[:type].present?
      @type = params[:type]
      critical_devices = CriticalDevice.select('ip_address').all.map{|crt|crt.ip_address}
      case params[:type]
        # SAP DC DOwntime
      when 'sap_dc_downtime'
        @title = 'SAP Systems Downtimes'
        host_names = ['CI URLMSG Srv URL','CI URLMSG - HBP/BW','CI URLMSG - HRP/HCM','PIP - F5 Loadbalancer URL','ADP URL','FIP CI','GRP CI','BOP URL','SPP ABAP URL']
        sap_devices = SapDevice.where(:host_name => host_names).all
        @downtime_data = SapDowntime.where(:sap_device_id => sap_devices).group_by{|down| down[:sap_device_id]}
        @title = 'System Availability ( SAP )'

        # NON SAP DC
      when 'non_sap_dc_downtime'
        @title = 'System Availability ( NON - SAP )'
        @query_display = {}
        non_sap_devices = NonSapDevice.where(:device_type => 'prod').all
        @non_sap_downtime_month = NonSapDowntime.includes(:non_sap_device).where(:non_sap_device_id => non_sap_devices).all.group_by{|down| down[:non_sap_device_id]}.sort
        # END

        # Thailand Downtime
      when 'thailand_downtime'
        @app_data = SolarwindDeviceDowntime.where(:DataCenter => 'Thailand').where(:IPAddress => critical_devices).group_by{|interface| interface.NodeID}
        @title = 'System Downtime - Thailand'
        @query_display = {}
        # End

        # Vietnam Downtime
      when 'vietnam_downtime'
        @app_data = SolarwindDeviceDowntime.where(:DataCenter => 'Vietnam').where(:IPAddress => critical_devices).group_by{|interface| interface.NodeID}
        @title = 'System Downtime - Vietnam'
        @query_display = {}
        # End

        # Bangladesh and Indonesia
      when 'bangladesh_indonesia_downtime'
        @app_data = SolarwindDeviceDowntime.where(:DataCenter => 'Sri Lanka').where(:IPAddress => critical_devices).group_by{|interface| interface.NodeID}

        opsramp_devices = OpsrampDevice.where(:device_type => ["Server","Linux","Windows","VMware"]).all
        @device_downtime_month = OpsrampDeviceDowntime.where(:opsramp_device_id => opsramp_devices).all.group_by{|down| down[:opsramp_device_id]}
        @opsramp_devices_critical = opsramp_devices.where(:ip_address => critical_devices)

        @title = 'System Downtime - Sri Lanka,Bangladesh,Indonesia'
        @format = "%"
        @query_display = {}
        # end

        # internet downtime
      when 'internet_downtime'
        downtime_of_devices = SolarwindInterfaceDowntime.where(:MPLS_Details => nil).all
        if downtime_of_devices.count > 0
          @downtime_data_device = downtime_of_devices.group_by{|interface| interface.InterfaceID}
        else
          @downtime_data_device = []
        end
        @title = 'Internet Link Downtime'
        @query_display = {}
        # end of internet downtime

        # MPLS Downtime
      when 'mpls_downtime'
        @downtime_data_device = SolarwindInterfaceDowntime.where(:Interface_Details => nil).group_by{|interface| interface.InterfaceID}
        @title = 'Network MPLS Downtime'
        @query_display = {}
      end
      # END
    else
      @types = [
          {'name' => 'SAP Systems', 'url' => 'downtimes/sap_dc_downtime'},
          {'name' => 'Non SAP Systems', 'url' => 'downtimes/non_sap_dc_downtime'},
          {'name' => 'Thailand Systems', 'url' => 'downtimes/thailand_downtime'},
          {'name' => 'Vietnam Systems', 'url' => 'downtimes/vietnam_downtime'},
          {'name' => 'Sri Lanka,bangladesh & Indonesia Systems', 'url' => 'downtimes/bangladesh_indonesia_downtime'},
          {'name' => 'Internet Systems', 'url' => 'downtimes/internet_downtime'},
          {'name' => 'MPLS Systems', 'url' => 'downtimes/mpls_downtime'},
         ]
    end
  end

  def set_month
    month_hash = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    if params.present? && params['month'].present?
      @month = params['month']
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(2020,month_number,1)
    elsif params.present? && params[:query_string].present? && params[:query_string][:month].present?
      @month = params[:query_string][:month]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(2020,month_number,1)
    else
      month_d = (Time.current.beginning_of_month)
      @month = month_hash[month_d.month - 1]
    end
    @month_date = month_d.strftime("%Y-%m-%d")
    @month_end = month_d.end_of_month.strftime("%Y-%m-%d")
    @diff = month_d.end_of_month.to_i - month_d.to_i
    @last_three_months = []
    (1..3).each do |t|
      @last_three_months.push((Time.now.utc - (3-t).month).strftime("%B").downcase)
    end
    @last_three_months.delete('april')
    @last_three_months.delete('may')
    @groups_niit = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).map{|group| group.group_name}
  end

  private
  def check_role
    unless ['developer'].include?current_user.role
      redirect_to root_path
    end
  end

end
