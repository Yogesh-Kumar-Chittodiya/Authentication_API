class Admin::DashboardController < ApplicationController
    load_resource :find_by => :slug, except: :create
    authorize_resource
  
	  def index
      @widgets = []
      if current_user.customer_id == 0
        @dashboards = Dashboard.all 
      else
        @dashboards = Dashboard.where(:customer_id => current_user.customer_id)
      end
      @dashboards.each do |dash|
        @widgets.push(dash.widgets.select(:name).map{|widg| widg.name})
      end
	  end
	  
	  def new
      @dashboard = Dashboard.new
      @url_path =  admin_dashboard_index_path 
      @widgets = Hash.new
      Widget.select(:name, :id).all.map{|c| @widgets[c.id] = c.name}
      @remaining_widgets = @widgets
	  end
	  
	  def create
		 	@dashboard = Dashboard.new(dashboard_param)
      sort_order = 1
      
			params[:dashboard][:widgets].each do |widget_id|
				if !widget_id.empty?
					@dashboard.dashboard_widgets.build(:widget_id=>widget_id, :sort_order=>sort_order)
          sort_order = sort_order + 1
				end
			end if params[:dashboard][:widgets].present?
      
		 	if @dashboard.save
        redirect_to admin_dashboard_index_path
      else
        @url_path =  admin_dashboard_index_path
        @widgets = Hash.new
        Widget.select(:name, :id).all.map{|c| @widgets[c.id] = c.name}        
        @remaining_widgets = @widgets
				render :new
			end
	  end
	  
	  def edit
      @dashboard = Dashboard.friendly.find(params[:id])
      @url_path = admin_dashboard_path
      @widgets = Hash.new
      Widget.select(:name, :id).all.map{|c| @widgets[c.id] = c.name}
      .inspect
      @remaining_widgets = Hash.new
      @dashboard_widgets = Hash.new
      
      @dashboard.dashboard_widgets.order('sort_order asc').each do |d|
        @dashboard_widgets[d.widget_id] = d.widget.name
      end
      @widgets.each do |w,name|
        if !@dashboard.widget_ids.include?(w)
          @remaining_widgets[w] = name
        end
      end      
	  end
	  
	  def update
      @url_path = admin_dashboard_path
      @dashboard = Dashboard.friendly.find(params[:id])
      @dashboard.dashboard_widgets.destroy_all
      sort_order = 1
			params[:dashboard][:widgets].each do |widget_id|
				if !widget_id.empty?
					@dashboard.dashboard_widgets.build(:widget_id=>widget_id, :sort_order=>sort_order)
          sort_order = sort_order + 1
				end
			end if params[:dashboard][:widgets].present?

      if @dashboard.valid?
        @dashboard.update(dashboard_param)
        redirect_to admin_dashboard_index_path
      else
        @widgets = Hash.new
        @dashboard_widgets = Hash.new
        Widget.select(:name, :id).all.map{|c| @widgets[c.id] = c.name}
        @remaining_widgets = @widgets
        render :edit
      end
	  end 
    
	  def manage_users
      @dashboard = Dashboard.friendly.find(params[:id])

      @url_path = update_users_admin_dashboard_path
      
      @users = Hash.new
if @dashboard.customer_id == 0 or @dashboard.customer_id.nil?
      User.select(:email, :name, :id).all.map{|c| @users[c.id] = c.name}
else
      User.select(:email, :name, :id).where(:customer_id=>[0,@dashboard.customer_id]).map{|c| @users[c.id] = c.name}
end
      @dashboard_users = @dashboard.users

      @dashboard_users.each do |duser|
        if @users.key? duser.id
          @users.delete(duser.id)
        end
      end

      # raise @dashboard.users.inspect
	  end
    
	  def update_users
      @url_path = admin_dashboard_path
      @dashboard = Dashboard.friendly.find(params[:id])
            
      # @dashboard.dashboard_users.destroy_all
      
      params[:dashboard][:user_ids].each do |user_id|
				if !user_id.empty?
          check_user = User.where(:id=>user_id).first
          if check_user.present?
            if check_user.dashboard_users.where(:is_default=>1).present?
              @dashboard.dashboard_users.create(:user_id=>user_id, :is_default=>false)
            else
              @dashboard.dashboard_users.create(:user_id=>user_id, :is_default=>true)
            end
          end
				end
			end if params[:dashboard][:user_ids].present?

      redirect_to manage_users_admin_dashboard_path(@dashboard)
	  end

    def delete_users
      check_user = User.where(:id=>params[:user]).first
      @dashboard = Dashboard.where(:slug=>params[:id]).first
        if check_user.present?
          if check_user.dashboard_users.where(:dashboard_id=>@dashboard.id).present?
            check_user.dashboard_users.where(:dashboard_id=>@dashboard.id).destroy_all
          end
        end
        redirect_to manage_users_admin_dashboard_path(@dashboard)
    end 
    
	  def destroy
      @dashboard = Dashboard.friendly.find(params[:id])
      @dashboard.destroy
      redirect_to admin_dashboards_path
	  end
        
    private
    
	  def dashboard_param
      params.require(:dashboard).permit(:name, :customer_id,:is_active)
	  end
    
end
