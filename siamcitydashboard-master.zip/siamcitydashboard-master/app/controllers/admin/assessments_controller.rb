class Admin::AssessmentsController < ApplicationController
  before_action :set_month
  def index
    @disabled_months = []
    @assessments = Assessment.order(created_at: :desc).where("taken_on BETWEEN ? AND ?",@month_date,@month_end).paginate(:page => params[:page], :per_page => 50)
  end
  
  def destroy
    @assessment = Assessment.find_by(id: params[:id].to_i)
    @assessment.destroy
    redirect_to admin_assessments_path
  end
  
  def search
    if params[:search].blank?
      return @assessments = nil
    else
      parameter = params[:search].downcase
      @assessments = Assessment.search(parameter).paginate(:page => params[:page], :per_page => 50)
    end
  end
  
  private

  def set_month
    month_hash = ["January","February","March","April","May","June","July","August","September","October","November","December"]
    if params.present? && params['datepicker-search'].present?
      full_month = params['datepicker-search']
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    elsif params.present? && params[:query_string].present? && params[:query_string][:datepicker-search].present?
      full_month = params[:query_string][:datepicker-search]
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    else
      month_d = (Time.current.beginning_of_month - 1.month)
      @month = month_hash[month_d.month - 1]
      @year = month_d.year
    end
    @month_date = month_d.strftime("%Y-%m-%d")
    @month_end = month_d.end_of_month.strftime("%Y-%m-%d")
    @diff = month_d.end_of_month.to_i - month_d.to_i
    @last_three_months = []
    (1..6).each do |t|
      @last_three_months.push((Time.now.utc - (7-t).month).strftime("%B-%Y").downcase)
    end
    @groups_niit = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).map{|group| group.group_name}
  end
end
