class Admin::ManualAvailabilitiesController < ApplicationController
  authorize_resource
  before_action :check_role

  require 'roo'

  def index
    @files = DcPatchManagement.all
  end

  def new
    @manual_availability = ManualAvailability.new
    @url_path = admin_manual_availabilities_path
    @months = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @years = ["2020","2021","2022","2023","2024","2025"]
  end

  def create
    manual_availability_check = ManualAvailability.where(["created_at >= ? AND created_at <= ?", Date.today.beginning_of_day, Date.today.end_of_day]).first
    if manual_availability_check.present?
      manual_availability = manual_availability_check
    else
      manual_availability = ManualAvailability.new
    end
    @errors = []
    spreadsheets = []
    @month = params[:month]
    @year = params[:year]
    params[:file].each do |file|
      read_file = file[1]
      spreadsheet = case File.extname(read_file.original_filename)
        when ".csv" then Csv.new(read_file.path, nil, :ignore)
        when ".xls" then Roo::Excel.new(read_file.path, nil, :ignore)
        when ".xlsx" then Roo::Excelx.new(read_file.path)
        else @errors.push("Unknown file type: #{read_file.original_filename}")
        end
        records = load_imported_items(spreadsheet)
        unless records.empty?
          @status = ''
          @color = ''
          # DC PATCH------------------------------------------------>
          if file[0] == 'dc_patch'
            records.each do |record|
              if record['Overall Status (R/A/G)'].present?
                if record['Overall Status (R/A/G)'] == 'A'
                  @color = 'warning'
                  @status = 'amber'
                elsif record['Overall Status (R/A/G)'] == 'R'
                  @color = 'danger'
                  @status = 'red'
                else
                  @color = 'success'
                  @status = 'green'
                end
              end
              check_dc = DcPatchManagement.where("month = ? AND created_year = ? AND devices = ? ",@month,@year,record['Device Category']).first
              if check_dc.present?
                save_file_data = check_dc
              else
                save_file_data = DcPatchManagement.new
              end
              save_file_data.devices = record['Device Category']
              save_file_data.behind_patch = record['Behind 5 Patch']
              
              save_file_data.num_of_devices = record['No. of Devices']
              save_file_data.u_red = record['R']
              save_file_data.u_amber = record['A']
              save_file_data.u_green = record['G']
              save_file_data.remarks = record['Remarks']
              save_file_data.month = @month
              save_file_data.created_year = @year
              save_file_data.save
            end
            manual_availability.dc_patch_management_status = {"title" => 'Data Center - Patch Management Status','color' => @color,'status'=> @status,'link'=> true}
          end
          manual_availability.critical_security_alerts = {"title" => 'Critical Security Alerts','status' => 'green','color'=> 'success', 'link'=> false}
          manual_availability.save
          # ---------------------------------END--------------------------->
        end
    end
    redirect_to admin_manual_availabilities_path
  end

  def delete_dc_patch
    patch_file = DcPatchManagement.find(params[:patch_id])
    if patch_file.present?
      patch_file.delete
    end
    redirect_to admin_manual_availabilities_path
  end

  def show

  end

  private

  def load_imported_items(spreadsheet)
    records = []
    header = spreadsheet.row(2)
    (3..spreadsheet.last_row).map do |i|
      row = Hash[[header, spreadsheet.row(i)].transpose]
      records.push(row)
    end
    return records
  end

  def imported_items
    @imported_items ||= load_imported_items
  end

  def save
    if imported_items.map(&:valid?).all?
      imported_items.each(&:save!)
      true
    else
      imported_items.each_with_index do |item, index|
        item.errors.full_messages.each do |msg|
          errors.add :base, "Row #{index + 6}: #{msg}"
        end
      end
      false
    end
  end

  def check_role
    unless ['developer'].include?current_user.role
      redirect_to root_path
    end
  end

end
