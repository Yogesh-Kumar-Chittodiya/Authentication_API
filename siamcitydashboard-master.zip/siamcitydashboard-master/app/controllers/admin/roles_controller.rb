class Admin::RolesController < ApplicationController
  before_action :check_role
  def index
    role = Role.new()
    @roles = Role.all
  end

  def new
    @role = Role.new()
    @url_path = admin_roles_path
  end

  def edit
    @role = Role.where(:id=>params[:id]).first
    @url_path = admin_role_path
  end

  def update
     @role = Role.where(:id=>params[:id]).first
	 #raise params.inspect
	 @role.update(role_param)
      redirect_to admin_roles_path
  end

  def create
     @role = Role.new(role_param)
	 @role.save
     redirect_to admin_roles_path
  end

  def role_param
	params.require(:role).permit(:name, :file_name,
										 :is_active,
										 :size_type)
  end
  def check_role
    unless ['downtime_user','coforge_admin','developer'].include?current_user.role
      redirect_to root_path
    end
  end

end
