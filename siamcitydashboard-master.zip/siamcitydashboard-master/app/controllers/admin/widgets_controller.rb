class Admin::WidgetsController < ApplicationController
  load_and_authorize_resource except: :create
  
  def index
	widget = Widget.new()
  @widgets = Widget.all
  end
  
  def new
    @widget = Widget.new()
    @url_path = admin_widgets_path
  end
  
  def edit
    @widget = Widget.where(:id=>params[:id]).first
    @url_path = admin_widget_path
  end
  
  def update
    @filters = Array.new
    params[:widget][:filters].each do |filter_data|
      filter = Hash.new
      filter[:title] = filter_data[:title]
      filter[:type] = filter_data[:type]
      filter[:count] = filter_data[:count]
      @filters << filter
    end
    
    @widget = Widget.where(:id=>params[:id]).first
    @widget.filters = @filters
    if @widget.update(widget_param)
      redirect_to admin_widgets_path
    else
      @url_path = admin_widget_path
      render "edit"
    end
  end 
  
  def create
    authorize! :create, @model
    @filters = Array.new
    params[:widget][:filters].each do |filter_data|
      filter = Hash.new
      filter[:title] = filter_data[:title]
      filter[:type] = filter_data[:type]
      filter[:count] = filter_data[:count]
      @filters << filter
    end
    
    @widget = Widget.new(widget_param)
    @widget.filters = @filters
    if @widget.save
      redirect_to admin_widgets_path
    else
      @url_path = admin_widgets_path
      render "new"
    end
  end
  
  def widget_param
    params.require(:widget).permit(:name, :file_name,:is_active,:size_type,:module,:widget_type,:filters,:title,:options)
  end
end
