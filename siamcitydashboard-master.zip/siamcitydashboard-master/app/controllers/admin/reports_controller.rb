class Admin::ReportsController < ApplicationController
before_action :check_role
  def index
    @reports = Report.all
  end

  def new
    @report = Report.new()
    @url_path = admin_reports_path
  end

  def edit
    @report = Report.where(:id=>params[:id]).first
    @url_path = admin_report_path
  end

  def update
    @report = Report.where(:id=>params[:id]).first
   #raise params.inspect
   if @report.update(report_param)
     redirect_to admin_reports_path
   else
     @url_path =  admin_report_path
     render :edit
   end
  end

  def destroy
    @report = Report.find(params[:id])
    @report.destroy
    redirect_to admin_reports_path
  end

  def create
    params[:report][:customer_id] = current_user.customer_id
    @report = Report.new(report_param)
    if @report.save
      redirect_to admin_reports_path
    else
      @url_path =  admin_reports_path
      render :new
    end
  end



  private

  def report_param
  params.require(:report).permit(:title, :report_type,:tool,:link,:is_active,:customer_id)
  end
  def check_role
    unless ['downtime_user','coforge_admin','developer'].include?current_user.role
      redirect_to root_path
    end
  end
end
