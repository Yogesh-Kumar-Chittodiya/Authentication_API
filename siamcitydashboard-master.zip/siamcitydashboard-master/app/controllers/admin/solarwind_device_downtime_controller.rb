class Admin::SolarwindDeviceDowntimeController < ApplicationController

  before_action :set_data
  def index
    @downtimes = SolarwindDeviceDowntime.order(created_at: :desc).where(:is_delete => [false,nil])
  end

  def new
    @downtime = SolarwindDeviceDowntime.new
    @url = admin_solarwind_device_downtime_index_path
  end

  def edit
    @url= admin_solarwind_device_downtime_path
  end

  def update
    params[:solarwind_device_downtime][:DownEventTime] = DateTime.parse(params[:solarwind_device_downtime][:DownEventTime])#.strftime("%y-%e-%m %H:%M")
    if @downtime.update(solar_wind_params)
      redirect_to admin_solarwind_device_downtime_index_path
    else
      @url = admin_solarwind_device_downtime_path
      render "edit"
    end
  end

  def create
    @solarwind_device = SolarwindDevice.find_by(id: params[:solarwind_device_downtime][:Caption].to_i)
    if @solarwind_device.present?
      params[:solarwind_device_downtime][:NodeID] = @solarwind_device.NodeID
      params[:solarwind_device_downtime][:IPAddress] = @solarwind_device.IPAddress
      params[:solarwind_device_downtime][:Caption] = @solarwind_device.Caption
      params[:solarwind_device_downtime][:StatusLED] = "Up.gif"
      params[:solarwind_device_downtime][:DataCenter] = @solarwind_device.DataCenter
      params[:solarwind_device_downtime][:Devicetype] = @solarwind_device.MachineType
      params[:solarwind_device_downtime][:Message] = @solarwind_device.Caption + " Down"
      date_detail = DateTime.parse(params[:solarwind_device_downtime][:DownEventTime]) - 7.hours
      params[:solarwind_device_downtime][:DownEventTime] = date_detail
    end
    @downtime = SolarwindDeviceDowntime.new(solar_wind_params)
    if @downtime.save
      redirect_to admin_solarwind_device_downtime_index_path
    else
      @url= admin_solarwind_device_downtime_index_path
      render :new
    end
  end
  
  def destroy
    downtime = SolarwindDeviceDowntime.find_by(id: params[:id].to_i)
    if downtime.update(is_delete: true)
      redirect_to admin_solarwind_device_downtime_index_path, notice: "Book not found"
    end
  end

  private
    def solar_wind_params
      params.require(:solarwind_device_downtime).permit(:Caption,:IPAddress, :DataCenter,:Devicetype, :Message, :DownEventTime, :OutageDurationInSeconds, :created_month, :remarks, :created_year, :NodeID, :StatusLED, :isremoved )
    end
    def set_data
      @downtime = SolarwindDeviceDowntime.find_by(:id=>params[:id])
      @months = {'january' => 'January','febuary' => 'February','march' => 'March','april' => 'April','may' => 'May', 'june' => 'June', 'july' => 'July', 'August' => 'August', 'september' => 'September', 'october' => 'October', 'november' => 'November', 'december' => 'December'}
      @years = {'2020'=> '2020', '2021' => '2021', '2022' => '2022', '2023' => '2023', '2024' => '2024', '2025' => '2025'}
      @host_names = SolarwindDevice.all
    end
end
