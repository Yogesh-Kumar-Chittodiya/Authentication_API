class Admin::CustomersController < ApplicationController
  load_resource :find_by => :slug, except: :create
  authorize_resource

  before_action :set_tools, only: [:new, :edit, :create, :update]
  
  def index
    @customers = Customer.all
  end

  def new
    @tools_configuration = Hash.new
    @customer = Customer.new
    @url_path = admin_customers_path
  end

  def create
    @customer = Customer.new(customers_param)
    if @customer.save        
      url = "#{APP_CONFIG['data_fetch_url']}customers.json"
      return_data = RestClient.post url, {:customer => customers_param}.to_json, {content_type: :json, accept: :json}
      api_customer_id = JSON.parse(return_data)  
      @customer.api_customer_id = api_customer_id
      @customer.save
      redirect_to admin_customers_path
    else
      @url_path = admin_customers_path
      render :new
    end
  end

  def edit
    @url_path = admin_customer_path 
    @tools_configuration = @customer.tools_configuration
  end

  def update
    if @customer.update(customers_param)
      url = "#{APP_CONFIG['data_fetch_url']}customers.json"
      if @customer.api_customer_id.present?
        return_data = RestClient.post url, {:customer_id=>@customer.api_customer_id, :customer => customers_param}.to_json, {content_type: :json, accept: :json}
      else
        return_data = RestClient.post url, {:customer => customers_param}.to_json, {content_type: :json, accept: :json}
        api_customer_id = JSON.parse(return_data)
        @customer.api_customer_id = api_customer_id
        @customer.save
      end
      redirect_to admin_customers_path
    else
      @tools_configuration = @customer.tools_configuration
      @url_path = admin_customer_path
      render :edit
    end
  end

  private

  def customers_param
    params.require(:customer).permit(:name,:is_active,:logo, :tools_configuration => [
      :service_now => [:enabled, :customer_id],
      :opsramp => [:enabled, :msp_id, :client_id],
      :snow => [:enabled, :customer_id]
    ])
  end

  def set_tools
    @tools = APP_CONFIG['tools']
  end
end
