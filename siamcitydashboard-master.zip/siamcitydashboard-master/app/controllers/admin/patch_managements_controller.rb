class Admin::PatchManagementsController < ApplicationController
  require 'roo'
  before_action :set_admin_patch_management, only: [:show, :edit, :update, :destroy]
  before_action :check_role
  def index
    @admin_patch_managements = Admin::PatchManagement.all
    @dc_patch_managements = DcPatchManagement.all
  end

  def show
  end

  def new
    @admin_patch_management = Admin::PatchManagement.new
    @months = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @years = ['2020','2021','2022','2023','2024','2025'] 
 end

  def edit
    @months = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @years = ['2021','2022','2023','2024','2025']
  end

  def create
    @admin_patch_management = Admin::PatchManagement.new(admin_patch_management_params)
    respond_to do |format|
      if @admin_patch_management.save
        format.html { redirect_to @admin_patch_management, notice: 'Patch management was successfully created.' }
        format.json { render :show, status: :created, location: @admin_patch_management }
      else
        format.html { render :new }
        format.json { render json: @admin_patch_management.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @admin_patch_management.update(admin_patch_management_params)
        format.html { redirect_to @admin_patch_management, notice: 'Patch management was successfully updated.' }
        format.json { render :show, status: :ok, location: @admin_patch_management }
      else
        format.html { render :edit }
        format.json { render json: @admin_patch_management.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @admin_patch_management.destroy
    respond_to do |format|
      format.html { redirect_to admin_patch_managements_url, notice: 'Patch management was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def upload_multiple
    @admin_patch_management = Admin::PatchManagement.new
    @url_path = post_upload_admin_patch_managements_path
    @months = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @years = ["2020","2021","2022","2023","2024","2025"]
  end

  def post_upload
    month = params[:month]
    year = params[:year]
    @errors = []
    params[:file].each do |file|
      read_file = file[1]
      spreadsheet = case File.extname(read_file.original_filename)
                    when ".xls" then Roo::Excel.new(read_file.path, nil, :ignore)
                    when ".xlsx" then Roo::Excelx.new(read_file.path)
                    else @errors.push("Unknown file type: #{read_file.original_filename}")
                    end
      # raise spreadsheet.inspect
      spreadsheet.each_with_pagename do |name,sheet|
        records = load_imported_items(sheet)
        case name
        when 'Data Center'
          DcPatchManagement.where("month = ? AND created_year = ?",month,year).delete_all
          records.each do |rec|
            totaldevices = rec['Updated'] + rec['Pending'] + rec['End of Life'] +rec['Behind 5 Patch']
            newrec = DcPatchManagement.new(devices: rec['Device'],u_green: rec['Updated'],u_amber: rec['Pending'],u_red: rec['End of Life'],behind_patch: rec['Behind 5 Patch'],month: month,created_year: year,num_of_devices: totaldevices)
            newrec.save
          end
        when 'Thailand'
          Admin::PatchManagement.where("month = ? AND created_year = ? AND device LIKE ?",month,year,"%- TH%").delete_all
          records.each do |rec|
            totaldevices = rec['Updated'] + rec['Pending'] + rec['End of Life']
            dev = rec['Device'] + ' - TH'
            newrec = Admin::PatchManagement.new(device: dev,update_devices: rec['Updated'],update_pending_devices: rec['Pending'],end_of_life: rec['End of Life'],month: month,created_year: year,num_of_devices: totaldevices)
            newrec.save
          end
        when 'VNM'
          Admin::PatchManagement.where("month = ? AND created_year = ? AND device LIKE ?",month,year,"%- VN%").delete_all
          records.each do |rec|
            dev = rec['Device'] + ' - VN'
            totaldevices = rec['Updated'] + rec['Pending'] + rec['End of Life']
            newrec = Admin::PatchManagement.new(device: dev,update_devices: rec['Updated'],update_pending_devices: rec['Pending'],end_of_life: rec['End of Life'],month: month,created_year: year,num_of_devices: totaldevices)
            newrec.save
          end
        when 'LKA'
          Admin::PatchManagement.where("month = ? AND created_year = ? AND device LIKE ?",month,year,"%- LK%").delete_all
          records.each do |rec|
            dev = rec['Device'] + ' - LK'
            totaldevices = rec['Updated'] + rec['Pending'] + rec['End of Life']
            newrec = Admin::PatchManagement.new(device: dev,update_devices: rec['Updated'],update_pending_devices: rec['Pending'],end_of_life: rec['End of Life'],month: month,created_year: year,num_of_devices: totaldevices)
            newrec.save
          end
        when 'BD'
          Admin::PatchManagement.where("month = ? AND created_year = ? AND device LIKE ?",month,year,"%- BD%").delete_all
          records.each do |rec|
            dev = rec['Device'] + ' - BD'
            totaldevices = rec['Updated'] + rec['Pending'] + rec['End of Life']
            newrec = Admin::PatchManagement.new(device: dev,update_devices: rec['Updated'],update_pending_devices: rec['Pending'],end_of_life: rec['End of Life'],month: month,created_year: year,num_of_devices: totaldevices)
            newrec.save
          end
        when 'ID'
          Admin::PatchManagement.where("month = ? AND created_year = ? AND device LIKE ?",month,year,"%- ID%").delete_all
          records.each do |rec|
            dev = rec['Device'] + ' - ID'
            totaldevices = rec['Updated'] + rec['Pending'] + rec['End of Life']
            newrec = Admin::PatchManagement.new(device: dev,update_devices: rec['Updated'],update_pending_devices: rec['Pending'],end_of_life: rec['End of Life'],month: month,created_year: year,num_of_devices: totaldevices)
            newrec.save
          end
        end
      end
    end
    @url_path = admin_patch_managements_path
    @months = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @years = ["2020","2021","2022","2023","2024","2025"]
    @admin_patch_management = Admin::PatchManagement.new
    render :new
  end

  def load_imported_items(spreadsheet)
    records = []
    header = spreadsheet.row(1)
    (2..spreadsheet.last_row).map do |i|
      row = Hash[[header, spreadsheet.row(i)].transpose]
      records.push(row)
    end
    return records
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_admin_patch_management
      @admin_patch_management = Admin::PatchManagement.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def admin_patch_management_params
      params.require(:patch_management).permit(:device, :num_of_devices, :update_devices, :update_pending_devices,:remarks,:month,:year)
    end

    def check_role
      unless ['developer'].include?current_user.role
        redirect_to root_path
      end
    end
end
