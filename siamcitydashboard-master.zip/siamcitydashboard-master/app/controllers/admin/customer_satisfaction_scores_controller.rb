class Admin::CustomerSatisfactionScoresController < ApplicationController
  before_action :set_month
  skip_before_action :verify_authenticity_token, :only=> [:fetch_customer_satisfaction_score, :change_request, :fetch_incident]
  skip_before_action :authenticate_user!, :only => [:fetch_customer_satisfaction_score, :change_request, :fetch_incident]

  def index
    @disabled_months = []
    @customer_satisfaction_score = CustomerSatisfactionScore.order(created_at: :asc).where("ai_taken_on BETWEEN ? AND ?",@month_date,@month_end).paginate(:page => params[:page], :per_page => 50)
  end

  def destroy
    @customer_satisfaction_score = CustomerSatisfactionScore.find_by(id: params[:id].to_i)
    @customer_satisfaction_score.destroy
    redirect_to admin_customer_satisfaction_scores_path
  end

  def search
    if params[:search].blank?
      return @customer_satisfaction_score = nil
    else
      parameter = params[:search].downcase
      @customer_satisfaction_score = CustomerSatisfactionScore.search(parameter).paginate(:page => params[:page], :per_page => 50)
    end
  end

  def fetch_customer_satisfaction_score
    if check_user(params[:email], params[:password])
      @customer_statisfaction = CustomerSatisfactionScore.order(created_at: :asc).where("created_at BETWEEN ? AND ?",params[:start_date],params[:end_date])
      render json: {status: 200, data: @customer_statisfaction}
    else
      render json: {status: 200, message: "Invalid User or Password"}
    end
  end

  def fetch_incident
    if check_user(params[:email], params[:password])
      @incident = Incident.order(created_at: :asc).where("created_at BETWEEN ? AND ?",params[:start_date],params[:end_date]).where("priority= ? OR priority =?","1 - Critical", "2 - High")
      render json: {status: 200, data: @incident}
    else
      render json: {status: 200, message: "Invalid User or Password"}
    end
  end

  private

  def check_user(email, password )
    valid_user = User.where(email: email).first
    if valid_user.present? && valid_user.valid_password?(params[:password])
      return true
    else
      return false
    end
  end

  def set_month
    month_hash = ["January","February","March","April","May","June","July","August","September","October","November","December"]
    if params.present? && params['datepicker-search'].present?
      full_month = params['datepicker-search']
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    elsif params.present? && params[:query_string].present? && params[:query_string][:datepicker-search].present?
      full_month = params[:query_string][:datepicker-search]
      @month = full_month.split('-')[0]
      @year = full_month.split('-')[1]
      month_number = month_hash.index(@month) + 1
      month_d = Time.new(@year.to_i,month_number,1)
    else
      month_d = (Time.current.beginning_of_month - 1.month)
      @month = month_hash[month_d.month - 1]
      @year = month_d.year
    end
    @month_date = month_d.strftime("%Y-%m-%d")
    @month_end = month_d.end_of_month.strftime("%Y-%m-%d")
    @diff = month_d.end_of_month.to_i - month_d.to_i
    @last_three_months = []
    (1..6).each do |t|
      @last_three_months.push((Time.now.utc - (7-t).month).strftime("%B-%Y").downcase)
    end
    @groups_niit = ServicenowGroup.where(:u_group_type => ['Application','Infrastructure']).where(:active => true).map{|group| group.group_name}
  end
end
