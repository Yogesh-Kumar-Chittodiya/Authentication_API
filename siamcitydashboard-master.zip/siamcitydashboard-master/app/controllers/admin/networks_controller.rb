class Admin::NetworksController < ApplicationController
  before_action :set_admin_network, only: [:show, :edit, :update, :destroy]
  before_action :check_role 
  def index
    @admin_networks = SolarwindInterface.all
  end

  def show
  end

  def edit
  end

  def update
    respond_to do |format|
      if @admin_network.update(admin_network_params)
        format.html { redirect_to @admin_network, notice: 'Solarwind Interface was successfully updated.' }
      else
        format.html { render :edit }
      end
    end
  end

  def destroy
    @admin_network.destroy
    respond_to do |format|
      format.html { redirect_to admin_networks_url, notice: 'Solarwind Interface was successfully destroyed.' }
    end
  end

  def change_status
    if @admin_netwok.is_delete
      @admin_netwok.update(:is_delete => false)
    else
      @admin_netwok.update(:is_delete => true)
    end
    respond_to do |format|
      format.html { redirect_to admin_networks_url, notice: 'Solarwind Interface was successfully removed.' }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_admin_network
    @admin_network = SolarwindInterface.find(params[:id])
  end

  def check_role
    unless ['developer'].include?current_user.role
      redirect_to root_path
    end
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def admin_network_params
    params.require(:solarwind_interface).permit(:NodeID, :InterfaceID, :ObjectSubType, :Name,:TypeName,:TypeDescription,:Speed,:MTU,:LastChange,:PhysicalAddress,:InBandwidth,:OutBandwidth,:Caption,:FullName,:LastSync,:Alias,:IfName,:CustomPollerLastStatisticsPoll,:NextPoll,:InterfaceSpeed,:InterfaceCaption,:InterfaceName,:InterfaceTypeName,:InterfaceAlias,:InterfaceLastChange,:InterfaceMTU,:InterfaceTypeDescription,:Status,:MPLS_Details,:DataCenter,:Interface_Details)
  end
end
