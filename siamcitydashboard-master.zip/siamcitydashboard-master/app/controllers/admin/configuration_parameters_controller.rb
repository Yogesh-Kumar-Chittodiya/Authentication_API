class Admin::ConfigurationParametersController < ApplicationController
    load_resource :find_by => :slug, except: :create
    authorize_resource
  
	  def index
      @configuration_parameters = ConfigurationParameter.all
	  end
	  
	  def new
      @configuration_parameter = ConfigurationParameter.new
      @url_path =  admin_configuration_parameters_path
	  end
	  
	  def create
		 	@configuration_parameter = ConfigurationParameter.new(configuration_parameter_param)

		 	if @configuration_parameter.save
        redirect_to admin_configuration_parameters_path
      else
        @url_path =  admin_configuration_parameters_path
				render :new
			end
	  end
	  
	  def edit
      @configuration_parameter = ConfigurationParameter.friendly.find(params[:id])

      @url_path = admin_configuration_parameter_path
	  end
	  
	  def update
      @configuration_parameter = ConfigurationParameter.friendly.find(params[:id])
      if @configuration_parameter.update(configuration_parameter_param)
        redirect_to admin_configuration_parameters_path
      else
        @url_path = admin_configuration_parameter_path
        render :edit
      end
	  end 
    
	  def destroy
      @configuration_parameter = ConfigurationParameter.friendly.find(params[:id])
      @configuration_parameter.destroy
      redirect_to admin_configuration_parameters_path
	  end
        
    private
    
	  def configuration_parameter_param
      params.require(:configuration_parameter).permit(:parameter,:slug)
	  end    
end
