class Admin::ServicenowGroupsController < ApplicationController
  before_action :check_role
  def index
    @servicenow_groups = ServicenowGroup.all
  end

  def new
    @servicenow_group = ServicenowGroup.new()
    @url_path = admin_servicenow_groups_path
  end

  def edit
    @servicenow_group = ServicenowGroup.where(:id=>params[:id]).first
    @url_path = admin_servicenow_group_path
  end

  def update
     @servicenow_group = ServicenowGroup.where(:id=>params[:id]).first
   #raise params.inspect
   @servicenow_group.update(servicenow_group_param)
      redirect_to admin_servicenow_groups_path
  end

  def create
     @servicenow_group = ServicenowGroup.new(servicenow_group_param)
   @servicenow_group.save
      redirect_to admin_servicenow_groups_path
  end

  def servicenow_group_param
  params.require(:servicenow_group).permit(:name, :sys_id)
  end

  private
  def check_role
    unless ['developer'].include?current_user.role
      redirect_to root_path
    end
  end
end
