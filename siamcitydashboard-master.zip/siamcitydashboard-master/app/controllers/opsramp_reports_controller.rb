class OpsrampReportsController < ApplicationController

  def system_performance_sap
    @sap_responses = SapResponse.where(:record_type => 'old')
    yesterday_responses = SapResponse.where(:kpi_date => Time.current.yesterday.strftime("%Y-%m-%d")).all
    yest_avg =  SapResponseDaily.where(:kpi_date => Time.current.yesterday.strftime("%Y-%m-%d")).all
    if yest_avg.count > 0
      @yesterday_value = yest_avg.map{|ye| { ye.kpi_name => ye.kpi_value}}
    else
       @yesterday_value = []
    end 
    if yesterday_responses.count > 0
      #@yesterday_value = yesterday_responses.group_by{|resp| resp[:kpi_name]}.map{|key,value| {key => value.sum{|per| per['kpi_value'].to_i}/value.count}}
      @sap_chart = yesterday_responses.group_by{|resp| resp[:kpi_name]}.map{|y,i| {"name" => y , "data" => i.map{|y| (y.kpi_value.split)[0].to_i}}}
    else
      @yesterday_value = []
    end
    @sap_responses_month = SapResponseMtd.where(:kpi_date => Time.current.strftime("%Y-%m-%d")).map{|res| { res.kpi_name => res.kpi_value.to_i}}
    # raise Time.current.yesterday.strftime("%Y-%m-%d").to_s.inspect
    
    # month_responses = SapResponse.where(kpi_date: Time.current.beginning_of_month.strftime("%Y-%m-%d")..Time.zone.today.strftime("%Y-%m-%d")).all
    # if month_responses.count > 0
    #   @sap_responses_month = month_responses.group_by{|resp| resp[:kpi_name]}.map{|key,value| {key => value.sum{|per| per['kpi_value'].to_i}/value.count}}
    # else
    #   @sap_responses_month = []
    # end
    # raise @sap_responses_month.inspect
    @stops = {"GRC" => [0,500,1000],"HCM" =>[0,500,1000],"FIORI" =>[0,500,1000],"ECC" =>[0,300,800],"BW" =>[0,300,800]}
    @labels = (1..24).map{|num| num.to_s + ':00'}
  end

  def system_performance_non_sap
    @devices = NonSapDevice.where(:device_type => 'prod').all
    @non_sap_responses = NonSapPerformance.where(:record_type=>'old')
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d")

    prod_devices = NonSapDevice.select('id').where(:device_type=>'prod').all.map{|p|p.id}

    # calculating month average value
    month_values = NonSapPerformanceHour.select('non_sap_device_id','usage').where("created_date BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:non_sap_device_id => prod_devices).all
    if month_values.present?
      @month_values = month_values.group_by{|resp| resp[:non_sap_device_id]}.map{|key,value| {key => [value.sum{|per| per['usage']['cpu'].to_f.round(2)}/value.count, value.sum{|per| per['usage']['memory'].to_f.round(2)}/value.count]}}
    end
    # end yesterday value

    # calculating Yesterday average value
      yesterday_values = NonSapPerformanceHour.select('non_sap_device_id','usage').where(created_date: Time.current.yesterday.strftime("%Y-%m-%d")).where(:non_sap_device_id => prod_devices).all
      if yesterday_values.present?
        @yesterday_values = yesterday_values.group_by{|resp| resp[:non_sap_device_id]}.map{|key,value| {key => [value.sum{|per| per['usage']['cpu'].to_f.round(2)}/value.count, value.sum{|per| per['usage']['memory'].to_f.round(2)}/value.count]}}
      end
    # end value

    # raise @non_sap_cpu.to_a.inspect
    @devices = @devices.group_by{|ava| ava['primary_app']}
  end

  def system_availability_sap
    current_time = Time.current
    @start_of_month = current_time.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = current_time.end_of_month.strftime("%Y-%m-%d")

    @availabilities = SapApplication.all
    @yesterday_value = 100

    host_names = ['CI URLMSG Srv URL','CI URLMSG - HBP/BW','CI URLMSG - HRP/HCM','PIP - F5 Loadbalancer URL','ADP URL','FIP CI','GRP CI','BOP URL','SPP ABAP URL']
    sap_devices = SapDevice.where(:host_name => host_names).all
    # calculating month average value
    @sap_month = SapDowntime.where(:isremoved=> [nil,false]).where("downtime_date BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:sap_device_id => sap_devices).group_by{|down| down[:sap_device_id]}.map{|key,value| {key => value.sum{|per| per[:total_downtime].to_i}}}
    # end month value

    # calculating yesterday average value
    @sap_yesterday = SapDowntime.where("downtime_date = ?",current_time.yesterday.strftime("%Y-%m-%d")).where(:sap_device_id => sap_devices).group_by{|down| down[:sap_device_id]}.map{|key,value| {key => value.sum{|per| per[:total_downtime].to_i}}}
    # end yesterday value
  end

  def system_availability_non_sap
    current_time = Time.current
    @start_of_month = current_time.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = current_time.end_of_month.strftime("%Y-%m-%d")

    non_sap_devices = NonSapDevice.select('id').all.map{|p|p.id}
    # calculating month average value
    @non_sap_month = NonSapDowntime.where(:isremoved=> [nil,false]).where("downtime_date BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:non_sap_device_id => non_sap_devices).group_by{|down| down[:non_sap_device_id]}.map{|key,value| {key => value.sum{|per| per[:total_downtime].to_i}}}
    # end month value

    # calculating yesterday average value
    @non_sap_yesterday = NonSapDowntime.where("downtime_date = ?",current_time.yesterday.strftime("%Y-%m-%d")).where(:non_sap_device_id => non_sap_devices).group_by{|down| down[:non_sap_device_id]}.map{|key,value| {key => value.sum{|per| per[:total_downtime].to_i}}}
    # end yesterday value

    @devices = NonSapDevice.all
    @availabilities = NonSapAvailability.where(:record_type=>'old')
    @devices = @devices.group_by{|ava| ava['primary_app']}
  end

  def local_system_availability_1
    diff_month = Time.current.to_i - Time.current.beginning_of_month.to_i
    current_time = Time.current
    @start_of_month = current_time.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = current_time.end_of_month.strftime("%Y-%m-%d")
    devices = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical').where.not(:landscape => 'DataCenter').all
    critical_devices = devices.map{|crt|crt.ip_address}
    host_names = devices.map{|crt|crt.host_name}
    @devices_tickets = {}

    # calculating month average value
    opsramp_devices = OpsrampDevice.where(:device_type => ["Server","Linux","Windows","VMware"]).where(:state => "active").all
    solarwind_devices = SolarwindDevice.where(:IPAddress => critical_devices).where("DataCenter != ?",'Thailand DC').all
    @solarwind_devices = solarwind_devices.group_by{|dev| dev.DataCenter }.sort
    # host_names = solarwind_devices.map{|device| device.NodeName.downcase}
    # host_names = host_names + opsramp_devices.map{|device| device.host_name.downcase}

    devices_tickets = DeviceTicket.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where("short_description NOT LIKE ? AND ( short_description LIKE ? OR short_description LIKE ? OR short_description LIKE ? OR short_description LIKE ?)","%interface%","%node%","%down%","%hardware%","%agent%").all
    host_names.each do |name|
      unless @devices_tickets[name].present?
        @devices_tickets[name] = {}
        @devices_tickets[name]['tickets'] = []
      end
      @devices_tickets[name]['tickets'] = devices_tickets.select{|ticket| ticket.short_description.downcase.include?(name)}
    end
    # calculating month average value
    @sap_month = OpsrampDeviceDowntime.where("downtime_date BETWEEN ? AND ?",@start_of_month,@end_of_month).where(:opsramp_device_id => opsramp_devices).group_by{|down| down[:opsramp_device_id]}.map{|key,value| {key => value.sum{|per| per[:total_downtime].to_i}}}
    # end month value

    # calculating yesterday average value
    @sap_yesterday = OpsrampDeviceDowntime.where("downtime_date = ?",current_time.yesterday.strftime("%Y-%m-%d")).where(:opsramp_device_id => opsramp_devices).group_by{|down| down[:opsramp_device_id]}.map{|key,value| {key => value.sum{|per| per[:total_downtime].to_i}}}
    # end yesterday value
    @local_systems = OpsrampDevice.where(:ip_address => critical_devices).where("location <> ? or location <> ?","",nil).where(:state => "active").where(:device_type => ["Server","Linux","Windows","VMware"]).includes(:opsramp_device_availabilities).where("opsramp_device_availabilities.record_type = ?",'old').references(:opsramp_device_availabilities).all.group_by{|opsr| opsr.location}

    downtime_of_devices = SolarwindDeviceDowntime.where(:isremoved=> [nil,false]).where(:created_month => current_time.beginning_of_month.strftime("%B").capitalize,:created_year => current_time.beginning_of_month.strftime("%Y")).group(:NodeID).sum(:OutageDurationInSeconds)

    @solarwind_availabilities = SolarwindDeviceAvailability.where(:record_type => 'old').all.each do |avail|
      if downtime_of_devices.key?(avail.NodeID.to_s)
        avail.AvailabilityMonth = ((1 - downtime_of_devices[avail.NodeID.to_s].to_f/diff_month)*100).round(2)
      else
        avail.AvailabilityMonth = "100.0"
      end
    end
  end

  def local_system_availability
    diff_month = Time.current.to_i - Time.current.beginning_of_month.to_i
    current_time = Time.current
    @start_of_month = current_time.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = current_time.end_of_month.strftime("%Y-%m-%d")
    devices = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical').where.not(:landscape => 'DataCenter').all
    @solarwind_devices = devices.select{|dev| (dev.landscape.downcase != 'indonesia' && dev.landscape.downcase != 'bangladesh')}.group_by(&:landscape)
    @local_devices = devices.select{|dev| (dev.landscape.downcase == 'indonesia' || dev.landscape.downcase == 'bangladesh')}.group_by(&:landscape)
    # raise devices.count.inspect
    critical_devices = devices.map{|crt|crt.ip_address}
    host_names = devices.map{|crt|crt.host_name}
    @devices_tickets = {}

    # calculate device tickets
    devices_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where("short_description NOT LIKE ? AND ( short_description LIKE ? OR short_description LIKE ? OR short_description LIKE ? OR short_description LIKE ?)","%interface%","%node%","%down%","%hardware%","%agent%").all
    host_names.each do |name|
      unless @devices_tickets[name].present?
        @devices_tickets[name] = {}
        @devices_tickets[name]['tickets'] = []
      end
      @devices_tickets[name]['tickets'] = devices_tickets.select{|ticket| ticket.short_description.include?(name)}
    end

    # calculating month average value
    sap_month = OpsrampDeviceDowntime.where("downtime_date BETWEEN ? AND ?",@start_of_month,@end_of_month).group(:ip_address).sum(:total_downtime)
    # end month value

    # calculating yesterday average value
     sap_yesterday = OpsrampDeviceDowntime.where("downtime_date = ?",current_time.yesterday.strftime("%Y-%m-%d")).group(:ip_address).sum(:total_downtime)
    # end yesterday value
    
    @opsramp_availabilities = OpsrampDeviceAvailability.where(:record_type => 'old',:ip_address => critical_devices).all.each do |avail|
      device = devices.select{|dev|dev.ip_address == avail.ip_address}.first
      if device.present?
        avail.logical_name = device.logical_name
        avail.node_name = device.host_name
      end
      if sap_yesterday.key?(avail.ip_address)
        avail.yesterday = ((1 - sap_yesterday[avail.ip_address].to_f/86400)*100).round(2)
      else
        avail.yesterday = "100.0"
      end
      if sap_month.key?(avail.ip_address)
        avail.month_to_date = ((1 - sap_month[avail.ip_address].to_f/diff_month)*100).round(2)
      else
        avail.month_to_date = "100.0"
      end
    end

    # raise @opsramp_availabilities.inspect

    downtime_of_devices = SolarwindDeviceDowntime.where(:isremoved=> [nil,false]).where(:is_delete => [nil,false]).where(:created_month => current_time.beginning_of_month.strftime("%B").capitalize,:created_year => current_time.beginning_of_month.strftime("%Y")).group(:NodeID).sum(:OutageDurationInSeconds)

    @solarwind_availabilities = SolarwindDeviceAvailability.where(:record_type => 'old',:ip_address => critical_devices).all.each do |avail|
      device = devices.select{|dev|dev.ip_address == avail.ip_address}.first
      if device.present?
        avail.logical_name = device.logical_name
        avail.node_name = device.host_name
      end
      if downtime_of_devices.key?(avail.NodeID.to_s)
        avail.AvailabilityMonth = ((1 - downtime_of_devices[avail.NodeID.to_s].to_f/diff_month)*100).round(2)
      else
        avail.AvailabilityMonth = "100.0"
      end
    end
    # raise @solarwind_availabilities.count.inspect
    render 'local_system_availability_1'
  end

  def local_network_availability
    diff_month = Time.current.to_i - Time.current.beginning_of_month.to_i
    current_time = Time.current
    @start_of_month = current_time.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = current_time.end_of_month.strftime("%Y-%m-%d")

    downtime_of_devices = SolarwindInterfaceDowntime.where(:isremoved=> [nil,false],:is_delete => [nil,false],:created_month => current_time.beginning_of_month.strftime("%B").capitalize,:created_year => current_time.beginning_of_month.strftime("%Y")).group(:InterfaceID).sum(:OutageDurationInSeconds)

    @solarwind_systems_mpls = SolarwindInterface.where(:Interface_Details => nil).all
    @solarwind_systems_internet = SolarwindInterface.where(:MPLS_Details => nil).all

    @devices_tickets = DeviceTicket.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where("short_description LIKE ? AND short_description LIKE ? ","%interface%","%down%").where.not(:incident_state => ['Closed','Cancelled','Resolved'])
    @solarwind_availability = SolarwindInterfaceAvailability.where(:record_type=>'old').all.each do |avail|
      if downtime_of_devices.key?(avail.InterfaceID.to_s)
        avail.AvailabilityMonth = ((1 - downtime_of_devices[avail.InterfaceID.to_s].to_f/diff_month)*100).round(2)
      else
        avail.AvailabilityMonth = "100.0"
      end
    end
  end

  def o365_availability
    @data = O365Availability.where(:record_type => 'old').all
  end

  def dc_patch_management
    month_hash = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    month_d = (Time.current.beginning_of_month - 1.month)
    @month = month_hash[month_d.month - 1]
    @data = DcPatchManagement.where(:month => @month)
  end

  def local_patch_management
    month_hash = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    month_d = (Time.current.beginning_of_month - 1.month)
    @month = month_hash[month_d.month - 1]
    @data_th = Admin::PatchManagement.where(:month => @month).select{|da| da.device.include?('TH')}
    @data_bd = Admin::PatchManagement.where(:month => @month).select{|da| da.device.include?('BD')}
    @data_in = Admin::PatchManagement.where(:month => @month).select{|da| da.device.include?('ID')}
    @data_lk = Admin::PatchManagement.where(:month => @month).select{|da| da.device.include?('LK')}
    @data_vn = Admin::PatchManagement.where(:month => @month).select{|da| da.device.include?('VN')}
  end

  def non_sap_performance
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d 00:00:00")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d 23:59:59")
    @db_servers = ['INSEE-DC-S090','INSEE-DC-S132','INSEE-DC-S193','INSEE-DC-S200','INSEE-DC-S217']
    @non_sap_devices = NonSapDevice.where(:device_type => 'prod').all
    hosts_names = @non_sap_devices.map{|device| device.host_name.downcase}
    @device_tickets = DeviceTicket.where("lower(cmdb_ci) IN (?) AND (short_description LIKE ? OR short_description LIKE ? )",hosts_names,"%memory%","%cpu%").where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month)
    @devices_with_utilization = DcDeviceUtilization.where("lower(node_name) IN (?) AND record_type = ?",hosts_names,'old').all
  end

  def system_availability_non_sap_devices
    set_time
    current_time = Time.current
    @critical_devices = CriticalDevice.where(:is_delete => [nil,false],:priority => 'Critical',:landscape => 'DataCenter').all
    hosts_names = @critical_devices.pluck(:host_name)
    ip_address = @critical_devices.pluck(:ip_address)

    devices_tickets = Incident.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where("short_description LIKE ? AND short_description LIKE ?","%Node%","%Down%")
    @devices_tickets = {}
    hosts_names.each do |name|
      unless @devices_tickets[name].present?
        @devices_tickets[name] = {}
        @devices_tickets[name]['tickets'] = []
      end
      if devices_tickets.present?
        @devices_tickets[name]['tickets'] = devices_tickets.select{|ticket| ticket.short_description.include?(name)}
      end
    end
    @devices_availability = DcDeviceAvailability.where("IPAddress IN (?) AND record_type = ?",ip_address,'old').all
    downtime_of_devices = SolarwindDeviceDowntime.where(:isremoved => [nil,false],:is_delete => [nil,false],:created_date => current_time.beginning_of_month.strftime("%Y-%m-%d 00:00:00")).group(:NodeID).sum(:OutageDurationInSeconds)

    @devices_availability = @devices_availability.each do |avail|
      device = @critical_devices.select{|device|device.ip_address == avail.IPAddress}.first
      if device.present?
        avail.DeviceType = device.logical_name
        avail.NodeName = device.host_name
      end
      if downtime_of_devices.key?(avail.NodeID.to_s)
        avail.AvailabilityMonth = ((1 - downtime_of_devices[avail.NodeID.to_s].to_f/@diff_month)*100).round(2)
      else
        avail.AvailabilityMonth = "100.0"
      end
    end
    # raise @devices_tickets.inspect
  end

  def system_availability_sap_devices
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d 00:00:00")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d 23:59:59")
    diff_month = Time.current.to_i - Time.current.beginning_of_month.to_i
    current_time = Time.current
    @start_of_month = current_time.beginning_of_month.strftime("%Y-%m-%d")
    @end_of_month = current_time.end_of_month.strftime("%Y-%m-%d")

    host_names_new = ['CI URLMSG Srv URL','CI URLMSG - HBP/BW','CI URLMSG - HRP/HCM','PIP - F5 Loadbalancer URL','ADP URL','FIP CI','GRP CI','BOP URL','SPP ABAP URL']

    @sap_devices = SapDevice.where(:host_name => host_names_new).all
    ids = @sap_devices.map{|device| device.component_id}

    @devices_availability = DcSapAvailability.where("ComponentID IN (?) AND record_type = ?",ids,'old').all
    host_names = @devices_availability.pluck(:Caption)
    componentids = @devices_availability.pluck(:ComponentID)

    downtime_of_devices = SolarwindComponentDowntime.where(:isremoved=> [nil,false],:is_delete=> [nil,false],:ComponentID => componentids).where("DATE(created_date) = ?",current_time.beginning_of_month.strftime("%Y-%m-%d")).group(:ComponentID).sum(:OutageDurationInSeconds)

    @devices_tickets = DeviceTicket.where('sys_created_on BETWEEN ? AND ?',@start_of_month,@end_of_month).where("lower(cmdb_ci) IN (?) AND short_description NOT LIKE ? AND ( short_description LIKE ? AND (short_description LIKE ? OR short_description LIKE ?))",host_names,"%interface%","%node%","%down%","%hardware%").where.not(:incident_state => ['Closed','Cancelled','Resolved'])

    @devices_availability = @devices_availability.each do |avail|
      device = @sap_devices.select{|dev|dev.component_id == avail.ComponentID}.first
      primary_app = SapApplication.where(:name => device.primary_app).first
      avail.ComponentName = primary_app.name
      if primary_app.sla_category == 'gold'
        avail.IPAddress = 99.99
      else
        avail.IPAddress = 99.50
      end

      if downtime_of_devices.key?(avail.ComponentID)
        avail.AvailabilityMonth = ((1 - downtime_of_devices[avail.ComponentID].to_f/diff_month)*100).round(3)
      else
        avail.AvailabilityMonth = "100.0"
      end
    end
  end

  def inventory
    if params[:status].present? && params[:status] != ''
      @status = params[:status].downcase
    end
    if @status == 'up'
      @devices = SolarwindDevice.where(:IsServer => true).where(:Status => "1").all
    elsif  @status == 'down'
      @devices = SolarwindDevice.where(:IsServer => true).where(:Status => "2").all
    else
      @devices = SolarwindDevice.where(:IsServer => true).where(:Status => "14").all
    end
  end

  def set_time
    @start_of_month = Time.current.beginning_of_month.strftime("%Y-%m-%d 00:00:00")
    @end_of_month = Time.current.end_of_month.strftime("%Y-%m-%d 23:59:59")
    @diff_month = Time.current.to_i - Time.current.beginning_of_month.to_i
    current_time = Time.current
  end

end
