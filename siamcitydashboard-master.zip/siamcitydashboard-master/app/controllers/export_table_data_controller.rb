class ExportTableDataController < ApplicationController
  before_action :check_role

    def index
      @tables = ['Incident','Assessment','SapDevice','NonSapDevice']
      @table = 'User'
      @data = @table.constantize.all
    end

    def export_data
      if params.present?
        if params[:start_date].present?
          start_date = params[:start_date]
          if params[:end_date].present?
            end_date = params[:end_date]
          else
            end_date = Date.today.strftime("%Y-%m-%d")
          end
        else
          start_date = ''
        end
      case params[:table]
        when 'users'
          data = User.all
          @fields = ['id','name','email','role','created_at']
          @sheets = {'users' => data}
          @header = ['ID','Name','Email','Role','Created On']
          @name = "Users"
        end
        respond_to do |format|
          format.xlsx {
            response.headers['Content-Disposition'] = "attachment; filename=#{@name}.xlsx"
          }
        end
      else
        respond_to do |format|
          format.xlsx {

          }
        end
      end
    end

    private
    def check_role
       unless ['developer'].include?current_user.role
         redirect_to root_path
       end
    end
end
