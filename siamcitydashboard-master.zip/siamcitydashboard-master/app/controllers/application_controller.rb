class ApplicationController < ActionController::Base

  before_action :authenticate_user!
  before_action :set_page_title
  before_action :get_dashboard_customer
  skip_before_action :get_dashboard_customer, if: :devise_controller?
  
  #before_action :confirm_duo_authentication
  # before_action :get_total_incident_current
  #skip_before_action :confirm_duo_authentication, if: :devise_controller?
  # skip_before_action :get_total_incident_current, if: :devise_controller?

  rescue_from CanCan::AccessDenied do |exception| 
    redirect_to root_url, :alert => exception.message
  end

  rescue_from ActionController::RoutingError do |exception|
    logger.error 'Routing error occurred'
    render "error"
    render plain: '404 Not found', status: 404
  end

  # get data for highcharts
  def get_data_charts_drilldown(chartdata,type,labels,colors,visibility = [])
    if type != ''
      data = Hash.new
      labels.each_with_index do |label,key|
        data[label] = Hash.new
        data[label]['name'] =label.titleize
        data[label]['visible'] = (visibility[key].present? and visibility[key] == "no") ? false : true
        data[label]['y'] = chartdata.map{|date,count| count[type][label]}
        data[label]['drilldown'] = label
      end
    else
      data = Hash.new
      labels.each_with_index do |label,key|
        data[label] = Hash.new
        data[label]['name'] =label.titleize
        data[label]['visible'] = (visibility[key].present? and visibility[key] == "no") ? false : true
        data[label]['y'] = chartdata.map{|date,count| count[label]}
        data[label]['drilldown'] = label
      end
    end

    data = data.map{|date,count| count}
    return data
  end

# check daytype and set name
  def set_name(graph_type,field,variable)
    if graph_type == 'day'
      return field[variable].to_time.strftime("%d-%b-%y")
    elsif graph_type == 'month'
      return field[variable].to_time.strftime("%b-%y")
    else
      return field[variable].to_time.strftime("%B")
    end
  end
  # end

   # Get Labels form the passed data
  def get_labels(chartdata)
    return chartdata.map{|date,count| date }
  end
  # end

  # get data for highcharts
  def get_data_high_charts(chartdata,type,labels,colors,visibility = [])
    if type != ''
      data = Hash.new
      labels.each_with_index do |label,key|
        data[label] = Hash.new
        data[label]['name'] =label.titleize
        puts "--------#{key}-------------#{visibility[key]}----#{(visibility[key].present?)}----------------"
        data[label]['visible'] = (visibility[key].present? and visibility[key] == "no") ? false : true
        data[label]['data'] = chartdata.map{|date,count| count[type][label]}
        if (colors.present?)
          data[label]['color'] = colors[key]
        end
      end
    else
      data = Hash.new
      labels.each_with_index do |label,key|
        data[label] = Hash.new
        data[label]['name'] =label.titleize
        data[label]['visible'] = (visibility[key].present? and visibility[key] == "no") ? false : true
        data[label]['data'] = chartdata.map{|date,count| count[label]}
        if (colors.present?)
          data[label]['color'] = colors[key]
        end
      end
    end

    data = data.map{|date,count| count}
    return data
  end

  def confirm_duo_authentication
    if !session[:duo_authentication]
      redirect_to duo_path
    end
  end

  def get_total_incident_current
    OpsrampPuller.refresh_auth_token
    query = [
      {'name' => 'inc_sys_created_by','value' => 'Eurostar_opsramp', 'operator' => 'notequal', 'type' => 'normal', 'joinoperator' => 'and' },
      {'name' => 'inc_state','value' => [6,7,8], 'operator' => 'notin', 'type' => 'normal', 'joinoperator' => 'and' },
      {'name' => 'inc_priority','value' => [1,2], 'operator' => 'in', 'type' => 'normal', 'joinoperator' => 'none' }
    ]
    @total_incident_current_marquee =  get_data(query,'u_es_incident_location')
  end

  def get_dashboard_customer
    if current_user.present?
      if current_user.role == "developer"
        @allowed_dashboards = Dashboard.all
      elsif current_user.role == "admin"
        @allowed_dashboards = Dashboard.where(:customer_id=>current_user.customer_id).all
      else
        @allowed_dashboards = current_user.dashboards.all
      end
    end
  end

  def get_widget_configuration(parameter)
    customer_id = @dashboard_customer
    begin
      parameter_value = ConfigurationParameter.friendly.find(parameter).customer_configurations.where(:customer_id=>customer_id).first.value
      parameter_values = Hash.new
      parameter_value.map{|p| parameter_values[p["key"]] = p["value"] }
      return parameter_values
    rescue
      if customer_id != 0
        customer_id = 0
        retry
      end
      return Hash.new
    end
  end

  def getDatafromurl(url,query = '',group_by='')
    if params[:cust].present?
      customer = Customer.where(:slug => params[:cust]).first
      if customer.present? and (current_user.customer_id == 0 or current_user.customer_id == customer.id)
        api_customer_id = customer.api_customer_id
      end
    end
    if !api_customer_id.present?
      if current_user.customer_id > 0
        api_customer_id = current_user.customer.api_customer_id
      else
        api_customer_id = ''
      end
    end
    if api_customer_id.present?
      query = query + "&customer_id=#{api_customer_id}"
    end
    #puts "------------------------------------------------------------------"
    #puts "#{url}?query=#{query}&group_by=#{group_by}".inspect
    return_data = RestClient.get url, {:params => {:query => query,:group_by=>group_by}, :"Content-Type" => 'application/json', :Accept => 'application/json'}
    return_data_parsed = JSON.parse(return_data)
    return return_data_parsed
  end

  def set_page_title
    #  query_parameter = params
    #  query_parameter.delete('controller')
    #  query_parameter.delete('action')
    #raise query_parameter.to_array.map{|k,v| "#{v}"}.join('-').inspect
    if action_name != "index"
      @page_title = controller_name.singularize.titleize+" - "+action_name.titleize
    else
      @page_title = controller_name.singularize.titleize
    end
  end

  def set_dates(day_type,data)
    labels = Array.new
    date_today = Date.today

    day_array = %w(current_day last_day last_five_days current_week last_week)
    # month_array = %w( last_three_months last_five_months)
    week_array = %w(current_month last_month last_three_weeks last_five_weeks)

    # check for current date type
      if day_array.include? day_type
        graph_type = 'day'
      elsif week_array.include? day_type
        graph_type = 'week'
      else
        graph_type = 'month'
      end

    # Set current date and End Date
    if graph_type == 'day'
      if day_type == 'last_five_days'
        (date_today-4..date_today).map do |d|
          labels.push(d.strftime("%Y-%m-%d"))
        end
        start_date = (date_today - 4).iso8601
        end_date = date_today.iso8601
      elsif day_type == 'last_day'
        labels.push((date_today - 1.day).strftime("%Y-%m-%d"))
        start_date = (date_today - 1.day).iso8601
        end_date = (date_today - 1.day).iso8601
      elsif day_type == 'current_week'
        ((date_today.strftime("%u").to_i + 1) - date_today.beginning_of_week.strftime("%u").to_i).times do |key|
          labels.push((date_today.beginning_of_week + key.day).strftime("%Y-%m-%d"))
        end
        start_date = date_today.beginning_of_week.strftime("%Y-%m-%d")
        end_date = date_today.strftime("%Y-%m-%d")
      elsif day_type == 'last_week'
        7.times do |key|
          labels.push((date_today - date_today.wday-6 + key.day).strftime("%Y-%m-%d"))
        end
        start_date = (date_today - date_today.wday-6).strftime("%Y-%m-%d")
        end_date = (date_today - date_today.wday).strftime("%Y-%m-%d")
      else
        labels.push(date_today.strftime("%Y-%m-%d"))
        start_date = date_today.iso8601
        end_date = date_today.iso8601
        # @start_date = (Date.today).iso8601
        # @end_date = (Date.today).iso8601
      end
    elsif graph_type == 'week'
      if day_type == 'last_five_weeks'
        labels = []
      elsif
      labels == []
      else
        labels = []
      end
    else
      current_date = Date.today
      if day_type == 'last_three_months'
        3.times do |t|
          labels.push((date_today - (2-t).month).strftime("%B"))
        end
        start_date = (date_today - 2.month).beginning_of_month.strftime("%Y-%m-%d")
        end_date = date_today.strftime("%Y-%m-%d")
      elsif day_type == 'last_five_months'
        5.times do |t|
          labels.push((current_date - (5-t).month).strftime("%B"))
        end
        start_date = (current_date - 4.month).strftime("%Y-%m-%d")
        end_date = Date.today.strftime("%Y-%m-%d")
      else
        labels = []
      end
    end
    if (data != '')
      data = data.select{|device| device['created_on'].to_time.strftime("%Y-%m-%d").to_s >= start_date && device['created_on'].to_time.strftime("%Y-%m-%d").to_s <= end_date}.map{|y| y}
    end
    return labels,data,start_date,end_date
  end

  # set labels of dates
  def set_date_range(type,count)
    labels = Array.new
    date_today = Date.today
    end_date = date_today
    #raise end_date.inspect
    case type
      when 'day'
        graph_type = 'day'
        start_date = date_today - (count.to_i-1).day
        check_date = start_date
        begin
          labels.push(check_date.strftime("%Y-%m-%d"))
          check_date = (check_date.to_date+1.day)
        end while (check_date.to_time.to_i <= end_date.to_time.to_i)
      when 'week'
        start_date = (end_date - count.to_i.week).beginning_of_week
        end_date = (end_date - count.to_i.week).end_of_week
        
        #temporary work        
        #start_date = Date.new(2019,9,16)
        #end_date = Date.new(2019,9,22)
        
        check_date = start_date
        begin
          labels.push(check_date.strftime("%Y-%m-%d"))
          check_date = (check_date.to_date+1.day)
        end while (check_date.to_time.to_i <= end_date.to_time.to_i)
        graph_type = 'day'
      when 'month'
        graph_type = 'month'
        start_date = (date_today - (count.to_i).month).beginning_of_month
        end_date = (end_date - 1.month).end_of_month
        check_date = start_date
        begin
          labels.push(check_date.strftime("%b-%y"))
          check_date = (check_date.to_date+1.month)
        end while (check_date.to_time.to_i < end_date.to_time.to_i)
      when 'monthly'
        graph_type = 'month'
        start_date = (date_today - (count.to_i).month).beginning_of_month
        end_date = start_date.end_of_month
        labels.push(start_date.strftime("%b-%y"))
    end
    
    # raise start_date.inspect
    return labels.sort,start_date,end_date,graph_type
  end
  # end
end
