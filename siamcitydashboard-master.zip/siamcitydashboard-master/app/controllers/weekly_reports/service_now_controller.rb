class WeeklyReports::ServiceNowController < ReportsController

  include ServiceNow
  layout "reports"


  def ageing
    query = "stateIN1,2,3,10&sys_created_on<=#{Date.today.strftime("%Y-%m-%d")}&sys_created_by!=Eurostar_OpsRamp"
    incidentdata =  get_incidents(query)
    incidentdata = incidentdata.select{|device| device['assignment_group'] != 'ad2f0991db77fa403eb17e400f9619f2' and device['assignment_group'] != '989e415ddb77fa403eb17e400f9619ba' and device['assignment_group'] != '5b7f4d9ddb77fa403eb17e400f961981'}.map{|y|y}

    incidentdata = incidentdata.select{|dat| ["1","2","3","10"].include?(dat['state']) }.map{|y|y}
    grouped_incidents = incidentdata.group_by{ |incident| incident['assignment_group']}
    
    labels = ['<=30','>30 & <=60','>60']
    currentdate = Date.today
    hashdata = Hash.new
    labels.each do |label|
      hashdata[label] = 0
    end

    # Eurostar Queues
    hashdata_eurostar = get_hash_data(EUROSTAR_QUEUES,grouped_incidents)
    @graph_data_eurostar,@euro_labels = get_filtered_data(hashdata,hashdata_eurostar)
    
    
    # NIIT Queues
    hashdata_niit = get_hash_data(NIIT_QUEUES,grouped_incidents)
    @graph_data_niit, @niit_labels = get_filtered_data(hashdata,hashdata_niit)

    @data = {
      'graph_data_eurostar' => @graph_data_eurostar,
      'graph_data_niit' => @graph_data_niit,
      'euro_labels' => @euro_labels
    }
  end

  def tickets_logged_by_priority
    @labels,@start_date,@end_date,@graph_type = set_date_range('week',1)
    query1 = "sys_created_by!=Eurostar_OpsRamp&sys_created_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @tickets_logged_1 =  get_incidents(query1)
    @tickets_data = get_hash(@labels,@graph_type,['logged'],['p1','p2','p3','p4','total'])
    # raise hashdata.inspect
    
    @tickets_logged_1.each do |sla|
      name = set_name(@graph_type,sla,'sys_created_on')
      if @tickets_data[name].present?
        @tickets_data[name]['logged']['total'] += 1
        if sla['priority'] == '1'
          @tickets_data[name]['logged']['p1'] += 1
        elsif sla['priority'] == '2'
          @tickets_data[name]['logged']['p2'] += 1
        elsif sla['priority'] == '3'
          @tickets_data[name]['logged']['p3'] += 1
        elsif sla['priority'] == '4'
          @tickets_data[name]['logged']['p4'] += 1
        end
      end
    end
    @labels,@start_date,@end_date,@graph_type = set_date_range('week',1)
    query = "sys_created_by!=Eurostar_OpsRamp&sys_created_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @tickets_logged =  get_incidents(query)

    hashdata = get_hash(@labels,@graph_type,['logged'],['p1','p2','p3','p4','total'])
    # raise hashdata.inspect
    @tickets_logged.each do |sla|
      name = set_name(@graph_type,sla,'sys_created_on')
      if hashdata[name].present?
        hashdata[name]['logged']['total'] += 1
        if sla['priority'] == '1'
            hashdata[name]['logged']['p1'] += 1
        elsif sla['priority'] == '2'
          hashdata[name]['logged']['p2'] += 1
        elsif sla['priority'] == '3'
          hashdata[name]['logged']['p3'] += 1
        elsif sla['priority'] == '4'
          hashdata[name]['logged']['p4'] += 1
        end
      end
    end

    @graph_data = get_data_high_charts(hashdata,'logged',['p1','p2','p3','p4'],'')
    @graph_labels = get_labels(hashdata)

    respond_to do |format|
      format.html {render :template => 'weekly_reports/service_now/tickets_logged_by_priority'}
      format.pdf do
        html = render_to_string(:action => 'tickets_logged_by_priority.html.erb',:layout => "pdf_layout")
        pdf = WickedPdf.new.pdf_from_string(html,javascript_delay: 1000,orientation: 'Landscape')
        send_data pdf, :filename => "tickets_logged_by_priority.pdf", :disposition => 'attachment'
        end
    end
  end

  def transactional_survey
    type = 'week'
    date_count = 1
    if (params[:type].present?)
      type = params[:type]
    end
    if (params[:count].present?)
      date_count = params[:count]
    end
    @labels,@start_date,@end_date,@graph_type = set_date_range(type,date_count)
    query = "created_on>=#{@start_date.strftime("%Y-%m-%d")}&updated_on<=#{@end_date.strftime("%Y-%m-%d")}&feedbackISBLANKfalse"
    @CSAT_data =  get_csats(query)

    hashdata = get_hash(['incident','u_manual_service_request'],@graph_type,['tickets'],['Extremely Satisfied','Satisfied','Not Satisfied'])
    # raise hashdata.inspect
    @CSAT_data.each do |d|
      name = d['trigger_type']
      if hashdata[name].present?
        if d['feedback'] == 'Extremely Satisfied'
          hashdata[name]['tickets']['Extremely Satisfied'] += 1
        elsif d['feedback'] == 'Satisfied'
          hashdata[name]['tickets']['Satisfied'] += 1
        else
          hashdata[name]['tickets']['Not Satisfied'] += 1
        end
      end
    end
    
    @graph_data = get_data_high_charts(hashdata,'tickets',['Not Satisfied','Satisfied','Extremely Satisfied'],['#ff5d5d','#20bae5','#2eb85a'])
    @graph_labels = ['Incidents','Service Reqs']
    respond_to do |format|
      format.html {render :template => 'weekly_reports/service_now/transactional_survey'}
      format.pdf do
        html = render_to_string(:action => 'transactional_survey.html.erb',:layout => "pdf_layout")
        pdf = WickedPdf.new.pdf_from_string(html,javascript_delay: 1000,orientation: 'Landscape')
        send_data pdf, :filename => "transactional_survey.pdf", :disposition => 'attachment'
        end
    end
  end

  def tickets_logged
    @labels,@start_date,@end_date,@graph_type = set_date_range('week',1)
    # raise @labels.inspect
    query = "sys_created_by!=Eurostar_OpsRamp&sys_created_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    tickets_logged =  get_incidents(query)


    # last seven days total------------------>
    hashdata = get_hash(@labels,@graph_type,['logged'],['incidents'])
    tickets_logged.each do |sla|
      name = set_name(@graph_type,sla,'sys_created_on')
      if hashdata[name].present?
        hashdata[name]['logged']['incidents'] += 1
      end
    end
    @last_seven_days = get_data_high_charts(hashdata,'logged',['incidents'],'')
    @labels_last_seven_days = @labels
    # end ------------------------------------>


    # logged by source-------------------------->
    hashdata_2 = get_hash(['phone','Own Observation','Event Monitoring','Walkup','Web Portal','email'],'',['logged'],['incidents'])

    tickets_logged.each do |sla|
      name = sla['contact_type']
      if hashdata_2[name].present?
        hashdata_2[name]['logged']['incidents'] += 1
      end
    end

    @last_seven_days_source = get_data_high_charts(hashdata_2,'logged',['incidents'],'')
    @labels_last_seven_days_source = ['Phone','Own Observation','Event Monitoring','Walkup','Self-Service Portal','email']
    # end ---------------------------------->


    # logged by category --------------------->
    labels = ['BUSINESS APPLICATIONS','DATA CENTRE','DISTRIBUTION SYSTEMS','EUROSTAR.COM','IN-STATION SERVICES','SECURITY','Eurostar MOBILE','ON-BOARD SERVICES','USER EQUIPMENT','VOICE AND DATA SERVICES','WORKSTATION SERVICES']
    hashdata_3 = get_hash(labels,'',['logged'],['incidents'])

    tickets_logged.each do |sla|
      name = sla['category']
      if hashdata_3[name].present?
        hashdata_3[name]['logged']['incidents'] += 1
      end
    end

    @last_seven_days_category = get_data_high_charts(hashdata_3,'logged',['incidents'],'')
    @labels_last_seven_days_category = labels
    # end ------------------------------------->

    respond_to do |format|
      format.html {render :template => 'weekly_reports/service_now/tickets_logged'}
      format.pdf do
        html = render_to_string(:action => 'tickets_logged.html.erb',:layout => "pdf_layout")
        pdf = WickedPdf.new.pdf_from_string(html,javascript_delay: 1000,)
        send_data pdf, :filename => "tickets_logged.pdf", :disposition => 'attachment'
        end
    end
  end

  def tickets_closed
    @labels,@start_date,@end_date,@graph_type = set_date_range('week',0)
    # raise @labels.inspect
    query = "sys_created_by!=Eurostar_OpsRamp&closed_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    tickets_logged =  get_incidents(query)

    # last seven days total------------------>
    hashdata = get_hash(@labels,@graph_type,['closed'],['incidents'])
    tickets_logged.each do |sla|
      if sla['closed_at'].present?
        closed_name = set_name(@graph_type,sla,'closed_at')
        if hashdata[closed_name].present?
          if hashdata[closed_name]['closed'].present? and hashdata[closed_name]['closed']['incidents'].present?
            hashdata[closed_name]['closed']['incidents'] += 1
          else
            hashdata[closed_name]['closed']['incidents'] = 1
          end
        end
      end
    end
    @last_seven_days = get_data_high_charts(hashdata,'closed',['incidents'],'')
    @labels_last_seven_days = @labels
    # end ------------------------------------>

    respond_to do |format|
      format.html {render :template => 'weekly_reports/service_now/tickets_closed'}
      format.pdf do
        html = render_to_string(:action => 'tickets_closed.html.erb',:layout => "pdf_layout")
        pdf = WickedPdf.new.pdf_from_string(html,javascript_delay: 1000,)
        send_data pdf, :filename => "tickets_closed.pdf", :disposition => 'attachment'
        end
    end
  end

  def tickets_closed_location
    @labels,@start_date,@end_date,@graph_type = set_date_range('week',0)
    # raise @labels.inspect
    query = "sys_created_by!=Eurostar_OpsRamp&closed_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    tickets_closed =  get_incidents(query)

    grouped_data = tickets_closed.group_by{|t| t['location']}

    @labels = grouped_data.map{|gd,i| gd}
    @dataset = [{'name' => 'incidents' , 'data' => grouped_data.map{|d,i| i.count}}]
  end

  def change_requests
    @labels,@start_date,@end_date,@graph_type = set_date_range('week',1)
    query = "opened_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    tickets_logged =  get_change_requests(query)

    # logged by type -------------------------->
    hashdata_1 = get_hash(['normal','emergency','standard'],'',['logged'],['changes'])
    tickets_logged.each do |sla|
      name = sla['type']
      if hashdata_1[name].present?
        hashdata_1[name]['logged']['changes'] += 1
      end
    end
    @last_seven_days_type = get_data_high_charts(hashdata_1,'logged',['changes'],'')
    @labels_last_seven_days_type = ['Normal','Emergency','Standard']
    # end ---------------------------------->


    query_1 = "closed_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    tickets_closed =  get_change_requests(query_1)
    # closed by type -------------------------->
    hashdata_2 = get_hash(['normal','emergency','standard'],'',['closed'],['changes'])
    tickets_closed.each do |sla|
      name = sla['type']
      if hashdata_2[name].present?
        hashdata_2[name]['closed']['changes'] += 1
      end
    end
    @last_seven_days_closed = get_data_high_charts(hashdata_2,'closed',['changes'],'')
    @labels_last_seven_days_closed = ['Normal','Emergency','Standard']
    # end ---------------------------------->

    hashdata_3 = get_hash(['New','Assess','Authorize','Scheduled','Implement','Review'],'',['change requests'],'')
    # raise data.inspect
    tickets_logged.each do |da|
      if da['state'] == '-5'
        hashdata_3['New']['change requests'] += 1
      elsif da['state'] == '-4'
        hashdata_3['Assess']['change requests'] += 1
      elsif da['state'] == '-3'
        hashdata_3['Authorize']['change requests'] += 1
      elsif da['state'] == '-2'
        hashdata_3['Scheduled']['change requests'] += 1
      elsif da['state'] == '-1'
        hashdata_3['Implement']['change requests'] += 1
      elsif da['state'] == '0'
        hashdata_3['Review']['change requests'] += 1
      end
    end

    @labels_last_seven_days_logged_status = get_labels(hashdata_3)
    @last_seven_days_logged_status = get_data_high_charts(hashdata_3,'',['change requests'],'')

    respond_to do |format|
      format.html {render :template => 'weekly_reports/service_now/change_requests'}
      format.pdf do
        html = render_to_string(:action => 'change_requests.html.erb',:layout => "pdf_layout")
        pdf = WickedPdf.new.pdf_from_string(html,javascript_delay: 1000,)
        send_data pdf, :filename => "change_requests.pdf", :disposition => 'attachment'
        end
    end
  end

  def overall_tickets_status
    @labels,@start_date,@end_date,@graph_type = set_date_range('week',0)
    # raise @start_date.inspect
    # total logged incidents
    query_1 = "sys_created_by!=Eurostar_OpsRamp&sys_created_onBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @incidents_logged =  get_incidents(query_1)
    @elgar_related_ticket_logged =  @incidents_logged.select{|device| device['assignment_group'] == '70fab7f6dbaf1300973056d6dc9619e7' or device['assignment_group'] == '05daf33adbaf1300973056d6dc961908' }.map{|y|y}

    @open_incidents = @incidents_logged.select{|dat| ["1","2","3","10"].include?(dat['state']) }.map{|y|y}

    @open_incidents_grouped = @open_incidents.group_by{|inc| inc['state']}

    # total closed incidents
    query_2 = "sys_created_by!=Eurostar_OpsRamp&closed_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @incidents_closed =  get_incidents(query_2)
    @elgar_related_ticket_closed =  @incidents_closed.select{|device| device['assignment_group'] == '70fab7f6dbaf1300973056d6dc9619e7' or device['assignment_group'] == '05daf33adbaf1300973056d6dc961908' }.map{|y|y}
    
    # service logged requests
    query_3 = "opened_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @sr_logged =  get_service_requests(query_3)
    
    @open_sr = @sr_logged.select{|dat| ["1","2","3","10"].include?(dat['state']) }.map{|y|y}

    # service closed requests
    query_4 = "closed_atBETWEEN#{@start_date.strftime("%Y-%m-%d")},#{@end_date.strftime("%Y-%m-%d")}"
    @sr_closed =  get_service_requests(query_4)

    # grouped = total_incident_data.group_by{ |incident| incident['state']}
    # final_grouped = grouped.map{|k,v| [k,v.length]}
    # # raise final_grouped.inspect
    # states= [1,7,6,3,10,2,8]

    # @total_logged = total_incident_data.count + service_requests_data.count

    # raise @total_logged.inspect 
  end


  private

  def get_hash_data(queue_array,incidents)
    hashdata = Hash.new
    queue_array.each do |eu|
      if incidents.key? eu['sys_id']
        hashdata[eu['name']] = incidents[eu['sys_id']]
      end
    end
    return hashdata
  end

  def get_filtered_data(hashdatasend,incidentdata)
    complete_data = [{"name" => '<=30','data' => []},{"name" => '>30 & <=60','data' => []},{"name" => '>60','data' => []}]
    labels = []
    incidentdata.each do |name,datainc|
      labels.push(name)
      hashdata = {'<=30'=> 0,'>30 & <=60'=> 0,'>60'=> 0}
      datainc.each do |d|
        days = (Date.today - Date.parse(d['sys_created_on'])).to_i
        if(days >= 0 && days <= 30)
          hashdata['<=30'] += 1
        elsif(days > 30 && days <= 60)
          hashdata['>30 & <=60'] += 1
        else
          hashdata['>60'] += 1
        end
      end
      complete_data.each do |cdata|
          cdata['data'].push(hashdata[cdata['name']])
        end
    end
    return  complete_data, labels
  end
end
