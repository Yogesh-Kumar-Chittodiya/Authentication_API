module ServiceNow extend ActiveSupport::Concern
  
  # MODULE CONSTANTS
  SERVICE_NOW_URL = APP_CONFIG['service_now_url']
  SERVICE_NOW_USERNAME = APP_CONFIG['service_now_username']
  SERVICE_NOW_PASSWORD = APP_CONFIG['service_now_password']
  PER_PAGE_RECORD = 1000
  # CUSTOMER_SYS_ID = "53a7ac7edbd35780292850d3dc961981"

  def get_data(query,table,fields = '')
    url = "#{SERVICE_NOW_URL}/now/table/#{table}?sysparm_query="
    query.each do |q|
      if q['type'] == 'normal'
        if q['operator'] == 'equal'
          url+= "#{q['name']}%3D#{q['value']}"
        elsif q['operator'] == 'notequal'
          url+= "#{q['name']}!%3D#{q['value']}"
        elsif q['operator'] == 'in'
          url+= "#{q['name']}IN"
          q['value'].each do |val|
            url+="#{val}"
            url+="%2C"
          end
        elsif q['operator'] == 'notin'
          url+= "#{q['name']}NOT%20IN"
          q['value'].each do |val|
            url+="#{val}"
            url+="%2C"
          end
        elsif q['operator'] == 'lessthenequal'
          url+= "#{q['name']}%3C%3D#{q['value']}"
        end
      else
        if q['operator'] == 'equal'
          url+= "#{q['name']}ON#{q['value'].strftime("%Y-%m-%d")}%40javascript%3Ags.dateGenerate(%27#{q['value'].strftime("%Y-%m-%d")}%27%2C'00%3A00%3A00')%40javascript%3Ags.dateGenerate(%27#{q['value'].strftime("%Y-%m-%d")}%27%2C'23%3A59%3A59')"
        elsif q['operator'] == 'notequal'
          url+= "#{q['name']}!%3D#{q['value'].strftime("%Y-%m-%d")}"
        elsif q['operator'] == 'between'
          url+= "#{q['name']}BETWEENjavascript%3Ags.dateGenerate(%27#{q['value'][0].strftime("%Y-%m-%d")}%27%2C'00%3A00%3A00')%40javascript%3Ags.dateGenerate(%27#{q['value'][1].strftime("%Y-%m-%d")}%27%2C'23%3A59%3A59')"
        elsif q['operator'] == 'lessthenequal'
        url+= "#{q['name']}%3C%3Djavascript%3Ags.dateGenerate(%27#{q['value'].strftime("%Y-%m-%d")}%27%2C'00%3A00%3A00')"
        end
      end
      
      if q['joinoperator'] == 'and'
        url+= '%5E'
      elsif q['joinoperator'] == 'or'
        url+= '%5EOR'
      else
      end
    end
    url += "&sysparm_limit=#{PER_PAGE_RECORD}&sysparm_exclude_reference_link=true&sysparm_display_value=true&sysparm_fields=#{fields}"
    # raise url.inspect
    rest_resource = RestClient::Request.execute(method: :get, url: url,verify_ssl: false, user: SERVICE_NOW_USERNAME, password: SERVICE_NOW_PASSWORD)
    results = JSON.parse(rest_resource, :symbolize_names => true)
    # raise results[:result].count.inspect
    return results[:result]
  end


  def get_incidents(query)
    url = "#{SERVICE_NOW_URL}/now/table/u_es_incident_location?sysparm_query=#{query}&sysparm_limit=#{PER_PAGE_RECORD}"
    return get_data(url)
  end

  def get_change_requests(query)
    url = "#{SERVICE_NOW_URL}/now/table/change_request?sysparm_query=#{query}&sysparm_limit=#{PER_PAGE_RECORD}"
    return get_data(url)
  end

  def get_service_requests(query)
    url = "#{SERVICE_NOW_URL}/now/table/u_manual_service_request?sysparm_query=#{query}&sysparm_limit=#{PER_PAGE_RECORD}"
    return get_data(url)
  end

  def get_problems(query)
    url = "#{SERVICE_NOW_URL}/now/table/problem?sysparm_query=#{query}&sysparm_limit=#{PER_PAGE_RECORD}"
    return get_data(url)
  end

  def get_csat_responses(query)
    # raise query.inspect
    url = APP_CONFIG['data_fetch_url']+'service_now/csat_responses.json'
    return getDatafromurl(url,query)
  end

  def get_csat_count(query)
    # raise query.inspect
    url = APP_CONFIG['data_fetch_url']+'service_now/csats_count.json'
    return getDatafromurl(url,query)
  end

  def get_csats(query)
    # raise query.inspect
    url = APP_CONFIG['data_fetch_url']+'service_now/csats.json'
    return getDatafromurl(url,query)
  end

  # end
  def getincidentSLAs(query)
    url = APP_CONFIG['data_fetch_url']+'service_now/incident_slas.json'
    return getDatafromurl(url,query)
  end

  def get_states(module_name='incident')
    parameter = module_name.to_s + '-states'
    @states = get_widget_configuration(parameter)
  end

  

  # end of methods

end
