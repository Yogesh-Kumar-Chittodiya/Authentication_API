module Opsramp

# for non_sap_availability check--------->
  def non_sap_applications_check(applications)
    availabilities_nonsap = NonSapAvailability.where(:record_type=>'old').all
    devices = NonSapDevice.all
    array_avail = Hash.new
    availabilities_nonsap.each do |avail|
      device = devices.select{|dev| dev.id == avail.non_sap_device_id }[0]
      unless array_avail[device.primary_app].present?
        array_avail[device.primary_app] = Hash.new
      end
      array_avail[device.primary_app][device.host_name] = [avail.currentState,avail.totalAvailability]
    end

    if applications.present? && applications.count > 0
      applications.each do |app|
      availabilities = array_avail[app.name]
      if app.name == 'DMS'
          if availabilities['INSEE-DC-S193'][0] == 'down' || availabilities['INSEE-DC-S194'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S189'][0] == 'down' && availabilities['INSEE-DC-S190'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S192'][0] == 'down' && availabilities['INSEE-DC-S191'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S192'][0] == 'up' && availabilities['INSEE-DC-S191'][0] == 'down'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S192'][0] == 'down' && availabilities['INSEE-DC-S191'][0] == 'up'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S189'][0] == 'down' && availabilities['INSEE-DC-S190'][0] == 'up'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S189'][0] == 'up' && availabilities['INSEE-DC-S190'][0] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
      elsif app.name == 'Citrix'
        if availabilities['INSEE-DC-S132'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S131'][0] == 'down' && availabilities['INSEE-DC-S133'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S131'][0] == 'up' && availabilities['INSEE-DC-S133'][0] == 'down'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S131'][0] == 'down' && availabilities['INSEE-DC-S133'][0] == 'up'
            app.status = 'amber'
          else
            app.status = 'green'
          end
      elsif app.name == 'Active Directory'
        if availabilities['INSEE-DC-S076'][0] == 'down' || availabilities['INSEE-DC-S097'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S244'][0] == 'down' && availabilities['INSEE-DC-S245'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S244'][0] == 'up' && availabilities['INSEE-DC-S245'][0] == 'down'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S244'][0] == 'down' && availabilities['INSEE-DC-S245'][0] == 'up'
            app.status = 'amber'
          else
            app.status = 'green'
          end
      elsif app.name == 'AutoPlant'
        if availabilities['INSEE-DC-S138'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      #elsif app.name == 'RMX'
        #if availabilities['INSEE-DC-S084'][0] == 'down' || availabilities['INSEE-DC-S085'][0] == 'down' || availabilities['INSEE-DC-S088'][0] == 'down' || availabilities['INSEE-DC-S089'][0] == 'down' || availabilities['INSEE-DC-S090'][0] == 'down' || availabilities['INSEE-DC-S091'][0] == 'down' || availabilities['INSEE-DC-S093'][0] == 'down' || availabilities['INSEE-DC-S094'][0] == 'down'
          #app.status = 'red'
        #else
          #app.status = 'green'
        #end
      elsif app.name == 'PMS'
        if availabilities['INSEE-DC-S182'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      elsif app.name == 'TSC'
        if availabilities['INSEE-DC-S134'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      elsif app.name == 'QlikView'
        if availabilities['INSEE-DC-S236'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      elsif app.name == 'JV Online'
        if availabilities['INSEE-DC-S198'][0] == 'down' || availabilities['INSEE-DC-S199'][0] == 'down' || availabilities['INSEE-DC-S200'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
       elsif app.name == 'OpenText'
        availabilities = array_avail[app.name]
        if availabilities['INSEE-DC-S148'][0] == 'down' || availabilities['INSEE-DC-S179'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      elsif app.name == 'Logistic'
        if availabilities['INSEE-DC-S217'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      elsif app.name == 'Power BI'
        if availabilities['INSEE-DC-S221'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      elsif app.name == 'IFRS 16'
        if availabilities['INSEE-DC-S225'][0] == 'down' || availabilities['INSEE-DC-S226'][0] == 'down'
          app.status = 'red'
        else
          app.status = 'green'
        end
      else
      end
      availabilities.each do |key,ava|
        if ava[1].to_i < SLA_MATRIX['silver']
          app.sla_breached = true
        end
      end
      app.save
    end
    end


  end

  def non_sap_check(applications)
    non_sap_devices = NonSapDevice.where(:device_type => 'prod').all
    hosts_names = non_sap_devices.map{|device| device.host_name.downcase}
    devices_availability = DcDeviceAvailability.where("lower(NodeName) IN (?) AND record_type = ?",hosts_names,'old').all

    array_avail = Hash.new
    devices_availability.each do |avail|
      device = non_sap_devices.select{|dev| dev.host_name.downcase == avail.NodeName.downcase }[0]
      unless array_avail[device.primary_app].present?
        array_avail[device.primary_app] = Hash.new
      end
      array_avail[device.primary_app][device.host_name] = [avail.Status,avail.AvailabilityToday]
    end

    if applications.present? && applications.count > 0
      applications.each do |app|
        availabilities = array_avail[app.name]
          if availabilities.present?
          if app.name == 'DMS'
          if availabilities['INSEE-DC-S193'][0] == 'down' || availabilities['INSEE-DC-S194'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S189'][0] == 'down' && availabilities['INSEE-DC-S190'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S192'][0] == 'down' && availabilities['INSEE-DC-S191'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S192'][0] == 'up' && availabilities['INSEE-DC-S191'][0] == 'down'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S192'][0] == 'down' && availabilities['INSEE-DC-S191'][0] == 'up'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S189'][0] == 'down' && availabilities['INSEE-DC-S190'][0] == 'up'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S189'][0] == 'up' && availabilities['INSEE-DC-S190'][0] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
        elsif app.name == 'Citrix'
          if availabilities['INSEE-DC-S132'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S131'][0] == 'down' && availabilities['INSEE-DC-S133'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S131'][0] == 'up' && availabilities['INSEE-DC-S133'][0] == 'down'
            app.status = 'amber'
          elsif availabilities['INSEE-DC-S131'][0] == 'down' && availabilities['INSEE-DC-S133'][0] == 'up'
            app.status = 'amber'
          else
            app.status = 'green'
          end
        # elsif app.name == 'Active Directory'
        #   if availabilities['INSEE-DC-S076'][0] == 'down' || availabilities['INSEE-DC-S097'][0] == 'down'
        #     app.status = 'red'
        #   else
        #     app.status = 'green'
        #   end
        elsif app.name == 'AutoPlant'
          if availabilities['INSEE-DC-S138'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'RMX'
          #if availabilities['INSEE-DC-S084'][0] == 'down' || availabilities['INSEE-DC-S085'][0] == 'down' || availabilities['INSEE-DC-S088'][0] == 'down' || availabilities['INSEE-DC-S089'][0] == 'down' || availabilities['INSEE-DC-S090'][0] == 'down' || availabilities['INSEE-DC-S091'][0] == 'down' || availabilities['INSEE-DC-S093'][0] == 'down' || availabilities['INSEE-DC-S094'][0] == 'down'
            #app.status = 'red'
          #else
            app.status = 'green'
          #end
        elsif app.name == 'PMS'
          if availabilities['INSEE-DC-S182'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'TSC'
          if availabilities['INSEE-DC-S134'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'QlikView'
          if availabilities['INSEE-DC-S236'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'JV Online'
          if availabilities['INSEE-DC-S198'][0] == 'down' || availabilities['INSEE-DC-S199'][0] == 'down' || availabilities['INSEE-DC-S200'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'OpenText'
          availabilities = array_avail[app.name]
          if availabilities['INSEE-DC-S148'][0] == 'down' || availabilities['INSEE-DC-S179'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'Logistic'
          if availabilities['INSEE-DC-S217'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'Power BI'
          if availabilities['INSEE-DC-S221'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        elsif app.name == 'IFRS 16'
          if availabilities['INSEE-DC-S225'][0] == 'down' || availabilities['INSEE-DC-S226'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
        else
        end
        availabilities.each do |key,ava|
          if ava[1].to_i < SLA_MATRIX['silver']
            app.sla_breached = true
          end
        end
        app.save
      end
      end
    end


  end

  # for sap_availability check--------->
  def sap_applications_check(sap_applications)
    sap_avalability = SapAvailability.where(:record_type=>'old')
    if sap_avalability.present?
      devices = SapDevice.where.not(:uid => "").all
      array_avail = Hash.new
      sap_avalability.each do |avail|
        device = devices.select{|dev| dev.id == avail.sap_device_id }[0]
        unless array_avail[device.primary_app].present?
          array_avail[device.primary_app] = Hash.new
        end
        array_avail[device.primary_app][device.host_name] = [avail.currentState,avail.totalAvailability,avail.month_to_date]
      end

      # raise array_avail.inspect
      sap_applications.each do |app|
        availabilities = array_avail[app.name]
        if app.name == 'HAP/ERP'
            if availabilities['DB Virtual IP/ URL'][0] == 'down' || availabilities['CI URLMSG Srv URL'][0] == 'down'
              app.status = 'red'
            elsif availabilities['INSEE-DC-S008'][0] == 'down' && availabilities['INSEE-DC-S009'][0] == 'down' && availabilities['INSEE-DC-S010'][0] == 'down' && availabilities['INSEE-DC-S011'][0] == 'down' && availabilities['INSEE-DC-S012'][0] == 'down'
              app.status = 'red'
            elsif availabilities['INSEE-DC-S008'][0] == 'down' || availabilities['INSEE-DC-S009'][0] == 'down' || availabilities['INSEE-DC-S010'][0] == 'down' || availabilities['INSEE-DC-S011'][0] == 'down' || availabilities['INSEE-DC-S012'][0] == 'down'
              app.status = 'amber'
            else
              app.status = 'green'
            end
            app.availability = availabilities['CI URLMSG Srv URL'][1]
            app.month_to_date = availabilities['CI URLMSG Srv URL'][2]
        elsif app.name == 'HBP/BW'
          if availabilities['CI URLMSG - HBP/BW'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S050'][0] == 'down' && availabilities['INSEE-DC-S051'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S050'][0] == 'down' || availabilities['INSEE-DC-S051'][0] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
          app.availability = availabilities['CI URLMSG - HBP/BW'][1]
          app.month_to_date = availabilities['CI URLMSG - HBP/BW'][2]
        elsif app.name == 'HRP/HCM'
          if availabilities['CI URLMSG - HRP/HCM'][0] == 'down' || availabilities['INSEE-DC-S033'][0] == 'down'
              app.status = 'red'
            else
              app.status = 'green'
            end
            app.availability = availabilities['CI URLMSG - HRP/HCM'][1]
            app.month_to_date = availabilities['CI URLMSG - HRP/HCM'][2]
        elsif app.name == 'PIP/PI'
          if availabilities['PIP - F5 Loadbalancer URL'][0] == 'down'
            app.status = 'red'
          elsif availabilities['J01 Instance'][0] == 'down' && availabilities['J02 Instance'][0] == 'down' && availabilities['J03 Instance'][0] == 'down'
            app.status = 'red'
          elsif availabilities['J01 Instance'][0] == 'down' || availabilities['J02 Instance'][0] == 'down' || availabilities['J03 Instance'][0] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
          # raise availabilities['PIP - F5 Loadbalancer URL'][0].inspect
          app.availability = availabilities['PIP - F5 Loadbalancer URL'][1]
          app.month_to_date = availabilities['PIP - F5 Loadbalancer URL'][2]
        elsif app.name == 'ADP/ADOBE'
          if availabilities['ADP URL'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['ADP URL'][1]
          app.month_to_date = availabilities['ADP URL'][2]
        elsif app.name == 'FIP/FIORI'
          if availabilities['FIP CI'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['FIP CI'][1]
          app.month_to_date = availabilities['FIP CI'][2]
        elsif app.name == 'GRP/GRC'
          if availabilities['GRP CI'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['GRP CI'][1]
          app.month_to_date = availabilities['GRP CI'][2]
        elsif app.name == 'BOP/BOBJ'
          if availabilities['BOP URL'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['BOP URL'][1]
          app.month_to_date = availabilities['BOP URL'][2]
        elsif app.name == 'SPP/SOLUTION MANAGER'
          if availabilities['SPP ABAP URL'][0] == 'down'
            app.status = 'red'
          elsif availabilities['SPP JAVA URL'] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
          app.availability = availabilities['SPP ABAP URL'][1]
          app.month_to_date = availabilities['SPP ABAP URL'][2]
        else
        end

        availabilities.each do |key,ava|
          if ava[1].to_i < SLA_MATRIX[app.sla_category]
            app.sla_breached = true
          end
        end

        app.save
      end
    end
  end
  #----------------------ENd------------

  def sap_check(sap_applications)
    sap_devices_new = SapDevice.all
    ids = sap_devices_new.pluck(:component_id)
    sap_avalability = DcSapAvailability.where("ComponentID IN (?) AND record_type = ? ",ids,'old').all

    if sap_avalability.present?
      array_avail = Hash.new
      sap_devices_new.each do |device|
        if device.component_id > 0
          availability = sap_avalability.select{|dev| dev.ComponentID == device.component_id }.first
          unless array_avail[device.primary_app].present?
            array_avail[device.primary_app] = Hash.new
          end
          array_avail[device.primary_app][device.host_name] = [availability.Status.downcase,availability.AvailabilityToday,availability.AvailabilityMonth]
        end
      end

      sap_applications.each do |app|
        availabilities = array_avail[app.name]
        if app.name == 'HAP/ERP'
          if availabilities['DB Virtual IP/ URL'][0] == 'down' || availabilities['CI URLMSG Srv URL'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S008'][0] == 'down' && availabilities['INSEE-DC-S009'][0] == 'down' && availabilities['INSEE-DC-S010'][0] == 'down' && availabilities['INSEE-DC-S011'][0] == 'down' && availabilities['INSEE-DC-S012'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S008'][0] == 'down' || availabilities['INSEE-DC-S009'][0] == 'down' || availabilities['INSEE-DC-S010'][0] == 'down' || availabilities['INSEE-DC-S011'][0] == 'down' || availabilities['INSEE-DC-S012'][0] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
          app.availability = availabilities['CI URLMSG Srv URL'][1]
          app.month_to_date = availabilities['CI URLMSG Srv URL'][2]

        elsif app.name == 'HBP/BW'
          if availabilities['CI URLMSG - HBP/BW'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S050'][0] == 'down' && availabilities['INSEE-DC-S051'][0] == 'down'
            app.status = 'red'
          elsif availabilities['INSEE-DC-S050'][0] == 'down' || availabilities['INSEE-DC-S051'][0] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
          app.availability = availabilities['CI URLMSG - HBP/BW'][1]
          app.month_to_date = availabilities['CI URLMSG - HBP/BW'][2]

        elsif app.name == 'HRP/HCM'
          if availabilities['DB Process Monitoring for Sybase HRP/HCM'][0] == 'down' || availabilities['DB Process Monitoring for Sybase BS HRP/HCM'][0] == 'down'
            app.status = 'red'
          elsif availabilities['CI URLMSG - HRP/HCM'][0] == 'down' || availabilities['INSEE-DC-S033'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['DB Process Monitoring for Sybase HRP/HCM'][1]
          app.month_to_date = availabilities['DB Process Monitoring for Sybase HRP/HCM'][2]

        elsif app.name == 'PIP/PI'
          if availabilities['DB Process Monitoring for Sybase PIP/PI'][0] == 'down' || availabilities['DB Process Monitoring for Sybase BS PIP/PI'][0] == 'down'
            app.status = 'red'
          elsif availabilities['PIP - F5 Loadbalancer URL'][0] == 'down'
            app.status = 'red'
          elsif availabilities['J01 Instance'][0] == 'down' && availabilities['J02 Instance'][0] == 'down' && availabilities['J03 Instance'][0] == 'down'
            app.status = 'red'
          elsif availabilities['J01 Instance'][0] == 'down' || availabilities['J02 Instance'][0] == 'down' || availabilities['J03 Instance'][0] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
          # raise availabilities['PIP - F5 Loadbalancer URL'][0].inspect
          app.availability = availabilities['DB Process Monitoring for Sybase PIP/PI'][1]
          app.month_to_date = availabilities['DB Process Monitoring for Sybase PIP/PI'][2]

        elsif app.name == 'ADP/ADOBE'
          if availabilities['DB Process Monitoring for Sybase ADP URL'][0] == 'down' || availabilities['DB Process Monitoring for Sybase BS ADP URL'][0] == 'down'
            app.status = 'red'
          elsif availabilities['ADP URL'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['DB Process Monitoring for Sybase ADP URL'][1]
          app.month_to_date = availabilities['DB Process Monitoring for Sybase ADP URL'][2]

        elsif app.name == 'FIP/FIORI'
          if availabilities['DB Process Monitoring for Sybase FIP CI'][0] == 'down' || availabilities['DB Process Monitoring for Sybase BS FIP CI'][0] == 'down'
            app.status = 'red'
          elsif availabilities['FIP CI'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['DB Process Monitoring for Sybase FIP CI'][1]
          app.month_to_date = availabilities['DB Process Monitoring for Sybase FIP CI'][2]

        elsif app.name == 'GRP/GRC'
          if availabilities['DB Process Monitoring for Sybase GRP CI'][0] == 'down' || availabilities['DB Process Monitoring for Sybase BS GRP CI'][0] == 'down'
            app.status = 'red'
          elsif availabilities['GRP CI'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['DB Process Monitoring for Sybase GRP CI'][1]
          app.month_to_date = availabilities['DB Process Monitoring for Sybase GRP CI'][2]

        elsif app.name == 'BOP/BOBJ'
          if availabilities['BOP URL'][0] == 'down'
            app.status = 'red'
          else
            app.status = 'green'
          end
          app.availability = availabilities['BOP URL'][1]
          app.month_to_date = availabilities['BOP URL'][2]

        elsif app.name == 'SPP/SOLUTION MANAGER'
          if availabilities['DB Process Monitoring for Sybase SPP ABAP URL'][0] == 'down' || availabilities['DB Process Monitoring for Sybase BS SPP ABAP URL'][0] == 'down'
            app.status = 'red'
          elsif availabilities['SPP ABAP URL'][0] == 'down'
            app.status = 'red'
          elsif availabilities['SPP JAVA URL'] == 'down'
            app.status = 'amber'
          else
            app.status = 'green'
          end
          app.availability = availabilities['DB Process Monitoring for Sybase SPP ABAP URL'][1]
          app.month_to_date = availabilities['DB Process Monitoring for Sybase SPP ABAP URL'][2]
        else

        end

        availabilities.each do |key,ava|
          if ava[1].to_i < SLA_MATRIX[app.sla_category]
            app.sla_breached = true
          end
        end

        app.save
      end
    end
  end

end
