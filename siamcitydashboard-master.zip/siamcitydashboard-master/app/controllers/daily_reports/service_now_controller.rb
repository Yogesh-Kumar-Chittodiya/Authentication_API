class DailyReports::ServiceNowController < ReportsController

  include ServiceNow
  
  def tickets
    today = Date.today
    @start_date = today.beginning_of_month.strftime("%d %b")
    @end_date = today.end_of_month.strftime("%d %b")

    @labels = []
    start_date= today.beginning_of_month
    end_date = @end_date.to_time.strftime("%d").to_i

    (1..end_date).each do |d|
      @labels << start_date.strftime("%d %b")
      start_date = start_date + 1.day
    end

    # get incidents
    query = "sys_created_onBETWEEN#{today.beginning_of_month.strftime("%Y-%m-%d")},#{today.end_of_month.strftime("%Y-%m-%d")}ORclosed_atBETWEEN#{today.beginning_of_month.strftime("%Y-%m-%d")},#{today.end_of_month.strftime("%Y-%m-%d")}"
    tickets_logged_incidents =  get_incidents(query)

    

    # get service requests
    query = "opened_atBETWEEN#{today.beginning_of_month.strftime("%Y-%m-%d")},#{today.end_of_month.strftime("%Y-%m-%d")}ORclosed_atBETWEEN#{today.beginning_of_month.strftime("%Y-%m-%d")},#{today.end_of_month.strftime("%Y-%m-%d")}"
    tickets_logged_service_requests =  get_service_requests(query)

    incident_hashdata = get_hash(@labels,'',['logged','closed'],'')

    # incidents data
    tickets_logged_incidents.each do |sla|
      name = sla['sys_created_on'].to_time.strftime("%d %b")
      if incident_hashdata[name].present?
        incident_hashdata[name]['logged'] += 1
      end
      if sla['closed_at'].present?
        closed_name = name = sla['closed_at'].to_time.strftime("%d %b")
        if incident_hashdata[closed_name].present?
          incident_hashdata[closed_name]['closed'] += 1
        end
      end
    end
    @tickets_incidents_data = get_data_high_charts(incident_hashdata,'',['logged','closed'],'')

    # service requests data
    sr_hashdata = get_hash(@labels,'',['logged','closed'],'')
    tickets_logged_service_requests.each do |sla|
      name = sla['created_on'].to_time.strftime("%d %b")
      if sr_hashdata[name].present?
        sr_hashdata[name]['logged'] += 1
      end
      if sla['closed_at'].present?
        closed_name = name = sla['closed_at'].to_time.strftime("%d %b")
        if sr_hashdata[closed_name].present?
          sr_hashdata[closed_name]['closed'] += 1
        end
      end
    end
    @tickets_sr_data = get_data_high_charts(sr_hashdata,'',['logged','closed'],'')


    # category wise incidents & service requests ------------------>
    labels = ['BUSINESS APPLICATIONS','DATA CENTRE','DISTRIBUTION SYSTEMS','EUROSTAR.COM','IN-STATION SERVICES','SECURITY','Eurostar MOBILE','ON-BOARD SERVICES','USER EQUIPMENT','VOICE AND DATA SERVICES','WORKSTATION SERVICES']
    hashdata_1 = get_hash(labels,'',['logged'],['incidents'])

    tickets_logged_incidents.each do |sla|
      name = sla['category']
      if hashdata_1[name].present?
        hashdata_1[name]['logged']['incidents'] += 1
      end
    end

    @tickets_category = get_data_high_charts(hashdata_1,'logged',['incidents'],'')
    @tickets_category_labels = labels

    # sub-category wise incidents & service requests ------------------>
    grouped = tickets_logged_incidents.group_by{ |incident| incident['subcategory']}
    final_grouped = grouped.map{|k,v| [k,v.length]}
    

    labels_sub = []
    data_sub = []
    final_grouped.each do |d|
      labels_sub.push(d[0])
      data_sub.push(d[1])
    end
    
    @tickets_sub_category = [{
      "name" => "Incidents",
      "visible" => true,
      "data" => data_sub 
    }]
    @labels_sub_category = labels_sub
  end
	
  def tickets_logged_per_site
    today = Date.today
    @start_date = today.beginning_of_month.strftime("%Y-%m-%d")
    @end_date = today.end_of_month.strftime("%Y-%m-%d")

    @labels = []
    start_date= today.beginning_of_month
    end_date = @end_date.to_time.strftime("%d").to_i

    (1..end_date).each do |d|
      @labels << start_date.strftime("%d %b")
      start_date = start_date + 1.day
    end

    # get all locations
    locations = get_locations
    query = "sys_created_onBETWEEN#{today.beginning_of_month.strftime("%Y-%m-%d")},#{today.end_of_month.strftime("%Y-%m-%d")}"
    tickets_logged =  get_incidents(query,@start_date,@end_date)

    # raise tickets_logged.inspect
    sites = ["AIS (Ashford International Station)","EHQ (Eurostar Headquarters)","PNO (Paris Gare Du Nord)","BMI (Brussels Midi)","EIS (Ebbsfleet International Station)","SPI (St Pancras International)","ECC (Eurostar Contact Centre)","LXE (Lille Axe CRE)","TMI (Temple Mills International)"]

    # daily days total------------------>
    hashdata = get_hash(@labels,'',['Total Tickets'],'')

    tickets_logged.each do |sla|
    name = sla['inc_sys_created_on'.to_sym].to_time.strftime("%d %b")
    loc_name = locations[sla['inc_location'.to_sym][:value]]
      if hashdata[name].present?
        hashdata[name]['Total Tickets'] += 1
      end
    end

    @data_site_wise = get_data_charts_drilldown(hashdata,'',['Total Tickets'],'')
    @labels_logged_by_sitewise = get_labels(hashdata)
    # end ------------------------------------>
    
    respond_to do |format|
      format.html {render :template => 'daily_reports/service_now/tickets_logged_per_site'}
      format.pdf do
        html = render_to_string(:action => 'tickets_logged_per_site.html.erb',:layout => "pdf_layout")
        pdf = WickedPdf.new.pdf_from_string(html,javascript_delay: 1000,)
        send_data pdf, :filename => "tickets_logged_per_site.pdf", :disposition => 'attachment'
        end
    end
  end
end
