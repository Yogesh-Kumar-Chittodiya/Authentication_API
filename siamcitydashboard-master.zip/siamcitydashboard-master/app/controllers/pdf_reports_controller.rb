class PdfReportsController < ApplicationController
  def index
    month_hash = ["january","february","march","april","may","june","july","august","september","october","november","december"]
    @reports_modules = [
        ['Data Center, SAP AND Non-SAP',['system_availability_non_sap','system_availability_sap','system_performance_sap']],
        ['System Operations,Network and End User Services',['internet_link_availability','network_mpls_availability','system_availability_thailand','system_availability_vietnam','system_availability_lanka_bangladesh_indonesia']],
        ['IT Security',['patch_management_status','patch_management_status_new','backup_reports','network_response_time']],
        ['Overall Ticket Management',['sla_status_report_domain','csat_report','tickets_ageing','first_call_resolution']]]
    # @reports = PdfReport.all.group_by{|rec| rec.created_year}
    @reports = PdfReport.all.sort.reverse.group_by{|report| report.report_name}
    # raise @reports.count.inspect
    @year_hash = {"2020" => month_hash - ["january","february","march","april","may"],"2021" => month_hash,"2022" => month_hash,"2023" => month_hash}
      
  end
end
