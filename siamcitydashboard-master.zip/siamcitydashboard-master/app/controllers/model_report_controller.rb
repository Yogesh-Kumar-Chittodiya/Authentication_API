class ModelReportController < ApplicationController
  include Pagy::Backend

  def index
    if params[:module].present?
    else
      @fields = Incident::DATATABLE_COLUMNS
      @pagy, @records = pagy(Incident)
    end
  end
end
