module ServiceNowReportsHelper
  def link_url(type,id)
    url = APP_CONFIG['service_now_url']+'/'
    if type == 'incident' 
      url = url + 'incident.do?sys_id='+id+'&sysparm_record_target=incident'
    elsif type == 'sc_request'
      url = url + 'sc_req_item.do?sys_id='+id+'&sysparm_record_target=incident'
    else
      url = url + 'u_manual_service_request.do?sys_id='+id+'&sysparm_record_target=incident'
    end
    return url
  end
end
