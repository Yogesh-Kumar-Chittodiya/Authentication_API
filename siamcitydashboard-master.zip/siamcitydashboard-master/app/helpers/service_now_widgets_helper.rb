module ServiceNowWidgetsHelper

  # incidents related widgets
  def incidentsData(data,labels,graph_type)
    data = [
      {
        'name' =>'Logged',
        'data' =>  get_data_in_field(data,'sys_created_on',labels,'date',graph_type,'column').map{|y,i| i}
      },
      {
        'name' => 'Closed',
        'data' =>  get_data_in_field(data,'closed_at',labels,'date',graph_type,'column').map{|y,i| i}

      }]
    return data,labels
  end

  # problems related widgets
  def problemsData(data,labels,graph_type)
    data = [
      {
        'name' =>'Logged',
        'data' =>  get_data_in_field(data,'sys_created_on',labels,'date',graph_type,'column').map{|y,i| i}
      },
      {
        'name' => 'Closed',
        'data' =>  get_data_in_field(data,'closed_at',labels,'date',graph_type,'column').map{|y,i| i}

      }]
    return data,labels
  end

  # service requests widgets
  def ServiceRequestsData(data,labels,graph_type)
    data = [
      {
        'name' =>'Logged',
        'data' =>  get_data_in_field(data,'sys_created_on',labels,'date',graph_type,'column').map{|y,i| i}
      },
      {
        'name' => 'Closed',
        'data' =>  get_data_in_field(data,'closed_at',labels,'date',graph_type,'column').map{|y,i| i}

      }]
    return data,labels
  end

  # change requests widgets
  def changesData(data,labels,graph_type)
    data = [
      {
        'name' =>'Logged',
        'data' =>  get_data_in_field(data,'sys_created_on',labels,'date',graph_type,'column').map{|y,i| i}
      },
      {
        'name' => 'Closed',
        'data' =>  get_data_in_field(data,'closed_at',labels,'date',graph_type,'column').map{|y,i| i}

      }]
    return data,labels
  end

  def getIncidentCurrentData(data,labels=["1 - Critical","2 - High","3 - Moderate","4 - Low"])
    # raise data.inspect
    data = [
      {
        'name' =>'Logged',
        'data' =>  get_data_in_field(data,'inc_priority',labels,true,['inc_sys_created_on',Date.today],'date')
      },
      {
        'name' =>'Closed',
        'data' =>  get_data_in_field(data,'inc_priority',labels,true,['inc_closed_at',Date.today],'date')
      }
    ]
    return data,labels
  end

  def incidentsDataReport(data,labels,graph_type)
    hashdata = get_hash(labels,graph_type,['logged'],['p1','p2','p3','p4','total'])
    # raise hashdata.inspect
    data.each do |sla|
      name = set_name(graph_type,sla,'sys_created_on')
      if hashdata[name].present?
        hashdata[name]['logged']['total'] += 1
        if sla['priority'] == '1'
            hashdata[name]['logged']['p1'] += 1
        elsif sla['priority'] == '2'
          hashdata[name]['logged']['p2'] += 1
        elsif sla['priority'] == '3'
          hashdata[name]['logged']['p3'] += 1
        elsif sla['priority'] == '4'
          hashdata[name]['logged']['p4'] += 1
        end

      end
    end
    data = get_data_high_charts(hashdata,'logged',['p1','p2','p3','p4'],'')
    labels = get_labels(hashdata)
    return hashdata,data,labels
  end

  def incidentAgeing(incidentdata)
    currentdate = Date.today
    labels = ['0-10','10-20','20-30','30-40','40 +']
    hashdata = Hash.new
    labels.each do |label|
      hashdata[label] = 0
    end

    incidentdata = incidentdata.select{|data| data['sys_created_by'].downcase.to_s != "eurostar_opsramp"}.map{|y|y}

    incidentdata = incidentdata.select{|device| device['assignment_group'] != 'ad2f0991db77fa403eb17e400f9619f2' and device['assignment_group'] != '989e415ddb77fa403eb17e400f9619ba' and device['assignment_group'] != '5b7f4d9ddb77fa403eb17e400f961981'}.map{|y|y}

    # showing only New,In progress,Assigned,On Hold Tickets
    incidentdata = incidentdata.select{|dat| ["1","2","3","10"].include?(dat['state']) }.map{|y|y}
    incidentdata.each do |d|
      days = (currentdate - Date.parse(d['sys_created_on'])).to_i
      if(days >= 0 && days < 10)
        hashdata['0-10'] += 1
      elsif(days >= 10 && days < 20)
        hashdata['10-20'] += 1
      elsif(days >= 20 && days < 30)
        hashdata['20-30'] += 1
      elsif(days >= 30 && days < 40)
        hashdata['30-40'] += 1
      else
        hashdata['40 +'] += 1
      end
    end
    bardata = Array.new
    hashdata.each do |hd|
      bardata.push(hd[1])
    end
    retdata = [{
      name: 'Number of Tickets',
      data: bardata,
      color: '#fdbc02'
    }]
    return retdata,labels
  end

  def customerSatisfactionRate(data,labels,graph_type)
    bardata = get_data_in_field(data,'mr_sys_updated_on',labels,'date',graph_type,'column','mr_metric_definition','field' ,['Extremely Satisfied','Satisfied','Not Satisfied'])
    return bardata,labels
  end

  def customerSatisfaction(data,labels,graph_type)
    response = data['Response']
    datedata = data['Conditions']['created_on']
    responselabels = ['Not Responded','Responded']
    feedbacklabels = ['Extremely Satisfied','Responded']
    responsedata = [
      { name: 'Not Responded',
        y: (response['Total'] - response['Responded']),
        start_date: datedata['start_on'],
        end_date: datedata['end_on']
      },
      { name: 'Responded',
        y: response['Responded'],
        start_date: datedata['start_on'],
        end_date: datedata['end_on']
      }
    ]
    feedbackdata = [
      { name: 'Extremely Satisfied',
        y: response['Extremely Satisfied'],
        start_date: datedata['start_on'],
        end_date: datedata['end_on']
      },
      { name: 'Satisfied',
        y: response['Satisfied'],
        start_date: datedata['start_on'],
        end_date: datedata['end_on']
      },
      { name: 'Not Satisfied',
        y: response['Not Satisfied'],
        start_date: datedata['start_on'],
        end_date: datedata['end_on']
      }
    ]
    return responsedata,responselabels,feedbackdata,feedbacklabels
  end

  def auto_resolved_incidents(data,labels,graph_type)
    hiro_inc = ['ad2f0991db77fa403eb17e400f9619f2','989e415ddb77fa403eb17e400f9619ba']
    hashdata = get_hash(labels,graph_type,['assigned','resolved'],'')
    data = data.select{|device| hiro_inc.include?device['assignment_group'] or hiro_inc.include?device['resolved_by']}.map{|y| y}
    data.each do |sla|
      assigned_name = set_name(graph_type,sla,'sys_updated_on')
      if hashdata[assigned_name].present?
        if sla['assignment_group'].present? && sla['assignment_group'] != ''
          if hiro_inc.include?sla['assignment_group']
           hashdata[assigned_name]['assigned'] += 1
          end
        end
      end
      if sla['resolved_at'].present? && sla['resolved_at'] != ''
        resolved_name = set_name(graph_type,sla,'resolved_at')
        if hashdata[resolved_name].present?
           hashdata[resolved_name]['resolved'] += 1
        end
      end
    end
    data = get_data_high_charts(hashdata,'',['assigned','resolved'],'')
    labels = get_labels(hashdata)
    return data,labels
  end

  def openChangeRequestsByTeam(data)
    # raise data.inspect
    ticketsdata = Hash.new
    groups = ServicenowGroup.all
    data.each do |da|
      if groups.map{|a| a.sys_id}.include? da['assignment_group']
        name = groups.select{ |a| a.sys_id == da['assignment_group']}[0].name
          unless  ticketsdata[name].present?
            ticketsdata[name] = Hash.new
            ticketsdata[name]['tickets'] = 0
          end
          ticketsdata[name]['tickets'] += 1
      end
    end
    return ticketsdata
  end

  def changeRequestStats(data)
    hashdata = Hash.new
    hashdata['waiting-approval'] = 0
    hashdata['waiting-implementation'] = 0
    hashdata['open-emergency-change-request'] = 0
    hashdata['closed-change-request'] = 0
    newdata = data.select{|d| d['state'] != 3 and d['state'] != 4 and d['type'] == 'emergency'}.map{|y|y}
    hashdata['open-emergency-change-request'] = newdata.count
    data.each do |da|
      if da['state'] == '-3'
        hashdata['waiting-approval'] += 1
      elsif da['state'] == '-2'
        hashdata['waiting-implementation'] += 1
      elsif da['state'] == '3' || da['state'] == '4'
        hashdata['closed-change-request'] += 1
      end
    end
    return hashdata
  end

  def openChangeRequestByStatus(data)
    hashdata = get_hash(['New','Assess','Authorize','Scheduled','Implement','Review'],'',['change requests'],'')
    # raise data.inspect
    data.each do |da|
      if da['state'] == '-5'
        hashdata['New']['change requests'] += 1
      elsif da['state'] == '-4'
        hashdata['Assess']['change requests'] += 1
      elsif da['state'] == '-3'
        hashdata['Authorize']['change requests'] += 1
      elsif da['state'] == '-2'
        hashdata['Scheduled']['change requests'] += 1
      elsif da['state'] == '-1'
        hashdata['Implement']['change requests'] += 1
      elsif da['state'] == '0'
        hashdata['Review']['change requests'] += 1
      end
    end

    barlabels = get_labels(hashdata)
    barData = get_data_high_charts(hashdata,'',['change requests'],'')
    # raise barData.inspect
    # barData = barData.map{|dat| dat['open tickets']}
    # raise barData.inspect
    return barData,barlabels
  end

  def openChangeRequestByType(data)

    hashdata = get_hash(['Emergency','Normal','Standard'],'',['change requests'],'')
    # raise data.inspect
    data.each do |da|
      if da['type'] == 'normal'
        hashdata['Normal']['change requests'] += 1
      elsif da['type'] == 'standard'
        hashdata['Standard']['change requests'] += 1
      elsif da['type'] == 'emergency'
        hashdata['Emergency']['change requests'] += 1
      end
    end
    barlabels = get_labels(hashdata)
    barData = get_data_high_charts(hashdata,'',['change requests'],'')
    # raise barData.inspect
    # barData = barData.map{|dat| dat['open tickets']}
    # raise barData.inspect
    return barData,barlabels
  end

  def openTicketsByStatus(data)
    labels = ['New','Assigned','On Hold','Work in Progress']
    hashdata = get_hash(labels,'',['incidents'],'')
    # raise data.inspect
    data.each do |da|
      if da['state'] == '1'
        hashdata['New']['incidents'] += 1
      elsif da['state'] == '3'
        hashdata['On Hold']['incidents'] += 1
      elsif da['state'] == '10'
        hashdata['Assigned']['incidents'] += 1
      elsif da['state'] == '2'
        hashdata['Work in Progress']['incidents'] += 1
      end
    end

    # barlabels = get_labels(hashdata)
    barData = get_pie_data(hashdata,'incidents')
    # raise barData.inspect
    return barData,labels
  end

  def openTicketsByPriority(data)
    hashdata = get_hash(['P1','P2','P3','P4'],'',['incidents'],'')
    data.each do |da|
      if da['priority'] == '1'
        hashdata['P1']['incidents'] += 1
      elsif da['priority'] == '2'
        hashdata['P2']['incidents'] += 1
      elsif da['priority'] == '3'
        hashdata['P3']['incidents'] += 1
      elsif da['priority'] == '4'
        hashdata['P4']['incidents'] += 1
      end
    end

    bardata = get_data_high_charts(hashdata,'',['incidents'],[COLOURS['red'],COLOURS['amber'],COLOURS['green'],COLOURS['blue']])
    barlabels = get_labels(hashdata)
    # raise bardata.inspect
    piedata = get_pie_data(hashdata,'incidents')
    piedata = piedata.map{|device,count| count }
    return bardata,piedata,barlabels
  end

  def openTicketsByCategory(data)
    labels = ['BUSINESS APPLICATIONS','DATA CENTRE','DISTRIBUTION SYSTEMS','EUROSTAR.COM','IN-STATION SERVICES','SECURITY','Eurostar MOBILE','ON-BOARD SERVICES','USER EQUIPMENT','VOICE AND DATA SERVICES','WORKSTATION SERVICES']
    hashdata = get_hash(labels,'',['incidents'],'')
    # raise data.inspect
    data.each do |da|
      new_label = labels.select { |a| a == da['category'] }
        if !new_label.empty?
        hashdata[new_label[0]]['incidents']  += 1
        end
      end
      bardata = get_data_high_charts(hashdata,'',['incidents'],'')
      barlabels = get_labels(hashdata)
    # barlabels = get_labels(hashdata)
    # barData = get_pie_data(hashdata,'incidents')
    # raise barData.inspect
    return bardata,barlabels
  end

  def openTicketsByResolverGroup(data)
    ticketsdata = Hash.new
    groups = ServicenowGroup.all
    data.each do |da|
      if groups.map{|a| a.sys_id}.include? da['assignment_group']
        name = groups.select{ |a| a.sys_id == da['assignment_group']}[0].name
          unless  ticketsdata[name].present?
            ticketsdata[name] = Hash.new
            ticketsdata[name]['tickets'] = 0
          end
          ticketsdata[name]['tickets'] += 1
      end
    end
    ticketsdata = ticketsdata.sort_by{|hash,ind| ind['tickets'].to_i}.reverse
    series = Array.new
    count = 0
    ticketsdata.each do |d|
      if count < 6
        ser = Hash.new
        ser['name'] = d[0]
        ser['y'] = d[1]['tickets']
        series.push(ser)
        count += 1
      else
        break
      end
    end
    # raise series.inspect
    return series
  end

  def resolutionAutomationIndex(incident_resolved,graph_type,labels)
    @resolved_incidents = get_hash(labels,graph_type,['auto','manual'],['p1','p2','p3','p4'])
    @count = 1
    hiro_inc = ['ad2f0991db77fa403eb17e400f9619f2','989e415ddb77fa403eb17e400f9619ba','5b7f4d9ddb77fa403eb17e400f961981']
    incident_resolved.each do |sla|
      if sla['resolved_at'].present?
        name = set_name(graph_type,sla,'resolved_at')
        if @resolved_incidents[name].present?
          @count = @count + 1
          # check resolver
          resolver = (hiro_inc.include?sla['assignment_group']) ? 'auto' : 'manual'
          if resolver == 'auto'
            if sla['priority'].to_i <= 4
            @resolved_incidents[name]['auto']["p#{sla['priority'].to_i}"] += 1
            end
          else
            if sla['priority'].to_i <= 4 && sla['sys_created_by'].downcase != 'eurostar_opsramp'
              @resolved_incidents[name]['manual']["p#{sla['priority'].to_i}"] += 1
            end
          end
        end
      end
    end
    autodata = get_data_high_charts(@resolved_incidents,'auto',['p1','p2','p3','p4'],'')
    autodata = set_colors([COLOURS['red'],COLOURS['amber'],COLOURS['blue'],COLOURS['green']],autodata)
    labels = get_labels(@resolved_incidents)
    manualdata = get_data_high_charts(@resolved_incidents,'manual',['p1','p2','p3','p4'],'')
    manualdata = set_colors([COLOURS['red'],COLOURS['amber'],COLOURS['blue'],COLOURS['green']],manualdata)
    return autodata,manualdata,labels
  end

  def slaStatistics(total_incident_sla,graph_type,labels)
    sla_statistics = get_hash(labels,graph_type,['met','breached'],['p1','p2','p3','p4'])
    count = 1
    total_incident_sla.each do |sla|
      name = set_name(graph_type,sla,'inc_sys_created_on')
      if sla_statistics[name].present?
        if sla['taskslatable_has_breached']
          if sla['inc_priority'].to_i <= 4
            sla_statistics[name]['breached']["p#{sla['inc_priority'].to_i}"] +=  1
          end
        else
          if sla['inc_priority'].to_i <= 4
            sla_statistics[name]['met']["p#{sla['inc_priority'].to_i}"] += 1
          end
        end
      end
    end
    # raise sla_statistics.inspect
    slamet = get_data_high_charts(sla_statistics,'met',['p1','p2','p3','p4'],'',['yes','yes','yes','no'])
    slamet = set_colors([COLOURS['red'],COLOURS['amber'],COLOURS['blue'],COLOURS['green']],slamet)
    labels = get_labels(sla_statistics)
    slabreached = get_data_high_charts(sla_statistics,'breached',['p1','p2','p3','p4'],'',['yes','yes','yes','no'])
    slabreached = set_colors([COLOURS['red'],COLOURS['amber'],COLOURS['blue'],COLOURS['green']],slabreached)
    return slamet,slabreached,labels
  end

  def incidentOrigin(total_incident_sla,graph_type,labels)
    incident_origin = get_hash(labels,graph_type,['auto','manual'],['p1','p2','p3','p4'])
    count = 1

    total_incident_sla.each do |sla|
      name = set_name(graph_type,sla,'sys_created_on')
      if incident_origin[name].present?

        # check creator
        creator = (sla['contact_type'].downcase.to_s == "event monitoring") ? 'auto' : 'manual'
        if creator == 'auto'
          if sla['priority'].to_i <= 4
            incident_origin[name]['auto']["p#{sla['priority'].to_i}"] = incident_origin[name]['auto']["p#{sla['priority'].to_i}"] + 1
          end
        else
          if sla['priority'].to_i <= 4
            incident_origin[name]['manual']["p#{sla['priority'].to_i}"] = incident_origin[name]['manual']["p#{sla['priority'].to_i}"] + 1
          end
        end
      end
    end
    autocreated = get_data_high_charts(incident_origin,'auto',['p1','p2','p3','p4'],'')
    autocreated = set_colors([COLOURS['red'],COLOURS['amber'],COLOURS['blue'],COLOURS['green']],autocreated)
    labels = get_labels(incident_origin)
    manualcreated = get_data_high_charts(incident_origin,'manual',['p1','p2','p3','p4'],'')
    manualcreated = set_colors([COLOURS['red'],COLOURS['amber'],COLOURS['blue'],COLOURS['green']],manualcreated)
    return autocreated,manualcreated,labels
  end

  # generic methods for all

  private

  def get_data_in_time(data,field,labels,graph_type = 'day')
    data_hash = Hash[labels.collect{|i| [i,0]}]
    if graph_type == "month"
      data.group_by{|y| (y[field.to_sym] != "") ? y[field.to_sym].to_time.strftime("%b-%y") : ''}.select{ |i,x| data_hash.key?(i.to_s)}.sort_by{|i,x| i}.each{|i,x| data_hash[i] = x.count}
    else
      data.group_by{|y| (y[field.to_sym] != "") ? y[field.to_sym].to_time.strftime("%Y-%m-%d") : ''}.select{ |i,x| data_hash.key?(i.to_s)}.sort_by{|i,x| i}.each{|i,x| data_hash[i] = x.count}
    end
    return data_hash
  end

  def get_data_in_field(data,label_field,labels,label_type,graph_type,chart_type,mul_col_field = '',mul_col_type = '' ,mul_col_labels = [])

    data_hash = Hash[labels.collect{|i| [i,0]}]
    if chart_type == 'column'
      if mul_col_field != ''
        data = data.select{|y| mul_col_labels.include? (y[mul_col_field.to_sym])}.map{|y|y}
        if label_type == 'date'
          if graph_type == 'day'
            data = data.group_by{|y| (y[label_field.to_sym] != "") ? y[label_field.to_sym].to_time.strftime("%Y-%m-%d") : ''}.select{ |i,x| data_hash.key?(i.to_s)}.sort_by{|i,x| i}
          else
            data = data.group_by{|y| (y[label_field.to_sym] != "") ? y[label_field.to_sym].to_time.strftime("%b-%y") : ''}.select{ |i,x| data_hash.key?(i.to_s)}
          end
          data.each do |y|
            ret = {}
            y[1].group_by{|x|x[mul_col_field.to_sym]}.each do |x,i|
              ret[x] = i.count
            end
            data_hash[y[0]] = ret
          end
        else
        end
        chart_data = []
        mul_col_labels.each do |l|
          chart_data.push({
            'name' => l,
            'data' => data_hash.map{|i,y| y[l]}
          })
        end
        data_hash = chart_data
      else
        if label_type == 'date'
          if graph_type == 'day'
            data.group_by{|y| (y[label_field.to_sym] != "") ? y[label_field.to_sym].to_time.strftime("%Y-%m-%d") : ''}.select{ |i,x| data_hash.key?(i.to_s)}.sort_by{|i,x| i}.each{|i,x| data_hash[i] = x.count}
          elsif graph_type == 'month'
            data.group_by{|y| (y[label_field.to_sym] != "") ? y[label_field.to_sym].to_time.strftime("%b-%y") : ''}.select{ |i,x| data_hash.key?(i.to_s)}.sort_by{|i,x| i}.each{|i,x| data_hash[i] = x.count}
          else
          end
        else
        end
      end
    elsif chart_type == 'pie'
      data_hash = pie_data
    else
    end
    return data_hash
  end

  def get_data_in_percentage(data,field,labels)

  end

end
