module ModelReportHelper
  include Pagy::Frontend
end
