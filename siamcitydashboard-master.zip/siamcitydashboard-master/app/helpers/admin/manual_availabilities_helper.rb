module Admin::ManualAvailabilitiesHelper
end
