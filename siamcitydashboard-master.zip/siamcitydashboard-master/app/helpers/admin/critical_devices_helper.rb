module Admin::CriticalDevicesHelper
end
