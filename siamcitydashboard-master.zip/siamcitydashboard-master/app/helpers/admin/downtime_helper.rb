module Admin::DowntimeHelper
end
