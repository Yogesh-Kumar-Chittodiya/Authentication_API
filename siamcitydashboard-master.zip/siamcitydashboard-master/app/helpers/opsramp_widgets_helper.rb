module OpsrampWidgetsHelper

  include Opsramp

  def get_sap_response(sap_responses)
    ratings = sap_responses.map{|sap| sap['kpi_rating']}
    status = ''
    border_status = ''
    if ratings.include? 'R'
      status = 'Red'
      border_status = 'danger'
    elsif ratings.include? 'Y'
      status = '#ffbf00'
      border_status = 'warning'
    else
      status = 'Green'
      border_status = 'success'
    end
    data = {:status=>status,:availability=>'Dialog Response',:color=>border_status ,:title=> 'System Performance (SAP)',:url=>system_performance_sap_opsramp_reports_path,:icon=>'dashboard' }
    return data
  end

  def get_sap_availability
    sap_applications = SapApplication.all
    sap_applications_check(sap_applications)
    sap_status = ''
    border_sap = ''
    sap_applications.each do |app|
      if app.sla_breached || app.status == 'red'
        sap_status = 'red'
        border_sap = 'danger'
      elsif app.status == 'amber'
        sap_status = 'amber'
        border_sap = 'warning'
      else
        sap_status = 'green'
        border_sap = 'success'
      end
    end
    data = {:status=>sap_status,:color=>border_sap, :title=> 'System Availability (SAP)',:url=>system_availability_sap_opsramp_reports_path,:icon=>'database' }
    return data
  end
end
