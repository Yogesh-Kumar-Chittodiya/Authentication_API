module DowntimesHelper
end
