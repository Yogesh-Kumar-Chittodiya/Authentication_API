


service mysql status | grep 'active (running)' > /dev/null 2>&1

if [ $? != 0 ]
then
        sudo service mysql restart > /dev/null
fi