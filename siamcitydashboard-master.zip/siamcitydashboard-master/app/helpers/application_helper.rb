module ApplicationHelper

  def current_customer_image()
    if current_user.customer_id > 0 and current_user.customer.present? and current_user.customer.logo.present?
      image_tag(current_user.customer.logo_url, :width=>"100px", :style=>"margin-top: 20px")
    end
  end
 
  def get_customer_name()
    if params[:customer].present? or Customer.all.count == 1
      cust = (params[:customer].present?) ? Customer.where(:api_customer_id=>params[:customer]).first : Customer.first      
      return "<strong>Customer </strong> : {customer_name}".html_safe
    end
  end

   # Initialize Hash
  def get_hash(labels,graph_type,types,datatypes)
    data = Hash.new
    display_name = ''
    name=''
    labels.each do |labelname|
      if graph_type == 'day'
        name = labelname.to_time.strftime("%d-%b-%y")
        display_name = labelname.to_time.strftime("%d-%b-%y")
      elsif graph_type == 'month'
        name = labelname
        display_name = labelname
      else
        name = labelname
        display_name = labelname
      end
      data[name] = Hash.new()
      data[name]['display_name'] = display_name
      types.each do |type|
        if(datatypes != '')
          data[name][type] = Hash.new()
          datatypes.each do |datatype|
            data[name][type][datatype] = 0
          end
        else
          data[name][type] = 0
        end
      end
    end
    return data
  end
  # end

  def get_pie_data(data,label,extra_field = '')
    piedata = Hash.new
    data.each_with_index do |d,index|
      piedata[d[0]] = Hash.new
      piedata[d[0]]['name'] = d[0]
      piedata[d[0]]['y'] = d[1][label]
      if extra_field != ''
        piedata[d[0]]['extra_field'] = extra_field
      end
    end
    piedata = piedata.map{|device,count| count }
    return piedata
  end

  # check daytype and set name
  def set_name(graph_type,field,variable)
    if graph_type == 'day'
      return field[variable.to_sym].to_time.strftime("%d-%b-%y")
    elsif graph_type == 'month'
      return field[variable.to_sym].to_time.strftime("%b-%y")
    else
      return field[variable.to_sym].to_time.strftime("%B")
    end
  end
  # end

  # Get Labels form the passed data
  def get_labels(chartdata)
    return chartdata.map{|date,count| date }
  end
  # end

  def set_colors(colors,data)
    data.each_with_index do |label,index|
      label['color'] = colors[index]
    end
    # raise data.inspect
  end

  # Get Labels form the passed data
  def get_raw_data(chartdata,device)
    bardata = Array.new
    chartdata.each_with_index do |data,index|
      dat = Hash.new
      dat['y'] = data[1]
      if data[0] == '80-100'
        dat['color'] = COLOURS['red']
      elsif  data[0] == '60-80'
        dat['color'] = COLOURS['amber']
      elsif  data[0] == '40-60'
        dat['color'] = COLOURS['green']
      else
        dat['color'] = COLOURS['blue']
      end
      bardata.push(dat)
    end
    bardatanew = [{
      name: device+' devices',
      data:  bardata
    }]
    return bardatanew
  end
  # end

  # get data for highcharts
  def get_data_high_charts(chartdata,type,labels,colors,visibility = [])
    if type != ''
      data = Hash.new
      labels.each_with_index do |label,key|
        data[label] = Hash.new
        data[label]['name'] =label.titleize
        puts "--------#{key}-------------#{visibility[key]}----#{(visibility[key].present?)}----------------"
        data[label]['visible'] = (visibility[key].present? and visibility[key] == "no") ? false : true
        data[label]['data'] = chartdata.map{|date,count| count[type][label]}
      end
    else
      data = Hash.new
      labels.each_with_index do |label,key|
        data[label] = Hash.new
        data[label]['name'] =label.titleize
        data[label]['visible'] = (visibility[key].present? and visibility[key] == "no") ? false : true
        data[label]['data'] = chartdata.map{|date,count| count[label]}
      end
    end

    data = data.map{|date,count| count}
    return data
  end

  # get data for highcharts
  def get_data_charts_drilldown(chartdata,type,labels,colors,visibility = [])
    if type != ''
      data = Hash.new
      labels.each_with_index do |label,key|
        data[label] = Hash.new
        data[label]['name'] =label.titleize
        data[label]['visible'] = (visibility[key].present? and visibility[key] == "no") ? false : true
        data[label]['y'] = chartdata.map{|date,count| count[type][label]}
        data[label]['drilldown'] = label
      end
    end

    data = data.map{|date,count| count}
    return data
  end

  def get_percentage_data(data_set)
    bardata = Hash.new
    bardata['20-40'] = 0
    bardata['40-60'] = 0
    bardata['60-80'] = 0
    bardata['80-100'] = 0
    data_set.each do |data|
      per = data['utilization'].to_i
      if(per >= 0 &&  per < 40)
        bardata['20-40'] += 1
      elsif (per >= 40 &&  per < 60)
        bardata['40-60'] += 1
      elsif (per >= 60 &&  per < 80)
        bardata['60-80'] += 1
      else
        bardata['80-100'] += 1
      end
    end
    return bardata
  end

end
