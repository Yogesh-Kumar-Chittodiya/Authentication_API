module PdfReportsHelper
end
