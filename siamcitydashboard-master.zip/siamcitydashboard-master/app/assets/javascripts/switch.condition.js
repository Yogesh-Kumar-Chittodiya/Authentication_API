function getValues(chart) {
  console.log(chart);
  var device_category = '';
  var status = ''
  var prefix = ''
  var type_chart = chart.series.chart.renderTo.id;
  // alert(type_chart);
  switch (type_chart) {
    case "openticketsbyteam":
      device_category = chart.name;
      prefix = ROOT + 'service_now_reports/open_incidents' + '?label=' + device_category+"&type=team";
      break;
    case "inventory":
      device_category = chart.name;
      prefix = ROOT + 'opsramp_reports/inventory' + '?status=' + device_category;
      break;
    case "incidents_data":
      device_category = chart.category;
      status = chart.series.name;
      prefix = ROOT + 'service_now_reports/incidents' + '?day_type=' + device_category + '&status=' + status.toUpperCase();
      break;
    case "incident_current_status":
        device_category = chart.category;
        status = chart.series.name;
        prefix = ROOT + 'service_now_reports/incident_current_status' + '?priority=' + device_category + '&status=' + status.toUpperCase();
        break;
    case "auto_resolved_incidents":
      device_category = chart.category;
      status = chart.series.name;
      prefix = ROOT + 'service_now_reports/auto_incidents_hiro' + '?day_type=' + device_category + '&status=' + status.toUpperCase();
      break;
    case "incidents_data_by_state":
      device_category = chart.name;
      prefix = ROOT + 'service_now_reports/open_incidents' + '?type=state&label=' + device_category;
      break;

    case "problems_data":
      device_category = chart.category;
      status = chart.series.name;
      prefix = ROOT + 'service_now_reports/problems' + '?day_type=' + device_category + '&status=' + status.toUpperCase();
      break;
    case "CSRATE":
      month = chart.category;
      type = chart.series.name;
      prefix = ROOT + 'service_now_reports/customer_satisfaction' + '?type=' + type + '&day_type=' + month;
      break;
    case "service_requests_data":
      device_category = chart.category;
      status = chart.series.name;
      prefix = ROOT + 'service_now_reports/service_requests' + '?day_type=' + device_category + '&status=' + status.toUpperCase();
      break;
    case "customer_satisfaction":
      device_category = chart.name;
      type = 'total';
      start_date = chart.start_date
      end_date = chart.end_date
      prefix = ROOT + 'service_now_reports/customer_feedback' + '?start_date=' + start_date + '&feedback=' + device_category+'&end_date=' + end_date+'&type='+type;
      break;
    case "customer_feedback":
      device_category = chart.name;
      type = 'feedback';
      start_date = chart.start_date
      end_date = chart.end_date
      prefix = ROOT + 'service_now_reports/customer_feedback' + '?start_date=' + start_date + '&feedback=' + device_category+'&end_date=' + end_date+'&type='+type;
    break;
    case "change_data":
      device_category = chart.category;
      status = chart.series.name;
      prefix = ROOT + 'service_now_reports/change_requests' + '?day_type=' + device_category + '&status=' + status.toUpperCase();
      break;
    case "sla_resolution_met":
      month = chart.category;
      priority = chart.series.name;
      prefix = ROOT + 'service_now_reports/sla_statistics' + '?priority=' + priority + '&day_type=' + month + '&type=met' + '&graph_type=' + graph_type;
      break;
    case "sla_resolution_breached":
      month = chart.category;
      priority = chart.series.name;
      prefix = ROOT + 'service_now_reports/sla_statistics' + '?priority=' + priority + '&day_type=' + month + '&type=breached' + '&graph_type=' + graph_type;
      break;
    case "autoresolved":
      month = chart.category;
      priority = chart.series.name;
      prefix = ROOT + 'service_now_reports/resolution_automation' + '?priority=' + priority + '&day_type=' + month + '&type=auto' + '&graph_type=' + graph_type;
      break;
    case "manualresolved":
      month = chart.category;
      priority = chart.series.name;
      prefix = ROOT + 'service_now_reports/resolution_automation' + '?priority=' + priority + '&day_type=' + month + '&type=manual' + '&graph_type=' + graph_type;
      break;
    case "tickets_ageing":
      duration = chart.category;
      prefix = ROOT + 'service_now_reports/incidents_open' + '?duration=' + duration;
      break;
    default:
      prefix = '#';
  }
  if (prefix == '#') {
    title = chart.series.name
    var pattern1 = new RegExp("Service Status");
    var pattern2 = new RegExp("devices");
    var pattern3 = new RegExp("Incidents");
    var pattern4 = new RegExp("Change Requests");
    if ((pattern3).test(title)) {
      var label = chart.category;
      if (['P1', 'P2', 'P3', 'P4'].includes(label)) {
        prefix = ROOT + 'service_now_reports/open_incidents' + '?type=priority&label=' + label;
      } else{
        prefix = ROOT + 'service_now_reports/open_incidents' + '?type=category&label=' + label;
      }
    } else if ((pattern4).test(title)) {
      var label = chart.category;
      if (['Emergency', 'Normal', 'Standard'].includes(label)) {
        prefix = ROOT + 'service_now_reports/open_change_requests' + '?type=type&label=' + label;
      } else {
        prefix = ROOT + 'service_now_reports/open_change_requests' + '?type=state&label=' + label;
      }
    } else {

    }
  }

  if (customer != '') {
    var URI = prefix + '&customer=' + customer;
  } else {
    var URI = prefix;
  }
  // alert(URI);
  // window.location = URI;
  window.open(URI, '_blank');
}
