//= require jquery
//= require rails-ujs
//= require bootstrap.min.js
//= require bootstrap-datepicker.js
//= require daterangepicker.js
//= require jquery.slimscroll.min.js
//= require jquery.dataTables.min.js

// require chartkick
//= require highcharts
//= require drilldown
// require series-label
//= require switch.condition
//= require jquery.smartTab.min.js
//= require refresh_data
//= require select2
//= require jquery.totemticker
//= require adminlte.min.js

Highcharts.setOptions({
  colors: ['#2eb85a','#0070C0','#fdbc02','#ff5d5d','#FF9655', '#FFF263', '#6AF9C4'],
  chart: {
    style: {
      fontFamily: 'Open Sans'
    }
  }
});

$(document).ready(function() {
  $(".select2").select2({ width: '100%' });
})


$(document).ready(function() {
    $('#datatablenew').DataTable({
        pageLength:25,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel','print'
        ]
    })
});
