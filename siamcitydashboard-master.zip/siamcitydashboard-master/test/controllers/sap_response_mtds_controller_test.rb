require 'test_helper'

class SapResponseMtdsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @sap_response_mtd = sap_response_mtds(:one)
  end

  test "should get index" do
    get sap_response_mtds_url
    assert_response :success
  end

  test "should get new" do
    get new_sap_response_mtd_url
    assert_response :success
  end

  test "should create sap_response_mtd" do
    assert_difference('SapResponseMtd.count') do
      post sap_response_mtds_url, params: { sap_response_mtd: { kpi_date: @sap_response_mtd.kpi_date, kpi_name: @sap_response_mtd.kpi_name, kpi_rating: @sap_response_mtd.kpi_rating, kpi_time: @sap_response_mtd.kpi_time, kpi_value: @sap_response_mtd.kpi_value } }
    end

    assert_redirected_to sap_response_mtd_url(SapResponseMtd.last)
  end

  test "should show sap_response_mtd" do
    get sap_response_mtd_url(@sap_response_mtd)
    assert_response :success
  end

  test "should get edit" do
    get edit_sap_response_mtd_url(@sap_response_mtd)
    assert_response :success
  end

  test "should update sap_response_mtd" do
    patch sap_response_mtd_url(@sap_response_mtd), params: { sap_response_mtd: { kpi_date: @sap_response_mtd.kpi_date, kpi_name: @sap_response_mtd.kpi_name, kpi_rating: @sap_response_mtd.kpi_rating, kpi_time: @sap_response_mtd.kpi_time, kpi_value: @sap_response_mtd.kpi_value } }
    assert_redirected_to sap_response_mtd_url(@sap_response_mtd)
  end

  test "should destroy sap_response_mtd" do
    assert_difference('SapResponseMtd.count', -1) do
      delete sap_response_mtd_url(@sap_response_mtd)
    end

    assert_redirected_to sap_response_mtds_url
  end
end
