require 'test_helper'

class SapResponseDailiesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @sap_response_daily = sap_response_dailies(:one)
  end

  test "should get index" do
    get sap_response_dailies_url
    assert_response :success
  end

  test "should get new" do
    get new_sap_response_daily_url
    assert_response :success
  end

  test "should create sap_response_daily" do
    assert_difference('SapResponseDaily.count') do
      post sap_response_dailies_url, params: { sap_response_daily: { kpi_date: @sap_response_daily.kpi_date, kpi_name: @sap_response_daily.kpi_name, kpi_rating: @sap_response_daily.kpi_rating, kpi_time: @sap_response_daily.kpi_time, kpi_value: @sap_response_daily.kpi_value } }
    end

    assert_redirected_to sap_response_daily_url(SapResponseDaily.last)
  end

  test "should show sap_response_daily" do
    get sap_response_daily_url(@sap_response_daily)
    assert_response :success
  end

  test "should get edit" do
    get edit_sap_response_daily_url(@sap_response_daily)
    assert_response :success
  end

  test "should update sap_response_daily" do
    patch sap_response_daily_url(@sap_response_daily), params: { sap_response_daily: { kpi_date: @sap_response_daily.kpi_date, kpi_name: @sap_response_daily.kpi_name, kpi_rating: @sap_response_daily.kpi_rating, kpi_time: @sap_response_daily.kpi_time, kpi_value: @sap_response_daily.kpi_value } }
    assert_redirected_to sap_response_daily_url(@sap_response_daily)
  end

  test "should destroy sap_response_daily" do
    assert_difference('SapResponseDaily.count', -1) do
      delete sap_response_daily_url(@sap_response_daily)
    end

    assert_redirected_to sap_response_dailies_url
  end
end
