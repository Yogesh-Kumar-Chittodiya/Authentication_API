require 'test_helper'

class Admin::BackupReportsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @admin_backup_report = admin_backup_reports(:one)
  end

  test "should get index" do
    get admin_backup_reports_url
    assert_response :success
  end

  test "should get new" do
    get new_admin_backup_report_url
    assert_response :success
  end

  test "should create admin_backup_report" do
    assert_difference('Admin::BackupReport.count') do
      post admin_backup_reports_url, params: { admin_backup_report: { country: @admin_backup_report.country, data: @admin_backup_report.data, month: @admin_backup_report.month } }
    end

    assert_redirected_to admin_backup_report_url(Admin::BackupReport.last)
  end

  test "should show admin_backup_report" do
    get admin_backup_report_url(@admin_backup_report)
    assert_response :success
  end

  test "should get edit" do
    get edit_admin_backup_report_url(@admin_backup_report)
    assert_response :success
  end

  test "should update admin_backup_report" do
    patch admin_backup_report_url(@admin_backup_report), params: { admin_backup_report: { country: @admin_backup_report.country, data: @admin_backup_report.data, month: @admin_backup_report.month } }
    assert_redirected_to admin_backup_report_url(@admin_backup_report)
  end

  test "should destroy admin_backup_report" do
    assert_difference('Admin::BackupReport.count', -1) do
      delete admin_backup_report_url(@admin_backup_report)
    end

    assert_redirected_to admin_backup_reports_url
  end
end
