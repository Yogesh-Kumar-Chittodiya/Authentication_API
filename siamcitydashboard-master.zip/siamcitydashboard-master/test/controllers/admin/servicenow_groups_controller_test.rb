require 'test_helper'

class Admin::ServicenowGroupsControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
