require 'test_helper'

class Admin::ManualAvailabilitiesControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
