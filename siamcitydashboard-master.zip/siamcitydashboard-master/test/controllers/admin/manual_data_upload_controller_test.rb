require 'test_helper'

class Admin::ManualDataUploadControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
