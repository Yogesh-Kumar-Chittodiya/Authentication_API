require 'test_helper'

class Admin::CustomerSatisfactionScoresControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
