require 'test_helper'

class Admin::SolarwindInterfaceDowntimeControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
