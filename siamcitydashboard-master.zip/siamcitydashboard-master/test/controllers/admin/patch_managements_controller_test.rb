require 'test_helper'

class Admin::PatchManagementsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @admin_patch_management = admin_patch_managements(:one)
  end

  test "should get index" do
    get admin_patch_managements_url
    assert_response :success
  end

  test "should get new" do
    get new_admin_patch_management_url
    assert_response :success
  end

  test "should create admin_patch_management" do
    assert_difference('Admin::PatchManagement.count') do
      post admin_patch_managements_url, params: { admin_patch_management: {  } }
    end

    assert_redirected_to admin_patch_management_url(Admin::PatchManagement.last)
  end

  test "should show admin_patch_management" do
    get admin_patch_management_url(@admin_patch_management)
    assert_response :success
  end

  test "should get edit" do
    get edit_admin_patch_management_url(@admin_patch_management)
    assert_response :success
  end

  test "should update admin_patch_management" do
    patch admin_patch_management_url(@admin_patch_management), params: { admin_patch_management: {  } }
    assert_redirected_to admin_patch_management_url(@admin_patch_management)
  end

  test "should destroy admin_patch_management" do
    assert_difference('Admin::PatchManagement.count', -1) do
      delete admin_patch_management_url(@admin_patch_management)
    end

    assert_redirected_to admin_patch_managements_url
  end
end
