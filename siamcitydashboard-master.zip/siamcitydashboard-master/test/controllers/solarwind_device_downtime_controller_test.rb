require 'test_helper'

class SolarwindDeviceDowntimeControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
