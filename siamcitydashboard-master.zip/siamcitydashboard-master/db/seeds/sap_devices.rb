SapDevice.create(:host_name=>"DB Virtual IP/ URL",:uid=>"4e4a663c-bc59-4def-bb65-9bde899bbeaf",:url=>"http://10.254.8.14:8000/",:primary_app=>"HAP/ERP",:component_id => 5791)
SapDevice.create(:host_name=>"CI URLMSG Srv URL",:uid=>"3f7535a7-1c54-48d4-ae4f-cb843cf4dd86",:url=>"http://ecchanapas.inseegroup.com:8001/sap/public/ping",:primary_app=>"HAP/ERP",:component_id => 5790 )
SapDevice.create(:host_name=>"INSEE-DC-S008",:uid=>"322d6cfa-0952-4468-b8c7-a52d08deff4d",:url=>"http://insee-dc-s008.inseegroup.com:8002/sap/public/ping",:primary_app=>"HAP/ERP",:component_id => 5795)
SapDevice.create(:host_name=>"INSEE-DC-S009",:uid=>"bb1c0bf1-8b6e-4ea3-9691-6f99b23c9cf6",:url=>"http://insee-dc-s009.inseegroup.com:8003/sap/public/ping",:primary_app=>"HAP/ERP",:component_id => 5796)
SapDevice.create(:host_name=>"INSEE-DC-S010",:uid=>"d7e292ab-60df-49b7-abe1-f93d08212dc9",:url=>"http://insee-dc-s010.inseegroup.com:8004/sap/public/ping",:primary_app=>"HAP/ERP",:component_id => 5797)
SapDevice.create(:host_name=>"INSEE-DC-S011",:uid=>"1c009c23-414d-48e5-9356-e9b208976553",:url=>"http://insee-dc-s011.inseegroup.com:8005/sap/public/ping",:primary_app=>"HAP/ERP",:component_id => 5794)
SapDevice.create(:host_name=>"INSEE-DC-S012",:uid=>"6689b7b8-addc-4485-bf9d-55753ff689cf",:url=>"http://insee-dc-s012.inseegroup.com:8006/sap/public/ping",:primary_app=>"HAP/ERP",:component_id => 5793)

SapDevice.create(:host_name=>"INSEE-DC-S050",:uid=>"250a93af-df62-40eb-acbf-b9482a6c374b",:url=>"http://insee-dc-s050.inseegroup.com:8002/sap/public/ping",:primary_app=>"HBP/BW",:component_id => 5803)
SapDevice.create(:host_name=>"INSEE-DC-S051",:uid=>"0a097a3a-2db3-42b6-a29c-5b66221b6316",:url=>"http://insee-dc-s051.inseegroup.com:8003/sap/public/ping",:primary_app=>"HBP/BW",:component_id => 5804)
SapDevice.create(:host_name=>"CI URLMSG - HBP/BW",:uid=>"a4cd61c0-077d-4829-a3c8-6dd58131df6c",:url=>"http://bwhanapas.inseegroup.com:8011/sap/public/ping",:primary_app=>"HBP/BW",:component_id => 5799)
SapDevice.create(:host_name=>"DB Virtual IP",:uid=>"50c778a2-49cf-4872-82b1-bff5a6aa711f",:url=>"http://10.254.8.24:8000/",:primary_app=>"HBP/BW",:component_id => 5800)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase HBP/BW",:uid=>"",:url=>"RUN_HRP",:primary_app=>"HBP/BW",:component_id => 5806)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS HBP/BW",:uid=>"",:url=>"RUN_HRP_BS",:primary_app=>"HBP/BW",:component_id => 5807)

SapDevice.create(:host_name=>"PIP - F5 Loadbalancer URL",:uid=>"616111c4-dd56-4690-a54a-7075c54dccd1",:url=>"http://sappo.inseegroup.com:8000/startPage",:primary_app=>"PIP/PI",:component_id => 5809)
SapDevice.create(:host_name=>"J01 Instance",:uid=>"33171b02-b8ef-4e6c-9fb9-70cf9f2330f9",:url=>"http://10.254.8.40:50100/startPage",:primary_app=>"PIP/PI",:component_id => 5810)
SapDevice.create(:host_name=>"J02 Instance",:uid=>"a7d3d16d-239d-4f42-afc3-884331c93e77",:url=>"http://10.254.8.40:50200/startPage",:primary_app=>"PIP/PI",:component_id => 5811)
SapDevice.create(:host_name=>"J03 Instance",:uid=>"17626a4d-ae00-4b5f-9c46-74d2b1265b2a",:url=>"http://10.254.8.41:50300/startPage",:primary_app=>"PIP/PI",:component_id => 5814)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase PIP/PI",:uid=>"",:url=>"RUN_PIP",:primary_app=>"PIP/PI",:component_id => 5812)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS PIP/PI",:uid=>"",:url=>"RUN_PIP_BS",:primary_app=>"PIP/PI",:component_id => 5813 )

SapDevice.create(:host_name=>"INSEE-DC-S033",:uid=>"f6fdda20-3169-46c4-8d8d-328cdea9087d",:url=>"http://insee-dc-s033.inseegroup.com:8002/sap/public/ping",:primary_app=>"HRP/HCM",:component_id => 5808)
SapDevice.create(:host_name=>"CI URLMSG - HRP/HCM",:uid=>"1abac99f-7fe3-4259-81ed-2590c4e00289",:url=>"http://hrpsybpas.inseegroup.com:8001/sap/public/ping",:primary_app=>"HRP/HCM",:component_id => 5805)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase HRP/HCM",:uid=>"",:url=>"RUN_HRP",:primary_app=>"HRP/HCM",:component_id => 5806)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS HRP/HCM",:uid=>"",:url=>"RUN_HRP_BS",:primary_app=>"HRP/HCM",:component_id => 5807)

SapDevice.create(:host_name=>"ADP URL",:uid=>"49afaead-df86-4a16-9a60-a57a713516fe",:url=>"http://adssybpas.inseegroup.com:50000/startPage",:primary_app=>"ADP/ADOBE",:component_id => 34968)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase ADP URL",:uid=>"",:url=>"RUN_ADP",:primary_app=>"ADP/ADOBE",:component_id => 5826 )
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS ADP URL",:uid=>"",:url=>"RUN_ADP_BS",:primary_app=>"ADP/ADOBE",:component_id => 5827)


SapDevice.create(:host_name=>"FIP CI",:uid=>"ea5aafaa-11d7-4e62-a373-a14411d35106",:url=>"http://insee-dc-s073.inseegroup.com:8000/sap/public/ping",:primary_app=>"FIP/FIORI",:component_id => 5824)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase FIP CI",:uid=>"",:url=>"RUN_FIP",:primary_app=>"FIP/FIORI",:component_id => 5822)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS FIP CI",:uid=>"",:url=>"RUN_FIP_BS",:primary_app=>"FIP/FIORI",:component_id => 5823)

SapDevice.create(:host_name=>"GRP CI",:uid=>"139a387a-3bbe-4d2e-a806-26c5881980c9",:url=>"http://insee-dc-s063.inseegroup.com:8000/sap/public/ping",:primary_app=>"GRP/GRC",:component_id => 5821)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase GRP CI",:uid=>"",:url=>"RUN_GRP",:primary_app=>"GRP/GRC",:component_id => 5819)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS GRP CI",:uid=>"",:url=>"RUN_GRP_BS",:primary_app=>"GRP/GRC",:component_id => 5820)

SapDevice.create(:host_name=>"BOP URL",:uid=>"b0963883-5c2d-4703-aab0-f3edbbbd26ce",:url=>"http://insee-dc-s068.inseegroup.com:8080/BOE/CMC",:primary_app=>"BOP/BOBJ",:component_id => 5825)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BOP URL",:uid=>"",:url=>"RUN_BOP",:primary_app=>"BOP/BOBJ",:component_id => 0)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS BOP URL",:uid=>"",:url=>"RUN_BOP_BS",:primary_app=>"BOP/BOBJ",:component_id => 0)

SapDevice.create(:host_name=>"SPP ABAP URL",:uid=>"0d4839ef-db0f-4431-b21a-d2afa9d3a479",:url=>"http://insee-dc-s040.inseegroup.com:50300/sap/public/ping",:primary_app=>"SPP/SOLUTION MANAGER",:component_id => 5817)
SapDevice.create(:host_name=>"SPP JAVA URL",:uid=>"836e8d01-2ff0-4c0d-b3a8-81ca6dd1b30d",:url=>"http://10.254.1.230:50000/startPage",:primary_app=>"SPP/SOLUTION MANAGER",:component_id => 5818)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase SPP ABAP URL",:uid=>"",:url=>"RUN_SPP",:primary_app=>"SPP/SOLUTION MANAGER",:component_id => 5815)
SapDevice.create(:host_name=>"DB Process Monitoring for Sybase BS SPP ABAP URL",:uid=>"",:url=>"RUN_SPP_BS",:primary_app=>"SPP/SOLUTION MANAGER",:component_id => 5816)









