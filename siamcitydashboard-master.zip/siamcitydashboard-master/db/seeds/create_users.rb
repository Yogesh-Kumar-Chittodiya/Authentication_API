# create users for siamcity cement

# User.create(:name=>'Phana Lukbouwornwong',:email=>'phana.lukbouwornwong@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Phana@123',:password_confirmation=>'Phana@123')

# User.create(:name=>'Nanthiya Saiyarot',:email=>'Nanthiya.Saiyarot@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Nant@123',:password_confirmation=>'Nant@123')

# User.create(:name=>'Rachata Budlek',:email=>'RACHATA.BUDLEK@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Rachata@123',:password_confirmation=>'Rachata@123')

# User.create(:name=>'Alfred Lim Ong',:email=>'alfredl.ong@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Alfred@123',:password_confirmation=>'Alfred@123')

# User.create(:name=>'Sombat Srisawaeng',:email=>'sombat.srisawaeng@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Sombat@123',:password_confirmation=>'Sombat@123')

# User.create(:name=>'Pooritch Archavamathakul',:email=>'pooritch.archavamathakul@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Pooritch@123',:password_confirmation=>'Pooritch@123')

# User.create(:name=>'Amit Kumar Dhiman',:email=>'AMIT.DHIMAN@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Amit@123',:password_confirmation=>'Amit@123')

# User.create(:name=>'Hans Keril Ante',:email=>'hanskeril.ante@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Hans@123',:password_confirmation=>'Hans@123')

# User.create(:name=>'Supattra Sujitwanit',:email=>'supattra.sujitwanit@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Supattra@123',:password_confirmation=>'Supattra@123')

# User.create(:name=>'Nantaporn Lapetch',:email=>'NANTAPORN.LAPETCH@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Nantaporn@123',:password_confirmation=>'Nantaporn@123')

# User.create(:name=>'Saranpong Vijitjanya',:email=>'Saranpong.Vijitjanya@niit-tech.com',:role=>'end_user',:customer_id => 0,:password=>'Saranpong@123',:password_confirmation=>'Saranpong@123')

# User.create(:name=>'Sukanta Sengupta',:email=>'Sukanta.Sengupta@niit-tech.com',:role=>'end_user',:customer_id => 0,:password=>'Sukanta@123',:password_confirmation=>'Sukanta@123')

# User.create(:name=>'Suparna Goswami',:email=>'Suparna.Goswami@niit-tech.com',:role=>'end_user',:customer_id => 0,:password=>'Suparna@123',:password_confirmation=>'Suparna@123')

# User.create(:name=>'Anoop Raja',:email=>'Anoop.Raja@niit-tech.com',:role=>'end_user',:customer_id => 0,:password=>'Anoop@123',:password_confirmation=>'Anoop@123')

# User.create(:name=>'Pinyada Thornteerakul',:email=>'PINYADA.THORNTEERAKUL@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Pinyada@123',:password_confirmation=>'Pinyada@123')

# User.create(:name=>'Perapong Sueaprasert',:email=>'PERAPONG.SUEAPRASERT@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Perap@123',:password_confirmation=>'Perap@123')

# User.create(:name=>'Sunita Koblashova',:email=>'sunita.koblashova@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Sunita@123',:password_confirmation=>'Sunita@123')

# User.create(:name=>'Anna Suppeuchpol',:email=>'anna.suppeuchpol@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Anna@123',:password_confirmation=>'Anna@123')

# User.create(:name=>'Pathida Panya',:email=>'pathida.panya@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Pathida@123',:password_confirmation=>'Pathida@123')

# User.create(:name=>'Nichcha Paknamkhiaw',:email=>'NICHCHA.PAKNAMKHIAW@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Nichcha@123',:password_confirmation=>'Nichcha@123')

# User.create(:name=>'Kridkanok Prasitchokchai',:email=>'Kridkanok.Prasitchokchai@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Kridkanok@123',:password_confirmation=>'Kridkanok@123')

# User.create(:name=>'Wanthakarn Huachai',:email=>'WANTHAKARN.HUACHAI@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Wanthakarn@123',:password_confirmation=>'Wanthakarn@123')

# User.create(:name=>'Supansa Polarwut',:email=>'supansa.polarwut@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Supansa@123',:password_confirmation=>'Supansa@123')

# User.create(:name=>'Chanunpath Wongaphiratthana',:email=>'CHANUNPATH.WONGAPHIRATTHANA@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Chanunpath@123',:password_confirmation=>'Chanunpath@123')

# User.create(:name=>'Keasorn Chongpensuklert',:email=>'Keasorn.Sinyanunt@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Keasorn@123',:password_confirmation=>'Keasorn@123')

# User.create(:name=>'Amornrat Jaimooon',:email=>'AMORNRAT.JAIMOOON@inseegroup.onmicrosoft.com',:role=>'end_user',:customer_id => 0,:password=>'Amornrat@123',:password_confirmation=>'Amornrat@123')

# User.create(:name=>'Akkara Siriuilikul',:email=>'Akkara.Siriuilikul@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Akkara@123',:password_confirmation=>'Akkara@123')

# User.create(:name=>'Chawintorn Pathomkasikul',:email=>'CHAWINTORN.P@NIIT-TECH.COM',:role=>'end_user',:customer_id => 0,:password=>'Chawintorn@123',:password_confirmation=>'Chawintorn@123')

# User.create(:name=>'Nattakit Phuphatsirikorn',:email=>'NATTAKIT.PHUPHATSIRIKORN@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Nattakit@123',:password_confirmation=>'Nattakit@123')

# User.create(:name=>'HUNG NGUYEN DUY',:email=>'DUYHUNG.NGUYEN@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'HUNG@123',:password_confirmation=>'HUNG@123')

# User.create(:name=>'LILANTHA PERERA',:email=>'lilantha.perera@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'LILANTHA@123',:password_confirmation=>'LILANTHA@123')

# User.create(:name=>'Saiduzzaman Majumder',:email=>'SAIDUZZAMAN.MAJUMDER@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Saiduzzaman@123',:password_confirmation=>'Saiduzzaman@123')

# User.create(:name=>'UDITHA ANURUDDHA',:email=>'uditha.anuruddha@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'UDITHA@123',:password_confirmation=>'UDITHA@123')

# User.create(:name=>'CHANAKA SAMARAKOON ',:email=>'chanaka.samarakoon@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'CHANAKA@123',:password_confirmation=>'CHANAKA@123')

# User.create(:name=>'KHOA NGUYEN MANH',:email=>'KHOA.MANH.NGUYEN@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'KHOA@123',:password_confirmation=>'KHOA@123')

# User.create(:name=>'BAO TRAN TIEU',:email=>'bao.tieu.tran@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'BAO@123',:password_confirmation=>'BAO@123')

# User.create(:name=>'LAM TRAN VAN',:email=>'lam.tran@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'LAM@123',:password_confirmation=>'LAM@123')

# User.create(:name=>'Uma Jayaraman',:email=>'Uma.Jayaraman@NIIT-Tech.com',:role=>'end_user',:customer_id => 0,:password=>'Uma@123',:password_confirmation=>'Uma@123')

# User.create(:name=>'Damini Tyagi',:email=>'DAMINI.TYAGI@SIAMCITYCEMENT.COM',:role=>'end_user',:customer_id => 0,:password=>'Damini@123',:password_confirmation=>'Damini@123')

# User.create(:name=>'Rishabh Mohan',:email=>'Rishabh.Mohan@NIIT-Tech.com',:role=>'end_user',:customer_id => 0,:password=>'Rishabh@123',:password_confirmation=>'Rishabh@123')

# User.create(:name=>'Chananporn Thaiwattananont',:email=>'chananporn.thaiwattananont@siamcitycement.com',:role=>'end_user',:customer_id => 0,:password=>'Chananporn@123',:password_confirmation=>'Chananporn@123')


