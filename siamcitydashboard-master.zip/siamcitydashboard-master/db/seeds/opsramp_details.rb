OpsrampDetail.create(:client_secret => 'EG28jU9ecTrnvdVpRyX7ppe4UT4bvFgxNbqTTSQenu8emyMgWgHZWMxasXdbQ3Q5',:client_key => 'SzYFyb4Mzwj8UhnE9sxX5gAVrMWuujmF',:client_id => 'client_712993',:msp_id => 'msp_619733',:auth_url => 'https://ntl.app.opsramp.com/auth/oauth/token',:api_url => 'https://ntl.app.opsramp.com/api/v2',:location => 'bangladesh,indonesia')

# SCCC Opsramp

OpsrampDetail.create(:client_secret => 'eyJqPHraFsu5MaU7PEHeTzXJukgX9MBb83umQXPj8ZqPamuNPur7eAmAdezxKDFS',:client_key => 'mzSJS9rAhNHrx5MQN3ZMAY2nDQaWNAUH',:client_id => 'client_610553',:msp_id => 'msp_610443',:auth_url => 'https://sccc.app.opsramp.com/auth/oauth/token',:api_url => 'https://sccc.app.opsramp.com/api/v2',:location => 'Thailand DC')

OpsrampToken.create(:client_key=>'zUQWdJ7GVzmNynjNgQCDADEeXNbnE6HJ', :client_secret=>'d8DZPQFmsZgytGJxewFzgK8EZ7YPPauw9447Y6ZskSmd7eU8JJs7Wqrv6EuzVcVp', :auth_token=>'06b2714b-1da5-4793-a52b-e064b30960da',:expires_at=>'1592870400')
