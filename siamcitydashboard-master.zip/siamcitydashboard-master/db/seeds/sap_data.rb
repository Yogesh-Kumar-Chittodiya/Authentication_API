# 18-19 data
SapResponse.create(kpi_name: "ECC", kpi_value: "272 ms", kpi_date: "2020-06-18", kpi_time: "182028", kpi_rating: "G")
SapResponse.create(kpi_name: "BW", kpi_value: "164 ms", kpi_date: "2020-06-18", kpi_time: "182028", kpi_rating: "G")
SapResponse.create(kpi_name: "FIORI", kpi_value: "18 ms", kpi_date: "2020-06-18", kpi_time: "182028", kpi_rating: "G")
SapResponse.create(kpi_name: "HCM", kpi_value: "85 ms", kpi_date: "2020-06-18", kpi_time: "182028", kpi_rating: "G")
SapResponse.create(kpi_name: "GRC", kpi_value: "225 ms", kpi_date: "2020-06-18", kpi_time: "182028", kpi_rating: "G")

# 19-20 data
SapResponse.create(kpi_name: "ECC", kpi_value: "233 ms", kpi_date: "2020-06-18", kpi_time: "192028", kpi_rating: "G")
SapResponse.create(kpi_name: "BW", kpi_value: "14 ms", kpi_date: "2020-06-18", kpi_time: "192028", kpi_rating: "G")
SapResponse.create(kpi_name: "FIORI", kpi_value: "19 ms", kpi_date: "2020-06-18", kpi_time: "192028", kpi_rating: "G")
SapResponse.create(kpi_name: "HCM", kpi_value: "74 ms", kpi_date: "2020-06-18", kpi_time: "192028", kpi_rating: "G")
SapResponse.create(kpi_name: "GRC", kpi_value: "0 ms", kpi_date: "2020-06-18", kpi_time: "192028", kpi_rating: "G")

# 20-21 data
SapResponse.create(kpi_name: "ECC", kpi_value: "257 ms", kpi_date: "2020-06-18", kpi_time: "202028", kpi_rating: "G")
SapResponse.create(kpi_name: "BW", kpi_value: "15 ms", kpi_date: "2020-06-18", kpi_time: "202028", kpi_rating: "G")
SapResponse.create(kpi_name: "FIORI", kpi_value: "17 ms", kpi_date: "2020-06-18", kpi_time: "202028", kpi_rating: "G")
SapResponse.create(kpi_name: "HCM", kpi_value: "13 ms", kpi_date: "2020-06-18", kpi_time: "202028", kpi_rating: "G")
SapResponse.create(kpi_name: "GRC", kpi_value: "1 ms", kpi_date: "2020-06-18", kpi_time: "202028", kpi_rating: "G")

# 21-22 data
SapResponse.create(kpi_name: "ECC", kpi_value: "194 ms", kpi_date: "2020-06-18", kpi_time: "212028", kpi_rating: "G")
SapResponse.create(kpi_name: "BW", kpi_value: "21 ms", kpi_date: "2020-06-18", kpi_time: "212028", kpi_rating: "G")
SapResponse.create(kpi_name: "FIORI", kpi_value: "18 ms", kpi_date: "2020-06-18", kpi_time: "212028", kpi_rating: "G")
SapResponse.create(kpi_name: "HCM", kpi_value: "31 ms", kpi_date: "2020-06-18", kpi_time: "212028", kpi_rating: "G")
SapResponse.create(kpi_name: "GRC", kpi_value: "424 ms", kpi_date: "2020-06-18", kpi_time: "212028", kpi_rating: "G")

#  22-23 data
SapResponse.create(kpi_name: "ECC", kpi_value: "318 ms", kpi_date: "2020-06-18", kpi_time: "222028", kpi_rating: "A")
SapResponse.create(kpi_name: "BW", kpi_value: "1802 ms", kpi_date: "2020-06-18", kpi_time: "222028", kpi_rating: "R")
SapResponse.create(kpi_name: "FIORI", kpi_value: "18 ms", kpi_date: "2020-06-18", kpi_time: "222028", kpi_rating: "G")
SapResponse.create(kpi_name: "HCM", kpi_value: "26 ms", kpi_date: "2020-06-18", kpi_time: "222028", kpi_rating: "G")
SapResponse.create(kpi_name: "GRC", kpi_value: "318 ms", kpi_date: "2020-06-18", kpi_time: "222028", kpi_rating: "G")


#  23-24 data
SapResponse.create(kpi_name: "ECC", kpi_value: "492 ms", kpi_date: "2020-06-18", kpi_time: "232028", kpi_rating: "A")
SapResponse.create(kpi_name: "BW", kpi_value: "16 ms", kpi_date: "2020-06-18", kpi_time: "232028", kpi_rating: "G")
SapResponse.create(kpi_name: "FIORI", kpi_value: "17 ms", kpi_date: "2020-06-18", kpi_time: "232028", kpi_rating: "G")
SapResponse.create(kpi_name: "HCM", kpi_value: "22 ms", kpi_date: "2020-06-18", kpi_time: "232028", kpi_rating: "G")
SapResponse.create(kpi_name: "GRC", kpi_value: "1 ms", kpi_date: "2020-06-18", kpi_time: "232028", kpi_rating: "G")


# latest data
SapResponse.create(kpi_name: "ECC", kpi_value: "354 ms", kpi_date: "2020-06-19", kpi_time: "182028", kpi_rating: "A")
SapResponse.create(kpi_name: "BW", kpi_value: "58 ms", kpi_date: "2020-06-19", kpi_time: "182028", kpi_rating: "G")
SapResponse.create(kpi_name: "FIORI", kpi_value: "24 ms", kpi_date: "2020-06-19", kpi_time: "182028", kpi_rating: "G")
SapResponse.create(kpi_name: "HCM", kpi_value: "88 ms", kpi_date: "2020-06-19", kpi_time: "182028", kpi_rating: "G")
SapResponse.create(kpi_name: "GRC", kpi_value: "112 ms", kpi_date: "2020-06-19", kpi_time: "182028", kpi_rating:"G")
