# create a entry in opsramp token fields
OpsrampToken.create(:client_key=>'mzSJS9rAhNHrx5MQN3ZMAY2nDQaWNAUH', :client_secret=>'eyJqPHraFsu5MaU7PEHeTzXJukgX9MBb83umQXPj8ZqPamuNPur7eAmAdezxKDFS', :auth_token=>'06b2714b-1da5-4793-a52b-e064b30960da',:expires_at=>'2020-02-18T08:24:39.392+00:00')
OpsrampToken.create(:client_key=>'SzYFyb4Mzwj8UhnE9sxX5gAVrMWuujmF', :client_secret=>'EG28jU9ecTrnvdVpRyX7ppe4UT4bvFgxNbqTTSQenu8emyMgWgHZWMxasXdbQ3Q5', :auth_token=>'06b2714b-1da5-4793-a52b-e064b30960da',:expires_at=>'2020-02-18T08:24:39.392+00:00')
