# Thiland Devices
CriticalDevice.create('logical_name' => 'CONW-SRBC-S002_File-Share (MA)','host_name' => 'CONW-SRBC-S002','server_type'=>'VM','ip_address'=>'10.224.44.31','location' => 'Thiland','vm_cluster' => 'CONW Cluster','description' => 'File Share')
CriticalDevice.create('logical_name' => 'CONW-SRBC-S060_Active-Directory-1','host_name' => 'CONW-SRBC-S060','server_type'=>'VM','ip_address'=>'10.224.44.60','location' => 'Thiland','vm_cluster' => 'CONW Cluster','description' => 'Active Directory Server1')
CriticalDevice.create('logical_name' => 'CONW-SRBC-S061_Active-Directory-2','host_name' => 'CONW-SRBC-S061','server_type'=>'VM','ip_address'=>'10.224.44.15','location' => 'Thiland','vm_cluster' => 'CONW Cluster','description' => 'Active Directory Server2')
CriticalDevice.create('logical_name' => 'ISUB-SRBP-S237_File-Share','host_name' => 'ISUB-SRBP-S237','server_type'=>'VM','ip_address'=>'10.224.48.237','location' => 'Thiland','vm_cluster' => 'ISUB Cluster','description' => 'File Share')
CriticalDevice.create('logical_name' => 'ISUB-SRBP-S240_Active-Directory-1','host_name' => 'ISUB-SRBP-S240','server_type'=>'VM','ip_address'=>'10.224.48.240','location' => 'Thiland','vm_cluster' => 'ISUB Cluster','description' => 'Active Directory')
CriticalDevice.create('logical_name' => 'THA-SCCC-CLMO-S077','host_name' => 'SCCC-CLMO-S014','server_type'=>'VM','ip_address'=>'10.224.21.14','location' => 'Thiland','vm_cluster' => 'Nutanix CLMO','description' => 'AD server Primary')
CriticalDevice.create('logical_name' => 'THA-SCCC-CLMO-S079','host_name' => 'SCCC-CLMO-S015','server_type'=>'VM','ip_address'=>'10.224.21.15','location' => 'Thiland','vm_cluster' => 'Nutanix CLMO','description' => 'AD server Secondary')
CriticalDevice.create('logical_name' => 'SCCC-SRBP-S015 Secondary AD (MA)','host_name' => 'SCCC-SRBP-S015','server_type'=>'VM','ip_address'=>'10.224.29.15','location' => 'Thiland','vm_cluster' => 'SRB Cluster','description' => 'AD server')
CriticalDevice.create('logical_name' => 'SCCC-SRBP-S016 Primary AD (MA)','host_name' => 'SCCC-SRBP-S016','server_type'=>'VM','ip_address'=>'10.224.29.16','location' => 'Thiland','vm_cluster' => 'SRB Cluster','description' => 'AD server')
CriticalDevice.create('logical_name' => 'SCCC-SRBP-S021 File Server (MA)','host_name' => 'SCCC-SRBP-S021','server_type'=>'VM','ip_address'=>'10.224.29.21','location' => 'Thiland','vm_cluster' => 'SRB Cluster','description' => 'File server')
CriticalDevice.create('logical_name' => 'SCCC-SRBP-S082-SAP-SPrint (MA)','host_name' => 'SCCC-SRBP-S082','server_type'=>'VM','ip_address'=>'10.224.29.82','location' => 'Thiland','vm_cluster' => 'SRB Cluster','description' => 'Sprint')
CriticalDevice.create('logical_name' => 'AD Server','host_name' => '','server_type'=>'VM','ip_address'=>'10.224.41.12','location' => 'Thiland','vm_cluster' => '','description' => 'AD Server')
CriticalDevice.create('logical_name' => 'AD server','host_name' => 'CONW-CDC-S014','server_type'=>'VM','ip_address'=>'10.235.21.14','location' => 'Thiland','vm_cluster' => 'CDC Cluster','description' => 'AD Server')
CriticalDevice.create('logical_name' => 'File Share','host_name' => 'CONW-CDC-S021','server_type'=>'VM','ip_address'=>'10.235.21.21','location' => 'Thiland','vm_cluster' => 'CDC Cluster','description' => 'File Share')
CriticalDevice.create('logical_name' => 'AD server Shin3','host_name' => 'INDG-SHIN-S014','server_type'=>'VM','ip_address'=>'10.227.21.14','location' => 'Thiland','vm_cluster' => 'Nutanix SHIN3','description' => 'AD server Shin3')
CriticalDevice.create('logical_name' => 'File server Shin3','host_name' => 'INDG-SHIN-S021','server_type'=>'VM','ip_address'=>'10.227.21.21','location' => 'Thiland','vm_cluster' => 'Nutanix SHIN3','description' => 'File server Shin3')
CriticalDevice.create('logical_name' => 'File server','host_name' => 'SCCC-CLMO-S021','server_type'=>'VM','ip_address'=>'10.224.21.21','location' => 'Thiland','vm_cluster' => 'Nutanix CLMO','description' => 'File server')
CriticalDevice.create('logical_name' => 'SAP print','host_name' => 'SCCC-CLMO-S061','server_type'=>'VM','ip_address'=>'10.224.21.61','location' => 'Thiland','vm_cluster' => 'Nutanix CLMO','description' => 'SAP print')
CriticalDevice.create('logical_name' => 'SAP print','host_name' => 'SCCC-CLMO-S062','server_type'=>'VM','ip_address'=>'10.224.21.62','location' => 'Thiland','vm_cluster' => 'Nutanix CLMO','description' => 'SAP print')
CriticalDevice.create('logical_name' => 'Sprint','host_name' => 'SCCC-SRBP-S081','server_type'=>'VM','ip_address'=>'10.224.29.81','location' => 'Thiland','vm_cluster' => 'SRB Cluster','description' => 'Sprint')
CriticalDevice.create('logical_name' => 'Sprint','host_name' => 'SCCC-SRBP-S083','server_type'=>'VM','ip_address'=>'10.224.29.83','location' => 'Thiland','vm_cluster' => 'SRB Cluster','description' => 'Sprint')
CriticalDevice.create('logical_name' => 'Sprint','host_name' => 'SCCC-SRBP-S084','server_type'=>'VM','ip_address'=>'10.224.29.84','location' => 'Thiland','vm_cluster' => 'SRB Cluster','description' => 'Sprint')



# Vietnam Devices
CriticalDevice.create('logical_name' => 'Active Directory Primary Server - HCMC','host_name' => 'SCCVN-HCMC-S008','server_type'=>'Physical','ip_address'=>'10.229.21.8','location' => 'Vietnam','vm_cluster' => 'Lenovo','description' => 'Active Directory Primary Server')
CriticalDevice.create('logical_name' => 'Active Directory Secondary Server - HCMC','host_name' => 'SCCVN-HCMC-S009','server_type'=>'VM','ip_address'=>'10.229.21.9','location' => 'Vietnam','vm_cluster' => 'IBM','description' => 'Active Directory Secondary Server')
CriticalDevice.create('logical_name' => 'File server - HCMC','host_name' => 'VNM-HCMC-S0630','server_type'=>'VM','ip_address'=>'10.229.21.30','location' => 'Vietnam','vm_cluster' => 'Nutanix','description' => 'File server')
CriticalDevice.create('logical_name' => 'Active Directory Primary Server - CATL','host_name' => 'VNM-CATL-S0608','server_type'=>'VM','ip_address'=>'10.229.32.8','location' => 'Vietnam','vm_cluster' => 'Hyper-V','description' => 'Active Directory Primary Server')
CriticalDevice.create('logical_name' => 'Active Directory Secondary Server - CATL','host_name' => 'VNM-CATL-S0609','server_type'=>'Physical','ip_address'=>'10.229.32.9','location' => 'Vietnam','vm_cluster' => 'Lenovo','description' => 'Active Directory Secondary Server')
CriticalDevice.create('logical_name' => 'FILE SERVER + Backup Server + Printer Server - CATL','host_name' => 'VNM-CATL-S0630','server_type'=>'Physical','ip_address'=>'10.229.32.30','location' => 'Vietnam','vm_cluster' => 'HP','description' => 'FILE SERVER + Backup Server + Printer Server')
CriticalDevice.create('logical_name' => 'H-V SERVER - CATL','host_name' => 'VNM-CATL-S0639','server_type'=>'Physical','ip_address'=>'10.229.32.39','location' => 'Vietnam','vm_cluster' => 'HP','description' => 'H-V SERVER')
# THIV
CriticalDevice.create('logical_name' => 'Active Directory Server 1 - THIV','host_name' => 'VNM-THIV-S008','server_type'=>'VM','ip_address'=>'10.229.31.8','location' => 'Vietnam','vm_cluster' => 'Hyper-V','description' => 'Active Directory Server 1')
CriticalDevice.create('logical_name' => 'Active Directory Server 2 - THIV','host_name' => 'VNM-THIV-S009','server_type'=>'Physical','ip_address'=>'10.229.31.9','location' => 'Vietnam','vm_cluster' => 'Lenovo','description' => 'Active Directory Server 2')
CriticalDevice.create('logical_name' => 'File & Print Server & Backup Server - THIV','host_name' => 'VNM-THIV-S0630','server_type'=>'Physical','ip_address'=>'10.229.31.30','location' => 'Vietnam','vm_cluster' => 'HP','description' => 'File & Print Server & Backup Server')
CriticalDevice.create('logical_name' => 'Hyper-V - THIV','host_name' => 'VNM-THIV-HYPERV','server_type'=>'Physical','ip_address'=>'10.229.31.39','location' => 'Vietnam','vm_cluster' => 'HP','description' => 'Hyper-V')
# HIEP
CriticalDevice.create('logical_name' => 'File & Print Server & Backup Server - HIEP','host_name' => 'VVNM-HIEP-S0630','server_type'=>'Physical','ip_address'=>'10.229.28.30','location' => 'Vietnam','vm_cluster' => 'HP','description' => 'File & Print Server & Backup Server')
CriticalDevice.create('logical_name' => 'AD primary Server SCCC - HIEP','host_name' => 'SCCVN-HIEP-S008','server_type'=>'VM','ip_address'=>'10.229.28.8','location' => 'Vietnam','vm_cluster' => 'Hyper-V','description' => 'AD primary Server SCCC')
CriticalDevice.create('logical_name' => 'AD Secondary SCCC - HIEP','host_name' => 'SCCVN-HIEP-S009','server_type'=>'Physical','ip_address'=>'10.229.28.9','location' => 'Vietnam','vm_cluster' => '','description' => 'AD Secondary SCCC')
CriticalDevice.create('logical_name' => 'Hyper V Server - HIEP','host_name' => 'VNM-HIEP-S0639','server_type'=>'Physical','ip_address'=>'10.229.28.39','location' => 'Vietnam','vm_cluster' => 'HP','description' => 'Hyper V Server')
# NHOT
CriticalDevice.create('logical_name' => 'File server - NHOT','host_name' => 'VNM-NHOT-S0630','server_type'=>'Physical','ip_address'=>'10.229.37.30','location' => 'Vietnam','vm_cluster' => 'HP','description' => 'File server')
# HONC
CriticalDevice.create('logical_name' => 'Directory & DNS - HONC','host_name' => 'SCCVN-HONC-S008','server_type'=>'VM','ip_address'=>'10.229.34.8','location' => 'Vietnam','vm_cluster' => 'Lenovo','description' => 'Directory & DNS')
CriticalDevice.create('logical_name' => 'Directory & DNS - HONC','host_name' => 'SCCVN-HONC-S009','server_type'=>'Physical','ip_address'=>'10.229.34.9','location' => 'Vietnam','vm_cluster' => 'Lenovo','description' => 'Directory & DNS')
CriticalDevice.create('logical_name' => 'File Server - HONC','host_name' => 'VNM-HONC-S0630','server_type'=>'VM','ip_address'=>'10.229.34.30','location' => 'Vietnam','vm_cluster' => 'Lenovo','description' => 'File Server')
CriticalDevice.create('logical_name' => 'Vcenter - HONC','host_name' => 'VNM-HONC-S0633','server_type'=>'VM','ip_address'=>'10.229.34.33','location' => 'Vietnam','vm_cluster' => 'Lenovo','description' => 'Vcenter')

# SriLanka
CriticalDevice.create('logical_name' => 'SCCCL-CMBO-S001.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.1.1','location' => 'SriLanka','vm_cluster' => '','description' => 'Infra Device')
CriticalDevice.create('logical_name' => 'SCCCL-CMBO-S002.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.1.2','location' => 'SriLanka','vm_cluster' => '','description' => 'Infra Device')
CriticalDevice.create('logical_name' => 'SCCCL-CMBO-S025.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.2.75','location' => 'SriLanka','vm_cluster' => '','description' => 'Infra Device')
CriticalDevice.create('logical_name' => 'SCCCL-CMBO-S033.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.1.33','location' => 'SriLanka','vm_cluster' => '','description' => 'File Share')
CriticalDevice.create('logical_name' => 'hll-cmbo-s067','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.5.1','location' => 'SriLanka','vm_cluster' => '','description' => 'Infra Device')
CriticalDevice.create('logical_name' => 'CMBO-HX-NODE1','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.2.4','location' => 'SriLanka','vm_cluster' => '','description' => 'Infra Device')
CriticalDevice.create('logical_name' => 'CMBO-HX-NODE2','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.2.5','location' => 'SriLanka','vm_cluster' => '','description' => 'Infra Device')
CriticalDevice.create('logical_name' => 'CMBO-HX-NODE3','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.2.6','location' => 'SriLanka','vm_cluster' => '','description' => 'Infra Device')
CriticalDevice.create('logical_name' => 'SCCCL-RCWK-S001.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.49.1','location' => 'SriLanka','vm_cluster' => '','description' => 'Primary AD server')
CriticalDevice.create('logical_name' => 'SCCCL-RCWK-S002.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.49.2','location' => 'SriLanka','vm_cluster' => '','description' => 'Secondary AD server')
CriticalDevice.create('logical_name' => 'SCCCL-RCWK-S033.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.49.33','location' => 'SriLanka','vm_cluster' => '','description' => 'File Share')
CriticalDevice.create('logical_name' => '','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.50.4','location' => 'SriLanka','vm_cluster' => 'Lenovo','description' => 'VM Host 1')
CriticalDevice.create('logical_name' => '','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.50.5','location' => 'SriLanka','vm_cluster' => '','description' => 'VM Host 2')
CriticalDevice.create('logical_name' => 'SCCCL-PCWK-S001.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.24.1','location' => 'SriLanka','vm_cluster' => '','description' => 'Primary AD server')
CriticalDevice.create('logical_name' => 'SCCCL-PCWK-S002.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.24.2','location' => 'SriLanka','vm_cluster' => '','description' => 'Secondary AD server')
CriticalDevice.create('logical_name' => 'SCCCL-PCWK-S005.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.24.68','location' => 'SriLanka','vm_cluster' => '','description' => 'SAP Sprint Server')
CriticalDevice.create('logical_name' => 'SCCCL-PCWK-S025.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.26.75','location' => 'SriLanka','vm_cluster' => '','description' => 'Vcentre Server')
CriticalDevice.create('logical_name' => 'SCCCL-PCWK-S033.inseegroup.com','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.24.33','location' => 'SriLanka','vm_cluster' => '','description' => 'File Share')
CriticalDevice.create('logical_name' => '','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.26.4','location' => 'SriLanka','vm_cluster' => '','description' => 'ESXI host 01')
CriticalDevice.create('logical_name' => '','host_name' => '','server_type'=>'VM','ip_address'=>'10.226.26.5','location' => 'SriLanka','vm_cluster' => '','description' => 'ESXI host 02')

# Indonesia

CriticalDevice.create('logical_name' => 'ESXi Host 01','host_name' => 'INDO-CONW-CKR-S193','server_type'=>'Physical','ip_address'=>'10.228.249.209','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster CKR','description' => 'ESXi Host 01')
CriticalDevice.create('logical_name' => 'ESXi Host 02','host_name' => 'INDO-CONW-CKR-S194','server_type'=>'Physical','ip_address'=>'10.228.249.208','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster CKR','description' => 'ESXI host 02')
CriticalDevice.create('logical_name' => 'ESXi Host 01','host_name' => 'CONW-JKT-S010','server_type'=>'Physical','ip_address'=>'10.228.248.10','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster JKT','description' => 'ESXi Host 01')
CriticalDevice.create('logical_name' => 'ESXi Host 02','host_name' => 'CONW-JKT-S011','server_type'=>'Physical','ip_address'=>'10.228.248.11','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster JKT','description' => 'ESXI host 02')
CriticalDevice.create('logical_name' => 'SAP Sprint','host_name' => 'CONW-CKR-S0201','server_type'=>'VM','ip_address'=>'10.228.249.201','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster CKR','description' => 'SAP Sprint')
CriticalDevice.create('logical_name' => 'CKR Domian Controller','host_name' => 'CONW-CKR-S0203','server_type'=>'VM','ip_address'=>'10.228.249.203','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster CKR','description' => 'CKR Domian Controller')
CriticalDevice.create('logical_name' => 'Domain Controller','host_name' => 'CONW-JKT-S014','server_type'=>'VM','ip_address'=>'10.228.29.14','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster JKT','description' => 'Domain Controller')
CriticalDevice.create('logical_name' => 'File Server','host_name' => 'CONW-JKT-S015','server_type'=>'VM','ip_address'=>'10.228.29.15','location' => 'Indonesia','vm_cluster' => 'Conwood Cluster JKT','description' => 'File Server')
 
# Bangladesh
CriticalDevice.create('logical_name' => '','host_name' => 'BDSICA01','server_type'=>'Physical','ip_address'=>'10.95.1.46','location' => 'Bangladesh','vm_cluster' => 'HP Server','description' => '')
CriticalDevice.create('logical_name' => '','host_name' => 'SCCCBD-HO-VMSERV06','server_type'=>'Physical','ip_address'=>'10.95.1.6','location' => 'Bangladesh','vm_cluster' => 'Cisco Server','description' => '')
CriticalDevice.create('logical_name' => '','host_name' => 'SCBD-DAC-S020','server_type'=>'VM','ip_address'=>'10.95.1.20','location' => 'Bangladesh','vm_cluster' => 'File Server ','description' => '')
CriticalDevice.create('logical_name' => '','host_name' => 'SCBD-DAC-S015','server_type'=>'VM','ip_address'=>'10.95.1.15','location' => 'Bangladesh','vm_cluster' => 'ADC Server','description' => '')




