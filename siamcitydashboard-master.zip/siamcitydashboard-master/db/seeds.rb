tools_configuration = Hash.new
customer  = Customer.create(:name=>'SIAM City', :is_active=>true, :tools_configuration=>tools_configuration)

u1 = User.new
u1.email = 'manish.rauthan@niitdashboard.com'
u1.role = 'developer'
u1.name = 'Manish Rauthan'
u1.password = 'Manish27!'
u1.password_confirmation = 'Manish27!'
u1.customer_id = 0
u1.save

u2 = User.new
u2.email = 'admin@niitdashboard.com'
u2.role = 'admin'
u2.name = 'NIIT Admin'
u2.password = 'Manish27!'
u2.password_confirmation = 'Manish27!'
u2.customer_id = 0
u2.save

u3 = User.new
u3.email = 'rajesh.singh@niitdashboard.com'
u3.role = 'developer'
u3.name = 'Rajesh Singh'
u3.password = 'password'
u3.password_confirmation = 'password'
u3.customer_id = 0
u3.save

filters = Array.new
filter1 = Hash.new
filter1[:title] = 'Last 5 Days'
filter1[:type] = 'day'
filter1[:count] = 5
filters << filter1

filter2 = Hash.new
filter2[:title] = 'Last 3 Months'
filter2[:type] = 'month'
filter2[:count] = 3
filters << filter2

filter3 = Hash.new
filter3[:title] = 'Current Week'
filter3[:type] = 'week'
filter3[:count] = 0
filters << filter3

filter4 = Hash.new
filter4[:title] = 'Last Week'
filter4[:type] = 'week'
filter4[:count] = 1
filters << filter4

filters2 = Array.new
filter21 = Hash.new
filter21[:title] = 'Last Month'
filter21[:type] = 'monthly'
filter21[:count] = 1
filters2 << filter21

filter22 = Hash.new
filter22[:title] = 'Current Month'
filter22[:type] = 'monthly'
filter22[:count] = 0
filters2 << filter22


widget1  = Widget.create(:title=>'Incidents',:name=>'Incidents',:file_name=>'incidents_data',:size_type=>'one-fourth', :widget_type => 'historical', :module => 'service_now', :filters=>filters);
widget2  = Widget.create(:title=>'Problems',:name=>'Problems',:file_name=>'problems_data',:size_type=>'one-fourth', :widget_type => 'historical', :module => 'service_now', :filters=>filters);
widget3  = Widget.create(:title=>'Change Requests',:name=>'Change Requests',:file_name=>'change_requests_data',:size_type=>'one-fourth', :widget_type => 'historical', :module => 'service_now', :filters=>filters);
widget4  = Widget.create(:title=>'Service Requests',:name=>'Service Requests',:file_name=>'service_requests_data',:size_type=>'one-fourth', :widget_type => 'historical', :module => 'service_now', :filters=>filters);
widget5  = Widget.create(:title=>'Customer Satisfaction Rate',:name=>'Customer Satisfaction Rate ',:file_name=>'customer_satisfaction_rate',:size_type=>'one-third', :widget_type => 'historical', :module => 'service_now', :filters=>filters);
widget6  = Widget.create(:title=>'Customer Satisfaction Ratio',:name=>'Customer Satisfaction Ratio',:file_name=>'customer_satisfaction',:size_type=>'one-third',:widget_type=>'historical',:module=>'service_now',:filters=>filters2);
widget7  = Widget.create(:title=>'Customer Responses',:name=>'Customer Responses',:file_name=>'customer_responses',:size_type=>'one-third',:widget_type=>'historical',:module=>'service_now',:filters=>filters2);

cp6 = ConfigurationParameter.create(:parameter=>"Resolver Groups", :value_guide=>"")
cp7 = ConfigurationParameter.create(:parameter=>"Incident States", :value_guide=>"")

