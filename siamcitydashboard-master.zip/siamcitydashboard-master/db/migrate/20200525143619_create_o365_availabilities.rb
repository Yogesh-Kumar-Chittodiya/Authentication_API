class CreateO365Availabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :o365_availabilities do |t|
      t.string :yesterday_value
      t.string :today_value
      t.string :issues
      t.text :remarks
      t.string :service
      t.string :status_reported
      t.timestamps
    end
  end
end
