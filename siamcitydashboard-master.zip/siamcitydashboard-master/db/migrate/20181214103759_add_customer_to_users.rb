class AddCustomerToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :customer_id, :integer, :default=>0
  end
end
