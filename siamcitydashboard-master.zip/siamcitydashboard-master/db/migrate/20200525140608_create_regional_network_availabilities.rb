class CreateRegionalNetworkAvailabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :regional_network_availabilities do |t|
      t.string :country
      t.string :wan_availability
      t.string :site
      t.string :status_rag
      t.string :internet_availability
      t.text :remarks
      t.string :lan_critical_device_availability
      t.timestamps
    end
  end
end
