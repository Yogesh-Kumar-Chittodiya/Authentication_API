class CreateConfigurationParameters < ActiveRecord::Migration[5.2]
  def change
    create_table :configuration_parameters do |t|
      t.string :parameter
      t.string :slug
    end
  end
end
