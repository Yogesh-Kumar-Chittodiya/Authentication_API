class CreateCustomerSatisfactionScores < ActiveRecord::Migration[5.2]
  def change
    create_table :customer_satisfaction_scores do |t|
      t.datetime :ai_taken_on
      t.datetime :ai_sys_updated_on
      t.datetime :mr_sys_updated_on
      t.datetime :mr_sys_created_on
      t.string :mr_actual_value
      t.string :mr_sys_created_by
      t.string :ai_assessment_group
      t.string :mr_assessment_group
      t.string :ai_sys_id
      t.string :mr_sys_id
      t.string :mr_metric
      t.string :mr_user
      t.string :mr_source_id
      t.string :ai_task_id
      t.string :ai_sys_domain
      t.string :md_display
      t.string :ai_related_id_1
      t.string :ai_related_id_2
      t.string :ai_trigger_table
      t.string :ai_percent_answered
      t.string :md_sys_id
      t.string :ai_number
      t.string :ai_expiration_date
      t.string :mr_assign_to_order
      t.string :md_sys_updated_by
      t.string :md_sys_created_by
      t.string :mr_metric_definition
      t.string :mr_instance
      t.timestamps
    end
  end
end
