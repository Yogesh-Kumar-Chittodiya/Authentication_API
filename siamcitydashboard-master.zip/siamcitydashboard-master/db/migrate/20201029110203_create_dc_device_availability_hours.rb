class CreateDcDeviceAvailabilityHours < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_device_availability_hours do |t|
      t.integer :NodeID
      t.datetime :DateTime
      t.string :created_date
      t.string :created_time
      t.string :Availability
      t.string :NodeName
      t.string :IPAddress
      t.string :DeviceType
      t.string :Status
      t.timestamps
    end
  end
end
