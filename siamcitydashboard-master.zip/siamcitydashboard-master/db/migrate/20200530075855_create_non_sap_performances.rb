class CreateNonSapPerformances < ActiveRecord::Migration[5.2]
  def change
    create_table :non_sap_performances do |t|
      t.integer :non_sap_device_id
      t.string :start_time
      t.string :end_time
      t.string :record_type
      t.json :usage
      t.json :yesterday
      t.string :created_date
      t.timestamps
    end
  end
end
