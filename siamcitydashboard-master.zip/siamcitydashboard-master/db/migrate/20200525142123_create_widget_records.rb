class CreateWidgetRecords < ActiveRecord::Migration[5.2]
  def change
    create_table :widget_records do |t|
      t.string :name
      t.string :value
      t.string :status
      t.timestamps
    end
  end
end
