class CreateAssessments < ActiveRecord::Migration[5.2]
  def change
    create_table :assessments do |t|
      t.datetime :taken_on
      t.datetime :sys_updated_on
      t.datetime :sys_created_on
      t.date :expiration_date
      t.date :due_date
      t.string :preview
      t.string :percent_answered
      t.string :signature
      t.string :trigger_id
      t.string :assessment_group
      t.string :task_id
      t.string :number
      t.string :sys_id
      t.string :sys_updated_by
      t.string :sys_domain
      t.string :metric_type
      t.string :signature_result
      t.string :state
      t.string :sys_created_by
      t.string :trigger_table
      t.string :trigger_condition
      t.string :sys_mod_count
      t.string :sys_tags
      t.string :user
      t.timestamps
    end
  end
end
