class CreateSolarwindInterfaceDowntimes < ActiveRecord::Migration[5.2]
  def change
    create_table :solarwind_interface_downtimes do |t|
      t.string :StatusLED
      t.string :MPLS_Details
      t.string :DataCenter
      t.string :Interface_Details
      t.string :NodeID
      t.string :InterfaceID
      t.string :FullName
      t.text :Message
      t.string :DownEventTime
      t.string :OutageDurationInSeconds
      t.string :created_month
      t.string :created_date
      t.timestamps
    end
  end
end
