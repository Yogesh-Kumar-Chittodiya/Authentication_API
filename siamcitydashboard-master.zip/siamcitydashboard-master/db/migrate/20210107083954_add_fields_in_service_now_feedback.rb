class AddFieldsInServiceNowFeedback < ActiveRecord::Migration[5.2]
  def change
    add_column :assessments, :trigger_sys_id , :string
    add_column :servicenow_feedbacks, :trigger_sys_id , :string
    add_column :servicenow_feedbacks, :user , :string
    add_column :servicenow_feedbacks, :feedback_updated , :boolean, default: :false
  end
end
