class CreateLocalSystemAvailabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :local_system_availabilities do |t|
      t.string :country
      t.string :site
      t.string :system_availability_today
      t.string :system_availability_yesterday
      t.string :status_color
      t.text :remarks
      t.timestamps
    end
  end
end
