class CreateOpsrampNetworks < ActiveRecord::Migration[5.2]
  def change
    create_table :opsramp_networks do |t|
      t.integer :networkID 
      t.string :networkName 
      t.string :ifName 
      t.string :ifAlias 
      t.string :ifDescription 
      t.string :ifType 
      t.string :ifTxType 
      t.boolean :dhcpEnabled 
      t.string :speed 
      t.string :linkMode 
      t.string :confLinkSpeed 
      t.string :adminStatus 
      t.string :operationalStatus
      t.timestamps
    end
  end
end
