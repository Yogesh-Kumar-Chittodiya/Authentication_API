class CreateDashboards < ActiveRecord::Migration[5.2]
  def change
    create_table :dashboards do |t|
      t.string :name
      t.string :slug
      t.references :customer, :default=>0
      t.boolean :is_active, :default=>1
      t.boolean :is_delete, :default=>0	
      t.timestamps
    end
  end
end
