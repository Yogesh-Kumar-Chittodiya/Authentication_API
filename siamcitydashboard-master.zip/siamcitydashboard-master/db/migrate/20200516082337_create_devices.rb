class CreateDevices < ActiveRecord::Migration[5.2]
  def change
    create_table :devices do |t|
      t.string :unique_id
      t.string :site_id
      t.string :customer_id
      t.string :ip_address
      t.string :device_type
      t.string :device_path
      t.string :os_name
      t.string :make
      t.string :host_name
      t.string :mac_address
      t.string :device_category
      t.string :status
      t.string :state
      t.date :modified_time
      t.boolean :is_updated, :default=>true
      t.boolean :is_active, :default=>true
      t.boolean :is_new, :default=>true
      t.json :custom_attributes
      t.timestamps
    end
  end
end
