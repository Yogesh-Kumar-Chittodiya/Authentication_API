class CreateSapApplications < ActiveRecord::Migration[5.2]
  def change
    create_table :sap_applications do |t|
      t.string :name
      t.json :devices
      t.string :status
      t.boolean :sla_breached
      t.string :sla_category
      t.integer :availability
      t.integer :month_to_date
      t.timestamps
    end
  end
end
