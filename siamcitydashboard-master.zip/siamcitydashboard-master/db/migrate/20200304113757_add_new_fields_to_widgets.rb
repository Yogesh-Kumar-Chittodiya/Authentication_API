class AddNewFieldsToWidgets < ActiveRecord::Migration[5.2]
  def change
    add_column :widgets, :table_name, :string, :default=>''
    add_column :widgets, :url_query, :string, :default=>''
  end
end
