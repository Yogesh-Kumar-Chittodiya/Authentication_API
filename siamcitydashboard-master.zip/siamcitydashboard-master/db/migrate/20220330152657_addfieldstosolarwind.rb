class Addfieldstosolarwind < ActiveRecord::Migration[5.2]
  def change
    add_column :solarwind_device_availabilities, :node_name, :string, default: ""
    add_column :solarwind_device_availabilities, :ip_address, :string, default: ""
    add_column :solarwind_device_availabilities, :logical_name, :string, default: ""
    add_column :opsramp_device_availabilities, :ip_address, :string, default: ""
    add_column :opsramp_device_availabilities, :logical_name, :string, default: ""
    add_column :opsramp_device_availabilities, :node_name, :string, default: ""
    add_column :opsramp_device_downtimes, :ip_address, :string, default: ""
  end
end
