class CreateDcDeviceUtilizations < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_device_utilizations do |t|
      t.string :node_name
      t.string :memory_percent
      t.string :cpu_percent
      t.string :memory_yesterday
      t.string :cpu_yesterday
      t.string :memory_month
      t.string :cpu_month
      t.string :NodeID
      t.string :Caption
      t.string :DeviceType
      t.string :InstanceSiteId
      t.string :record_type
      t.string :created_date
      t.timestamps
    end
  end
end
