class AddFieldsToIncidents < ActiveRecord::Migration[5.2]
  def change
    add_column :incidents , :reassignment_count ,:integer
  end
end
