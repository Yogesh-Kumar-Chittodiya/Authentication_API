class CreateCriticalSecurityAlerts < ActiveRecord::Migration[5.2]
  def change
    create_table :critical_security_alerts do |t|
      t.integer :u_critical_alerts
      t.integer :compromised_alerts
      t.string :status
      t.timestamps
    end
  end
end
