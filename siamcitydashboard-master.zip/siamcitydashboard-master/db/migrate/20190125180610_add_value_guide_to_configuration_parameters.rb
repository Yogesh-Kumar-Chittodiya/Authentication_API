class AddValueGuideToConfigurationParameters < ActiveRecord::Migration[5.2]
  def change
    add_column :configuration_parameters, :value_guide, :string  
  end
end
