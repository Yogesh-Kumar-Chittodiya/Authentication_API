class CreateRemarksModules < ActiveRecord::Migration[5.2]
  def change
    create_table :remarks_modules do |t|
      t.text :remarks
      t.string :report_name
      t.date :created_date
      t.timestamps
    end
  end
end
