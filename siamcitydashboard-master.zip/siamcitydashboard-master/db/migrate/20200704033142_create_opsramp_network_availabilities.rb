class CreateOpsrampNetworkAvailabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :opsramp_network_availabilities do |t|
      t.integer :opsramp_network_id
      t.integer :networkID
      t.integer :AvailabilityToday
      t.string :record_type
      t.date :created_date
      t.string :created_time
      t.timestamps
    end
  end
end
