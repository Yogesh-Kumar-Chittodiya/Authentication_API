class CreateOpsrampDetails < ActiveRecord::Migration[5.2]
  def change
    create_table :opsramp_details do |t|
      t.string :client_secret
      t.string :client_key
      t.string :client_id
      t.string :msp_id
      t.string :auth_url
      t.string :api_url
      t.string :location
      t.timestamps
    end
  end
end
