class CreatePdfReports < ActiveRecord::Migration[5.2]
  def change
    create_table :pdf_reports do |t|
      t.string :month
      t.string :report_name
      t.boolean :is_delete
      t.boolean :is_published
      t.string :path
      t.timestamps
    end
  end
end
