class AddFieldsToSapResponses < ActiveRecord::Migration[5.2]
  def change
    add_column :sap_responses , :record_type , :string
  end
end
