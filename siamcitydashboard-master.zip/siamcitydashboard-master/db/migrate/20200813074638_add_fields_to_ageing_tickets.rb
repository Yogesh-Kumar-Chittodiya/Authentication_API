class AddFieldsToAgeingTickets < ActiveRecord::Migration[5.2]
  def change
    add_column :incident_ageing_tickets , :created_month , :string
    add_column :dashboards , :without_user , :boolean, :default => false
    add_column :service_request_ageing_tickets , :created_month , :string
    add_column :service_request_items , :u_fulfillment_start_time_stamp , :datetime
    add_column :servicenow_groups , :u_module , :string
    add_column :servicenow_groups , :u_scope , :string
  end
end
