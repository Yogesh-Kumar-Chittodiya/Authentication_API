class Addfieldstoassessmentfeedback < ActiveRecord::Migration[5.2]
  def change
    add_column :servicenow_feedbacks, :assigned_user, :string
    add_column :servicenow_feedbacks, :assignment_group, :string
  end
end
