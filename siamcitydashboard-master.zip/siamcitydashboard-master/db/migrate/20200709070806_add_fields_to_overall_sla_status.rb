class AddFieldsToOverallSlaStatus < ActiveRecord::Migration[5.2]
  def change
    add_column :overall_sla_statuses, :task_sys_created_on,:datetime
    add_column :overall_sla_statuses, :inc_state,:string
    add_column :overall_sla_statuses, :ritm_state,:string
    add_column :overall_sla_statuses, :ritm_stage,:string
  end
end
