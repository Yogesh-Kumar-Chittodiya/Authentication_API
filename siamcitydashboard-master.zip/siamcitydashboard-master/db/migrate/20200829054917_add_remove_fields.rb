class AddRemoveFields < ActiveRecord::Migration[5.2]
  def change
    # INCIDENT AGEING
    add_column :incident_ageing_tickets , :country , :string
    add_column :incident_ageing_tickets , :pillar , :string
    add_column :incident_ageing_tickets , :u_module , :string
    add_column :incident_ageing_tickets , :u_scope , :string
    add_column :incident_ageing_tickets , :workstream , :string
    add_column :incident_ageing_tickets , :resolved_at , :datetime
    add_column :incident_ageing_tickets , :u_target_completion_date_time , :datetime
    add_column :incident_ageing_tickets , :u_target_date_met_exceed , :string

    # INCIDENT TABLE
    add_column :incidents , :country , :string
    add_column :incidents , :pillar , :string
    add_column :incidents , :u_module , :string
    add_column :incidents , :u_scope , :string
    add_column :incidents , :workstream , :string
    add_column :incidents , :resolved_at , :datetime
    add_column :incidents , :u_target_completion_date_time , :datetime
    add_column :incidents , :u_target_date_met_exceed , :string

    # RITM AGEING
    add_column :service_request_ageing_tickets , :country , :string
    add_column :service_request_ageing_tickets , :pillar , :string
    add_column :service_request_ageing_tickets , :u_module , :string
    add_column :service_request_ageing_tickets , :u_scope , :string
    add_column :service_request_ageing_tickets , :workstream , :string
    add_column :service_request_ageing_tickets , :u_target_completion_date_time , :datetime
    add_column :service_request_ageing_tickets , :u_target_date_met_exceed , :string

    # RITM TABLE
    add_column :service_request_items , :country , :string
    add_column :service_request_items , :pillar , :string
    add_column :service_request_items , :u_module , :string
    add_column :service_request_items , :u_scope , :string
    add_column :service_request_items , :workstream , :string
    add_column :service_request_items , :u_target_completion_date_time , :datetime
    add_column :service_request_items , :u_target_date_met_exceed , :string

    # CSAT TABLE
    add_column :customer_satisfaction_scores , :country , :string
    add_column :customer_satisfaction_scores , :pillar , :string
    add_column :customer_satisfaction_scores , :u_module , :string
    add_column :customer_satisfaction_scores , :u_scope , :string
    add_column :customer_satisfaction_scores , :workstream , :string

    # SLA TABLE
    add_column :overall_sla_statuses , :country , :string
    add_column :overall_sla_statuses , :pillar , :string
    add_column :overall_sla_statuses , :u_module , :string
    add_column :overall_sla_statuses , :u_scope , :string
    add_column :overall_sla_statuses , :workstream , :string

    # REMOVE FIELDS IN CSAT
    remove_column :customer_satisfaction_scores , :mr_sys_updated_on
    remove_column :customer_satisfaction_scores , :ai_sys_updated_on
    remove_column :customer_satisfaction_scores , :mr_sys_created_on
    remove_column :customer_satisfaction_scores , :ai_sys_domain
    remove_column :customer_satisfaction_scores , :md_sys_id
    remove_column :customer_satisfaction_scores , :ai_percent_answered
    remove_column :customer_satisfaction_scores , :ai_number
    remove_column :customer_satisfaction_scores , :md_sys_updated_by
    remove_column :customer_satisfaction_scores , :mr_metric_definition
    remove_column :customer_satisfaction_scores , :ai_assessment_group
    remove_column :customer_satisfaction_scores , :mr_source_id

  end

end
