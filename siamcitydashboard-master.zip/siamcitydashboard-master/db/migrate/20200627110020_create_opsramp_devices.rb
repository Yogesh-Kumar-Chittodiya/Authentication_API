class CreateOpsrampDevices < ActiveRecord::Migration[5.2]
  def change
    create_table :opsramp_devices do |t|
      t.string :unique_id
      t.string :host_name
      t.string :ip_address
      t.string :device_type
      t.string :alias_name
      t.string :resource_name
      t.string :resource_type
      t.string :device_name
      t.string :os_name
      t.string :make
      t.text :description
      t.string :device_type
      t.string :mac_address
      t.string :status
      t.string :state
      t.json :network_card_details
      t.boolean :is_updated, :default=>true
      t.boolean :is_active, :default=>true
      t.boolean :is_new, :default=>true
      t.json :custom_attributes
      t.string :location
      t.timestamps
    end
  end
end
