class RemoveFieldsFromAssessment < ActiveRecord::Migration[5.2]
  def change
    # Assessment TABLE
    add_column :assessments , :country , :string
    add_column :assessments , :pillar , :string
    add_column :assessments , :u_module , :string
    add_column :assessments , :u_scope , :string
    add_column :assessments , :workstream , :string
    add_column :assessments , :assignment_group , :string

    # remove Assessment TABLE
    remove_column :assessments , :preview
    remove_column :assessments , :percent_answered
    remove_column :assessments , :signature
    remove_column :assessments , :sys_updated_by
    remove_column :assessments , :sys_domain
    remove_column :assessments , :signature_result
    remove_column :assessments , :trigger_table
    remove_column :assessments , :trigger_condition
    remove_column :assessments , :sys_tags
  end
end
