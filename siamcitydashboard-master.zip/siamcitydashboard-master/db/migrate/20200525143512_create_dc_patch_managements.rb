class CreateDcPatchManagements < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_patch_managements do |t|
      t.string :devices
      t.string :num_of_devices
      t.string :u_red
      t.string :u_amber
      t.string :u_green
      t.text :remarks
      t.timestamps
    end
  end
end
