class CreateCustomers < ActiveRecord::Migration[5.2]
  def change
    create_table :customers do |t|
      t.string :name
      t.string :slug
      t.boolean :is_active, :default=>true
      t.string :logo
      t.text :tools_configuration
      t.timestamps
    end
  end
end
