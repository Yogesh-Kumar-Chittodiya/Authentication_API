class CreateDcDeviceAvailabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_device_availabilities do |t|
      t.integer :NodeID
      t.datetime :DateTime
      t.date :created_date
      t.string :created_time
      t.string :AvailabilityToday
      t.string :AvailabilityYesterday
      t.string :AvailabilityMonth
      t.string :record_type
      t.string :NodeName
      t.string :IPAddress
      t.string :DeviceType
      t.string :Status
      t.timestamps
    end
  end
end
