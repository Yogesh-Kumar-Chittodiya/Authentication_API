class AddFieldsToRemarks < ActiveRecord::Migration[5.2]
  def change
    add_column :remarks_modules , :created_month , :string
  end
end
