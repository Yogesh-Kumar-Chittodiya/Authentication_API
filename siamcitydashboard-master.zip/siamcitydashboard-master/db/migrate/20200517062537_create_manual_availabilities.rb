class CreateManualAvailabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :manual_availabilities do |t|
      t.json :local_system_availability
      t.json :network_availability
      t.json :o365_system_availability
      t.json :dc_patch_management_status
      t.json :local_patch_management_status
      t.json :critical_security_alerts
      t.timestamps
    end
  end
end
