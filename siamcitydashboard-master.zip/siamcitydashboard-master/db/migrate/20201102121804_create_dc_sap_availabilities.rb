class CreateDcSapAvailabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_sap_availabilities do |t|
      t.string :record_type
      t.string :AvailabilityToday
      t.string :AvailabilityYesterday
      t.string :AvailabilityMonth
      t.integer :NodeID
      t.string :IPAddress
      t.string :ApplicationName
      t.string :ComponentName
      t.integer :ComponentID
      t.string :Status
      t.string :Caption
      t.timestamps
    end
    add_column :solarwind_device_downtimes , :is_delete , :boolean
    add_column :solarwind_interface_downtimes , :is_delete , :boolean
    add_column :sap_devices , :component_id , :integer
  end
end
