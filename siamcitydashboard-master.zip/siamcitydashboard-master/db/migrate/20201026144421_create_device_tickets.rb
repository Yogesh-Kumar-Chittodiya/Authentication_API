class CreateDeviceTickets < ActiveRecord::Migration[5.2]
  def change
    create_table :device_tickets do |t|
      t.string :number
      t.datetime :sys_created_on
      t.datetime :sys_updated_on
      t.datetime :closed_at
      t.string :sys_created_by
      t.string :priority
      t.text :short_description
      t.string :assigned_to
      t.string :caller_id
      t.string :subcategory
      t.string :assignment_group
      t.string :sys_id
      t.string :contact_type
      t.string :incident_state
      t.string :company
      t.string :location
      t.string :category
      t.string :created_date
      t.string :u_indg_service_desk_counter
      t.integer :reassignment_count
      t.string :u_alert_type
      t.string :cmdb_ci
      t.string :correlation_display
      t.string :country
      t.string :workstream
      t.string :pillar
      t.string :u_module
      t.string :u_scope
      t.string :resolved_at
      t.string :u_target_completion_date_time
      t.string :u_target_date_met_exceed
      t.timestamps
    end
    add_column :incident_ageing_tickets ,:cmdb_ci , :string
    add_column :incidents ,:cmdb_ci , :string
  end
end
