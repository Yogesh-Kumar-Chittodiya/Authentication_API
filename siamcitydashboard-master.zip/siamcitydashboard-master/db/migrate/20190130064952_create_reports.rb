class CreateReports < ActiveRecord::Migration[5.2]
  def change
    create_table :reports do |t|
      t.integer :customer_id
      t.string :title
      t.string :report_type
      t.text :link
      t.string :tool
      t.boolean :is_active, :default => true
      t.timestamps
    end
  end
end
