class SolarwindInterfaceAvailabilities < ActiveRecord::Migration[5.2]
  def change
    create_table :solarwind_interface_availabilities do |t|
      t.integer :NodeID
      t.integer :InterfaceID
      t.datetime :DateTime
      t.string :AvailabilityToday
      t.string :AvailabilityYesterday
      t.string :AvailabilityMonth
      t.string :record_type
      t.timestamps
    end
  end
end
