class CreateCriticalIncidents < ActiveRecord::Migration[5.2]
  def change
    create_table :critical_incidents do |t|
      t.string :number
      t.datetime :sys_created_on
      t.datetime :sys_updated_on
      t.datetime :closed_at
      t.string :sys_created_by
      t.string :priority
      t.text :short_description
      t.string :assigned_to
      t.string :caller_id
      t.string :subcategory
      t.string :assignment_group
      t.string :sys_id
      t.string :contact_type
      t.string :incident_state
      t.string :company
      t.string :location
      t.string :category
      t.timestamps
    end
  end
end
