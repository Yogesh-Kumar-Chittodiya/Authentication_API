class CreateNonSapDowntimes < ActiveRecord::Migration[5.2]
  def change
    create_table :non_sap_downtimes do |t|
      t.integer :non_sap_device_id
      t.string :start_time
      t.string :end_time
      t.string :downtime_date
      t.string :total_downtime
      t.timestamps
    end
  end
end
