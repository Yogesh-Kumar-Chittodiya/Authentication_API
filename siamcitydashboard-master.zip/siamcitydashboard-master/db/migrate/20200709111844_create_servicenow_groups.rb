class CreateServicenowGroups < ActiveRecord::Migration[5.2]
  def change
    create_table :servicenow_groups do |t|
      t.string :parent
      t.string :u_bfl
      t.string :u_group_type
      t.string :sys_updated_on
      t.string :group_type
      t.string :sys_id
      t.string :sys_created_on
      t.string :u_ppm_group_lead
      t.string :u_sla_escalation_group
      t.json :vendors
      t.string :email
      t.string :sys_created_by
      t.string :manager
      t.string :u_application_delivery_head
      t.boolean :active
      t.string :u_workstream
      t.string :group_name
      t.json :exclude_manager
      t.json :include_members
      t.timestamps
    end
  end
end
