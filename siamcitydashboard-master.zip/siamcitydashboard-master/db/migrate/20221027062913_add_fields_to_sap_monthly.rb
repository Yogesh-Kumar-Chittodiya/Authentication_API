class AddFieldsToSapMonthly < ActiveRecord::Migration[5.2]
  def change
    add_column :sap_response_monthlies, :manual_response, :string
    add_column :sap_response_monthlies, :remarks, :text
  end
end
