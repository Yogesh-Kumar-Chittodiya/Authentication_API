class CreateOpsrampTokens < ActiveRecord::Migration[5.2]
  def change
    create_table :opsramp_tokens do |t|
      t.string :client_key
      t.string :client_secret
      t.string :auth_token
      t.date :expires_at
      t.timestamps
    end
  end
end
