class Addfieldstoadminpatchmanagement < ActiveRecord::Migration[5.2]
  def change
    add_column :admin_patch_managements, :end_of_life, :integer
  end
end
