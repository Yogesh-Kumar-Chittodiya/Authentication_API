class AddIsDefaultToDashboardUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :dashboard_users, :is_default, :boolean, :default=>false 
  end
end
