class CreateSolarwindComponentDowntimes < ActiveRecord::Migration[5.2]
  def change
    create_table :solarwind_component_downtimes do |t|
      t.string :ComponentName
      t.integer :ComponentID
      t.text :Message
      t.datetime :DownEventTime
      t.integer :OutageDurationInSeconds
      t.string :created_date
      t.string :created_month
      t.text :remarks
      t.boolean :is_delete
      t.boolean :isremoved
      t.timestamps
    end
  end
end
