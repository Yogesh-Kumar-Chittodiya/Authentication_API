class AddIsDefaultToDashboard < ActiveRecord::Migration[5.2]
  def change
    add_column :dashboards, :is_default, :boolean, :default=>false
  end
end
