class AddFieldsToIncident < ActiveRecord::Migration[5.2]
  def change
    add_column :incidents, :u_alert_type ,:string
    add_column :incidents, :correlation_display ,:string
  end
end
