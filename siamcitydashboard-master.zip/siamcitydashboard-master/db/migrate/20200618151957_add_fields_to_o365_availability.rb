class AddFieldsToO365Availability < ActiveRecord::Migration[5.2]
  def change
    add_column :o365_availabilities, :incidents,:json
    add_column :o365_availabilities, :display_name, :string
    add_column :o365_availabilities, :status_time, :datetime
    add_column :o365_availabilities, :record_type, :string
    remove_column :o365_availabilities, :remarks , :text
    remove_column :o365_availabilities, :yesterday_value, :string
    remove_column :o365_availabilities, :issues , :string
    remove_column :o365_availabilities, :status_reported, :string
  end
end
