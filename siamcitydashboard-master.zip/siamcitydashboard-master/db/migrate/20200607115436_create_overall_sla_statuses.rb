class CreateOverallSlaStatuses < ActiveRecord::Migration[5.2]
  def change
    create_table :overall_sla_statuses do |t|
      t.string :task_parent
      t.text :task_short_description
      t.string :sccc_sla_u_sccc_sla_text
      t.string :task_assignment_group
      t.string :task_state
      t.string :tsla_stage
      t.boolean :tsla_has_breached
      t.string :task_number
      t.string :task_sys_id
      t.string :tsla_sys_id
      t.string :task_sys_class_name
      t.string :task_assigned_to
      t.string :tsla_schedule
      t.string :task_priority
      t.string :tsla_percentage
      t.string :tsla_duration
      t.datetime :tsla_sys_created_on
      t.datetime :tsla_sys_updated_on
      t.date :task_sys_updated_on
      t.date :task_closed_at
      t.datetime :tsla_end_time
      t.text :task_comments_and_work_notes
      t.string :tsla_business_time_left
      t.string :task_opened_by
      t.string :task_escalation
      t.string :task_contact_type
      t.string :tsla_sla
      t.string :task_company
      t.timestamps
    end
  end
end
