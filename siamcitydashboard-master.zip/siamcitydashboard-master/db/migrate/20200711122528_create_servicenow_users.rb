class CreateServicenowUsers < ActiveRecord::Migration[5.2]
  def change
    create_table :servicenow_users do |t|
      t.datetime :user_sys_created_on
      t.datetime :comp_sys_updated_on
      t.datetime :user_sys_updated_on
      t.datetime :comp_sys_created_on
      t.string :comp_stock_price
      t.string :comp_name
      t.string :user_sys_created_by
      t.string :user_employee_number
      t.string :user_sys_class_name
      t.string :user_web_service_access_only
      t.string :user_last_name
      t.string :user_name
      t.string :user_notification
      t.string :comp_profits
      t.string :user_first_name
      t.string :comp_sys_created_by
      t.string :user_department
      t.string :comp_sys_updated_by
      t.string :user_sys_updated_by
      t.string :comp_sys_class_name
      t.string :user_internal_integration_user
      t.string :comp_sys_id
      t.string :user_sys_id
      t.string :user_manager
      t.string :user_active
      t.string :comp_notes
      t.string :user_company
      t.string :user_email
      t.string :user_user_name
      t.string :user_u_manager_email
      t.string :comp_sys_mod_count
      t.string :comp_customer
      t.string :user_calendar_integration
      t.string :comp_u_code
      t.string :comp_country
      t.string :user_u_persona_check
      t.string :user_u_ppm_resource
      t.string :user_location
      t.string :user_u_user_persona
      t.timestamps
    end
  end
end
