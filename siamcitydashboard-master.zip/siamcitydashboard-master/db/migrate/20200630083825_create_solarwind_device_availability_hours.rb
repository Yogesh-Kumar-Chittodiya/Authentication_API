class CreateSolarwindDeviceAvailabilityHours < ActiveRecord::Migration[5.2]
  def change
    create_table :solarwind_device_availability_hours do |t|
      t.integer :NodeID
      t.datetime :DateTime
      t.string :created_date
      t.string :created_time
      t.string :Availability
      t.timestamps
    end
  end
end
