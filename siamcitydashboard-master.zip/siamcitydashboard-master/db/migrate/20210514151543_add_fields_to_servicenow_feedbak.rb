class AddFieldsToServicenowFeedbak < ActiveRecord::Migration[5.2]
  def change
    add_column :servicenow_feedbacks, :ticket_priority, :string
    add_column :servicenow_feedbacks, :ticket_state, :string
  end
end
