class CreateDcDeviceUtilizationHours < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_device_utilization_hours do |t|
      t.string :node_name
      t.string :memory_percent
      t.string :cpu_percent
      t.string :NodeID
      t.string :Caption
      t.string :DeviceType
      t.string :InstanceSiteId
      t.string :record_type
      t.string :created_date
      t.string :created_time
      t.timestamps
    end
  end
end
