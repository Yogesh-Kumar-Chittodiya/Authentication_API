class CreateAdminPatchManagements < ActiveRecord::Migration[5.2]
  def change
    create_table :admin_patch_managements do |t|
      t.string :device
      t.string :month
      t.string :num_of_devices
      t.string :status
      t.string :update_devices
      t.string :update_pending_devices
      t.text :remarks
      t.timestamps
    end

    add_column :dc_patch_managements , :month ,:string
    add_column :local_patch_managements , :month ,:string
  end
end
