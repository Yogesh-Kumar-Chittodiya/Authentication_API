class AddConfigurationToWidgets < ActiveRecord::Migration[5.2]
  def change
    add_column :widgets, :configuration, :text
  end
end
