class CreateNonSapApplications < ActiveRecord::Migration[5.2]
  def change
    create_table :non_sap_applications do |t|
      t.string :name
      t.json :devices
      t.string :status
      t.boolean :sla_breached
      t.string :sla_category
      t.timestamps
    end
  end
end
