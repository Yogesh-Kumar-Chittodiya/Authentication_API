class CreateOpsrampDeviceDowntimes < ActiveRecord::Migration[5.2]
  def change
    create_table :opsramp_device_downtimes do |t|
      t.integer :opsramp_device_id
      t.string :start_time
      t.string :end_time
      t.string :downtime_date
      t.string :total_downtime
      t.timestamps
    end
  end
end
