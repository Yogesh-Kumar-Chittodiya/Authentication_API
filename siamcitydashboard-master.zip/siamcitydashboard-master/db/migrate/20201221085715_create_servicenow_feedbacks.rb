class CreateServicenowFeedbacks < ActiveRecord::Migration[5.2]
  def change
    add_column :solarwind_response_times, :Name , :text
    create_table :servicenow_feedbacks do |t|
      t.string :ticket_number
      t.string :assessment_sys_id
      t.string :workstream
      t.string :country
      t.string :state
      t.datetime :resolved_at
      t.datetime :created_on
      t.string :servicedesk_owner
      t.string :pillar
      t.integer :rating
      t.boolean :is_updated , :default => false
      t.datetime :call_date
      t.string :call_successful
      t.text :remarks
      t.timestamps
    end
  end
end
