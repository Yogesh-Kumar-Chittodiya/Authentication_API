class CreateCriticalServers < ActiveRecord::Migration[5.2]
  def change
    create_table :critical_servers do |t|
      t.string :ip_address
      t.string :name
      t.text :description
      t.string :location
      t.string :server_type
      t.string :host_name
      t.string :os_system
      t.timestamps
    end
  end
end
