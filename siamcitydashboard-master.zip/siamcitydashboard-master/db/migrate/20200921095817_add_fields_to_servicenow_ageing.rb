class AddFieldsToServicenowAgeing < ActiveRecord::Migration[5.2]
  def change
    add_column :service_request_ageing_tickets , :u_fulfillment_start_time_stamp , :datetime
  end
end
