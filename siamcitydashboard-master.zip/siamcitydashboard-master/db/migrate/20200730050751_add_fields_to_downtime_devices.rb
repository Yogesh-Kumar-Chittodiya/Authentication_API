class AddFieldsToDowntimeDevices < ActiveRecord::Migration[5.2]
  def change
    add_column :opsramp_device_downtimes , :remark , :text
    add_column :non_sap_downtimes , :remark , :text
    add_column :sap_downtimes , :remark , :text
  end
end
