class AddFieldsToDowntimes < ActiveRecord::Migration[5.2]
  def change
    add_column :solarwind_device_downtimes , :remarks , :text
    add_column :solarwind_device_downtimes , :isremoved , :boolean
    add_column :solarwind_interface_downtimes , :isremoved , :boolean
    add_column :solarwind_interface_downtimes , :remarks , :text
  end
end
