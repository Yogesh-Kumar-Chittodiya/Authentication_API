class CreateSolarwindDevices < ActiveRecord::Migration[5.2]
  def change
    create_table :solarwind_devices do |t|
      t.integer :NodeID
      t.string :ObjectSubType
      t.string :NodeName
      t.string :DisplayName
      t.string :IPAddress
      t.string :Caption
      t.boolean :IsServer
      t.string :MachineType
      t.text :NodeDescription
      t.text :Description
      t.text :DNS
      t.text :Status
      t.string :SysName
      t.string :Vendor
      t.string :DataCenter
      t.string :DeviceCategory
      t.datetime :LastSync
      t.datetime :LastSystemUpTimePollUtc
      t.datetime :NextPoll
      t.timestamps
    end
  end
end

# Status[0=>"Unknown",1=>"up",2=>"down",3=>"warning",14=>"critical"]
