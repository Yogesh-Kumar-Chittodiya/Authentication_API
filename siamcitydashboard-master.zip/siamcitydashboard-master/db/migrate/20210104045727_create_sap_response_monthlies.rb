class CreateSapResponseMonthlies < ActiveRecord::Migration[5.2]
  def change
    create_table :sap_response_monthlies do |t|
      t.string :kpi_name
      t.string :kpi_value
      t.string :kpi_value_system
      t.date :kpi_date
      t.string :kpi_time
      t.string :kpi_rating
      t.string :created_month
      t.string :created_year
      t.timestamps
    end
  end
end
