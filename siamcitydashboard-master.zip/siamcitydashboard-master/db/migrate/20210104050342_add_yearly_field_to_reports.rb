class AddYearlyFieldToReports < ActiveRecord::Migration[5.2]
  def change
    add_column :solarwind_response_times, :created_year , :string
    add_column :solarwind_interface_downtimes, :created_year , :string
    add_column :solarwind_device_downtimes, :created_year , :string
    add_column :remarks_modules, :created_year , :string
    add_column :local_patch_managements, :created_year , :string
    add_column :dc_patch_managements, :created_year , :string
    add_column :admin_patch_managements, :created_year , :string
    add_column :admin_backup_reports, :created_year , :string
    add_column :service_request_ageing_tickets, :created_year , :string
    add_column :incident_ageing_tickets, :created_year , :string
    add_column :pdf_reports, :created_year , :string
    add_column :solarwind_component_downtimes, :created_year , :string
  end
end
