class CreateDcDeviceDowntimes < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_device_downtimes do |t|
      t.string :StatusLED
      t.string :Caption
      t.string :IPAddress
      t.string :NodeID
      t.string :DataCenter
      t.string :Devicetype
      t.text :Message
      t.string :DownEventTime
      t.string :OutageDurationInSeconds
      t.string :created_month
      t.string :created_date
      t.timestamps
    end
  end
end
