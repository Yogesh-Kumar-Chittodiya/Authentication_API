class AddFieldsToInterfaces < ActiveRecord::Migration[5.2]
  def change
    add_column :solarwind_interfaces, :is_delete , :boolean
    add_column :solarwind_devices, :is_delete , :boolean
    add_column :opsramp_devices, :is_delete , :boolean
    add_column :critical_devices, :is_delete , :boolean
    add_column :dc_devices, :is_delete , :boolean
  end
end
