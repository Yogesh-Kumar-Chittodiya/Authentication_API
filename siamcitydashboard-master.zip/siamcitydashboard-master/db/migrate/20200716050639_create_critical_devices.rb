class CreateCriticalDevices < ActiveRecord::Migration[5.2]
  def change
    create_table :critical_devices do |t|
      t.string :ip_address
      t.string :host_name
      t.string :logical_name
      t.string :server_type
      t.string :vm_cluster
      t.string :description
      t.string :location
      t.string :device_type
      t.timestamps
    end
  end
end
