class CreateDcSapAvailabilityHours < ActiveRecord::Migration[5.2]
  def change
    create_table :dc_sap_availability_hours do |t|
      t.string :record_type
      t.string :created_date
      t.string :created_time
      t.string :Availability
      t.integer :NodeID
      t.string :IPAddress
      t.string :ApplicationName
      t.string :ComponentName
      t.integer :ComponentID
      t.string :Status
      t.string :Caption
      t.timestamps
    end
  end
end
