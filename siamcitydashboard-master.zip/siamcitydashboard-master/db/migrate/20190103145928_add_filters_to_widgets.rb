class AddFiltersToWidgets < ActiveRecord::Migration[5.2]
  def change
    add_column :widgets, :widget_type, :string, :default=>'live'
    add_column :widgets, :filters, :text
  end
end
