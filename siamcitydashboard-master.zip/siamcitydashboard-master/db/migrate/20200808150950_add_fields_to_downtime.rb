class AddFieldsToDowntime < ActiveRecord::Migration[5.2]
  def change
    add_column :opsramp_device_downtimes , :isremoved , :boolean
    add_column :non_sap_downtimes , :isremoved , :boolean
    add_column :sap_downtimes , :isremoved , :boolean
  end
end
