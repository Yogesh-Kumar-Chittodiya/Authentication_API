class CreateSolarwindInterfaces < ActiveRecord::Migration[5.2]
  def change
    create_table :solarwind_interfaces do |t|
      t.integer :NodeID
      t.integer :InterfaceID
      t.string :ObjectSubType
      t.string :Name
      t.string :TypeName
      t.string :TypeDescription
      t.integer :Speed
      t.integer :MTU
      t.datetime :LastChange
      t.string :PhysicalAddress
      t.string :InBandwidth
      t.string :OutBandwidth
      t.text :Caption
      t.text :FullName
      t.datetime :LastSync
      t.string :Alias
      t.string :IfName
      t.datetime :CustomPollerLastStatisticsPoll
      t.datetime :NextPoll
      t.integer :InterfaceSpeed
      t.string :InterfaceCaption
      t.string :InterfaceName
      t.string :InterfaceTypeName
      t.string :InterfaceAlias
      t.datetime :InterfaceLastChange
      t.string :InterfaceMTU
      t.string :InterfaceTypeDescription
      t.string :Status
      t.string :InterfaceMTU
      t.string :MPLS_Details
      t.string :DataCenter
      t.string :Interface_Details
      t.timestamps
    end
  end
end

            
