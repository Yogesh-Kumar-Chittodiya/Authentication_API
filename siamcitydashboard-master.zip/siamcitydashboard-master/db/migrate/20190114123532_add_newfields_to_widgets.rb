class AddNewfieldsToWidgets < ActiveRecord::Migration[5.2]
  def change
    add_column :widgets, :options, :text
  end
end
