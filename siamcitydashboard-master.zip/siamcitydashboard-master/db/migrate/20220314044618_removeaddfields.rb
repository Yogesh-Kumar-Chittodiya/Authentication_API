class Removeaddfields < ActiveRecord::Migration[5.2]
  def change
    add_column :critical_devices, :priority, :string, default: "Non-Critical"
    add_column :critical_devices, :landscape, :string
    # remove_column :critical_devices, :description
  end
end
