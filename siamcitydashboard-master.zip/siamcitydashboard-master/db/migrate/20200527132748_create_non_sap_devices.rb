class CreateNonSapDevices < ActiveRecord::Migration[5.2]
  def change
    create_table :non_sap_devices do |t|
      t.string :host_name
      t.string :ip_address
      t.string :primary_app
      t.string :uid
      t.string :device_type
      t.timestamps
    end
  end
end
