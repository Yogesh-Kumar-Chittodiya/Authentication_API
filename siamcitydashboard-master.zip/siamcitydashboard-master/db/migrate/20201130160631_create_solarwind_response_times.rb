class CreateSolarwindResponseTimes < ActiveRecord::Migration[5.2]
  def change
    create_table :solarwind_response_times do |t|
      t.string :record_type
      t.string :AvgResponseTime
      t.string :MaxResponseTime
      t.string :MinResponseTime
      t.integer :NodeID
      t.string :IPAddress
      t.string :Caption
      t.string :ObservationTimestamp
      t.string :created_month
      t.string :created_date
      t.timestamps
    end
  end
end
