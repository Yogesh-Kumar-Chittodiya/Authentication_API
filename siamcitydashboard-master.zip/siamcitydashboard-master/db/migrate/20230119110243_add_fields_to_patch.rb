class AddFieldsToPatch < ActiveRecord::Migration[5.2]
  def change
    add_column :dc_patch_managements, :end_of_life ,:string, default: '0'
    add_column :dc_patch_managements, :behind_patch ,:string, default: '0'
  end
end
