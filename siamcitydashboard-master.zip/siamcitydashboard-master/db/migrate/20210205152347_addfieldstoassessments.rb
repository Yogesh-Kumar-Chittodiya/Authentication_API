class Addfieldstoassessments < ActiveRecord::Migration[5.2]
  def change
    add_column :assessments, :ai_created_on , :string
    add_column :customer_satisfaction_scores, :ai_created_on , :string
  end
end
