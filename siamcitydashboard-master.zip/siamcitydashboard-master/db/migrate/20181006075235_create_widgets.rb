class CreateWidgets < ActiveRecord::Migration[5.2]
  def change
    create_table :widgets do |t|
      t.string :name
      t.string :file_name
      t.string :size_type
      t.boolean :is_active, :default=>1
      t.boolean :is_delete, :default=>0
      t.timestamps
    end
  end
end
