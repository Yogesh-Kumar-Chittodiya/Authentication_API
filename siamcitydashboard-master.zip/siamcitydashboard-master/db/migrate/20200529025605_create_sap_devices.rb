class CreateSapDevices < ActiveRecord::Migration[5.2]
  def change
    create_table :sap_devices do |t|
      t.string :host_name
      t.text :url
      t.string :primary_app
      t.string :uid
      t.timestamps
    end
  end
end
