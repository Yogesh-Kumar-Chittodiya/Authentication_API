class AddFieldsToToOverallSlaStatus < ActiveRecord::Migration[5.2]
  def change
    add_column :overall_sla_statuses , :chg_state , :string
  end
end
