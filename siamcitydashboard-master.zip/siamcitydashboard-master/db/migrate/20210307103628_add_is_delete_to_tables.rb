class AddIsDeleteToTables < ActiveRecord::Migration[5.2]
  def change
    add_column :opsramp_device_downtimes, :is_delete ,:boolean
    add_column :sap_downtimes, :is_delete ,:boolean
    add_column :non_sap_downtimes, :is_delete ,:boolean
  end
end
