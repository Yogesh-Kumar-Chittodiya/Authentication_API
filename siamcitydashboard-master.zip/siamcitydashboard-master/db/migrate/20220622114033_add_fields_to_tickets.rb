class AddFieldsToTickets < ActiveRecord::Migration[5.2]
  def change
    add_column :incidents, :assigned_company, :string
    add_column :service_request_ageing_tickets, :assigned_company, :string
    add_column :service_request_items, :assigned_company, :string
    add_column :incident_ageing_tickets, :assigned_company, :string
    add_column :solarwind_interface_availabilities, :ip_address, :string
  end
end
