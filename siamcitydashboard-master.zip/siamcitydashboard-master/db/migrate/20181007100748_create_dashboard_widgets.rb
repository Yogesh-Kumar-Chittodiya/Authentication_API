class CreateDashboardWidgets < ActiveRecord::Migration[5.2]
  def change
    create_table :dashboard_widgets do |t|
      t.references :widget
      t.references :dashboard
      t.integer :sort_order
      t.timestamps 
    end
  end
end
