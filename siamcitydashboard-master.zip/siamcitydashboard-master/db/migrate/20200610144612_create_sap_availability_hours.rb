class CreateSapAvailabilityHours < ActiveRecord::Migration[5.2]
  def change
    create_table :sap_availability_hours do |t|
      t.integer :sap_device_id
      t.string :totalDowntime
      t.string :totalAvailability
      t.string :currentState
      t.json :downTimeList
      t.string :start_time
      t.string :end_time
      t.string :record_type
      t.integer :yesterday
      t.string :created_date
      t.string :month_to_date
      t.timestamps
    end
  end
end
