class CreateAdminBackupReports < ActiveRecord::Migration[5.2]
  def change
    create_table :admin_backup_reports do |t|
      t.string :country
      t.string :month
      t.json :data
      t.timestamps
    end
  end
end
