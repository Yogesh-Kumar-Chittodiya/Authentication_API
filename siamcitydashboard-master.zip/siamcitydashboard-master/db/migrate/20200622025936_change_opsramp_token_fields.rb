class ChangeOpsrampTokenFields < ActiveRecord::Migration[5.2]
  def change
    change_column :opsramp_tokens, :expires_at, :string
    add_column :opsramp_tokens, :type, :string
  end
end
