class CreateCustomerConfigurations < ActiveRecord::Migration[5.2]
  def change
    create_table :customer_configurations do |t|
      t.references :configuration_parameter
      t.references :customer, :default=>0
      t.text :value
    end
  end
end
