class CreateSapResponseDailies < ActiveRecord::Migration[5.2]
  def change
    create_table :sap_response_dailies do |t|
      t.date :kpi_date
      t.string :kpi_time
      t.string :kpi_name
      t.string :kpi_value
      t.string :kpi_rating
      t.timestamps
    end
  end
end
