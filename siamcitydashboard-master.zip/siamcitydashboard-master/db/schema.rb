# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2023_08_30_081427) do

  create_table "admin_backup_reports", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "country"
    t.string "month"
    t.json "data"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "created_year"
  end

  create_table "admin_patch_managements", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "device"
    t.string "month"
    t.string "num_of_devices"
    t.string "status"
    t.string "update_devices"
    t.string "update_pending_devices"
    t.text "remarks"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "created_year"
    t.integer "end_of_life"
  end

  create_table "assessments", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.datetime "taken_on"
    t.datetime "sys_updated_on"
    t.datetime "sys_created_on"
    t.date "expiration_date"
    t.date "due_date"
    t.string "trigger_id"
    t.string "assessment_group"
    t.string "task_id"
    t.string "number"
    t.string "sys_id"
    t.string "metric_type"
    t.string "state"
    t.string "sys_created_by"
    t.string "sys_mod_count"
    t.string "user"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "country"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "workstream"
    t.string "assignment_group"
    t.string "trigger_sys_id"
    t.string "ai_created_on"
  end

  create_table "blazer_audits", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "user_id"
    t.bigint "query_id"
    t.text "statement"
    t.string "data_source"
    t.datetime "created_at"
    t.index ["query_id"], name: "index_blazer_audits_on_query_id"
    t.index ["user_id"], name: "index_blazer_audits_on_user_id"
  end

  create_table "blazer_checks", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "creator_id"
    t.bigint "query_id"
    t.string "state"
    t.string "schedule"
    t.text "emails"
    t.text "slack_channels"
    t.string "check_type"
    t.text "message"
    t.datetime "last_run_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["creator_id"], name: "index_blazer_checks_on_creator_id"
    t.index ["query_id"], name: "index_blazer_checks_on_query_id"
  end

  create_table "blazer_dashboard_queries", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "dashboard_id"
    t.bigint "query_id"
    t.integer "position"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["dashboard_id"], name: "index_blazer_dashboard_queries_on_dashboard_id"
    t.index ["query_id"], name: "index_blazer_dashboard_queries_on_query_id"
  end

  create_table "blazer_dashboards", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "creator_id"
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["creator_id"], name: "index_blazer_dashboards_on_creator_id"
  end

  create_table "blazer_queries", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "creator_id"
    t.string "name"
    t.text "description"
    t.text "statement"
    t.string "data_source"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["creator_id"], name: "index_blazer_queries_on_creator_id"
  end

  create_table "configuration_parameters", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "parameter"
    t.string "slug"
    t.string "value_guide"
  end

  create_table "critical_devices", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "ip_address"
    t.string "host_name"
    t.string "logical_name"
    t.string "server_type"
    t.string "vm_cluster"
    t.string "location"
    t.string "device_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_delete"
    t.string "priority", default: "Non-Critical"
    t.string "landscape"
  end

  create_table "critical_incidents", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "number"
    t.datetime "sys_created_on"
    t.datetime "sys_updated_on"
    t.datetime "closed_at"
    t.string "sys_created_by"
    t.string "priority"
    t.text "short_description"
    t.string "assigned_to"
    t.string "caller_id"
    t.string "subcategory"
    t.string "assignment_group"
    t.string "sys_id"
    t.string "contact_type"
    t.string "incident_state"
    t.string "company"
    t.string "location"
    t.string "category"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "critical_security_alerts", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "u_critical_alerts"
    t.integer "compromised_alerts"
    t.string "status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "critical_servers", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "ip_address"
    t.string "name"
    t.text "description"
    t.string "location"
    t.string "server_type"
    t.string "host_name"
    t.string "os_system"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "customer_configurations", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "configuration_parameter_id"
    t.bigint "customer_id", default: 0
    t.text "value"
    t.index ["configuration_parameter_id"], name: "index_customer_configurations_on_configuration_parameter_id"
    t.index ["customer_id"], name: "index_customer_configurations_on_customer_id"
  end

  create_table "customer_satisfaction_scores", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.datetime "ai_taken_on"
    t.string "mr_actual_value"
    t.string "mr_assessment_group"
    t.string "mr_sys_created_by"
    t.string "ai_sys_id"
    t.string "mr_sys_id"
    t.string "mr_metric"
    t.string "mr_user"
    t.string "ai_task_id"
    t.string "md_display"
    t.string "ai_related_id_1"
    t.string "ai_related_id_2"
    t.string "ai_trigger_table"
    t.string "ai_expiration_date"
    t.string "mr_assign_to_order"
    t.string "md_sys_created_by"
    t.string "mr_instance"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "country"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "workstream"
    t.string "ai_created_on"
  end

  create_table "customers", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "name"
    t.string "slug"
    t.boolean "is_active", default: true
    t.string "logo"
    t.text "tools_configuration"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "dashboard_users", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "user_id"
    t.bigint "dashboard_id"
    t.string "role", default: "end_user"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_default", default: false
    t.index ["dashboard_id"], name: "index_dashboard_users_on_dashboard_id"
    t.index ["user_id"], name: "index_dashboard_users_on_user_id"
  end

  create_table "dashboard_widgets", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.bigint "widget_id"
    t.bigint "dashboard_id"
    t.integer "sort_order"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["dashboard_id"], name: "index_dashboard_widgets_on_dashboard_id"
    t.index ["widget_id"], name: "index_dashboard_widgets_on_widget_id"
  end

  create_table "dashboards", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "name"
    t.string "slug"
    t.bigint "customer_id", default: 0
    t.boolean "is_active", default: true
    t.boolean "is_delete", default: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_default", default: false
    t.boolean "without_user", default: false
    t.index ["customer_id"], name: "index_dashboards_on_customer_id"
  end

  create_table "dc_device_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.datetime "DateTime"
    t.date "created_date"
    t.string "created_time"
    t.string "AvailabilityToday"
    t.string "AvailabilityYesterday"
    t.string "AvailabilityMonth"
    t.string "record_type"
    t.string "NodeName"
    t.string "IPAddress"
    t.string "DeviceType"
    t.string "Status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "dc_device_availability_hours", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.datetime "DateTime"
    t.string "created_date"
    t.string "created_time"
    t.string "Availability"
    t.string "NodeName"
    t.string "IPAddress"
    t.string "DeviceType"
    t.string "Status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "dc_device_downtimes", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "StatusLED"
    t.string "Caption"
    t.string "IPAddress"
    t.string "NodeID"
    t.string "DataCenter"
    t.string "Devicetype"
    t.text "Message"
    t.string "DownEventTime"
    t.string "OutageDurationInSeconds"
    t.string "created_month"
    t.string "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "dc_device_utilization_hours", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "node_name"
    t.string "memory_percent"
    t.string "cpu_percent"
    t.string "NodeID"
    t.string "Caption"
    t.string "DeviceType"
    t.string "InstanceSiteId"
    t.string "record_type"
    t.string "created_date"
    t.string "created_time"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "dc_device_utilizations", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "node_name"
    t.string "memory_percent"
    t.string "cpu_percent"
    t.string "memory_yesterday"
    t.string "cpu_yesterday"
    t.string "memory_month"
    t.string "cpu_month"
    t.string "NodeID"
    t.string "Caption"
    t.string "DeviceType"
    t.string "InstanceSiteId"
    t.string "record_type"
    t.string "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "dc_devices", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.string "ObjectSubType"
    t.string "NodeName"
    t.string "DisplayName"
    t.string "IPAddress"
    t.string "Caption"
    t.boolean "IsServer"
    t.string "MachineType"
    t.text "NodeDescription"
    t.text "Description"
    t.text "DNS"
    t.text "Status"
    t.string "SysName"
    t.string "Vendor"
    t.string "DataCenter"
    t.string "DeviceCategory"
    t.datetime "LastSync"
    t.datetime "LastSystemUpTimePollUtc"
    t.datetime "NextPoll"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_delete"
  end

  create_table "dc_patch_managements", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "devices"
    t.string "num_of_devices"
    t.string "u_red"
    t.string "u_amber"
    t.string "u_green"
    t.text "remarks"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "month"
    t.string "created_year"
    t.string "end_of_life", default: "0"
    t.string "behind_patch", default: "0"
  end

  create_table "dc_sap_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "record_type"
    t.string "AvailabilityToday"
    t.string "AvailabilityYesterday"
    t.string "AvailabilityMonth"
    t.integer "NodeID"
    t.string "IPAddress"
    t.string "ApplicationName"
    t.string "ComponentName"
    t.integer "ComponentID"
    t.string "Status"
    t.string "Caption"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "dc_sap_availability_hours", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "record_type"
    t.string "created_date"
    t.string "created_time"
    t.string "Availability"
    t.integer "NodeID"
    t.string "IPAddress"
    t.string "ApplicationName"
    t.string "ComponentName"
    t.integer "ComponentID"
    t.string "Status"
    t.string "Caption"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "device_tickets", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "number"
    t.datetime "sys_created_on"
    t.datetime "sys_updated_on"
    t.datetime "closed_at"
    t.string "sys_created_by"
    t.string "priority"
    t.text "short_description"
    t.string "assigned_to"
    t.string "caller_id"
    t.string "subcategory"
    t.string "assignment_group"
    t.string "sys_id"
    t.string "contact_type"
    t.string "incident_state"
    t.string "company"
    t.string "location"
    t.string "category"
    t.string "created_date"
    t.string "u_indg_service_desk_counter"
    t.integer "reassignment_count"
    t.string "u_alert_type"
    t.string "cmdb_ci"
    t.string "correlation_display"
    t.string "country"
    t.string "workstream"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "resolved_at"
    t.string "u_target_completion_date_time"
    t.string "u_target_date_met_exceed"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "devices", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "unique_id"
    t.string "site_id"
    t.string "customer_id"
    t.string "ip_address"
    t.string "device_type"
    t.string "device_path"
    t.string "os_name"
    t.string "make"
    t.string "host_name"
    t.string "mac_address"
    t.string "device_category"
    t.string "status"
    t.string "state"
    t.date "modified_time"
    t.boolean "is_updated", default: true
    t.boolean "is_active", default: true
    t.boolean "is_new", default: true
    t.json "custom_attributes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "incident_ageing_tickets", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "number"
    t.datetime "sys_created_on"
    t.datetime "sys_updated_on"
    t.datetime "closed_at"
    t.string "sys_created_by"
    t.string "priority"
    t.text "short_description"
    t.string "assigned_to"
    t.string "caller_id"
    t.string "subcategory"
    t.string "assignment_group"
    t.string "sys_id"
    t.string "contact_type"
    t.string "incident_state"
    t.string "company"
    t.string "location"
    t.string "category"
    t.string "created_date"
    t.string "u_indg_service_desk_counter"
    t.integer "reassignment_count"
    t.string "u_alert_type"
    t.string "correlation_display"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "created_month"
    t.string "country"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "workstream"
    t.datetime "resolved_at"
    t.datetime "u_target_completion_date_time"
    t.string "u_target_date_met_exceed"
    t.string "cmdb_ci"
    t.string "created_year"
    t.string "assigned_company"
  end

  create_table "incidents", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "number"
    t.datetime "sys_created_on"
    t.datetime "sys_updated_on"
    t.datetime "closed_at"
    t.string "sys_created_by"
    t.string "priority"
    t.text "short_description"
    t.string "assigned_to"
    t.string "caller_id"
    t.string "subcategory"
    t.string "assignment_group"
    t.string "sys_id"
    t.string "contact_type"
    t.string "incident_state"
    t.string "company"
    t.string "location"
    t.string "category"
    t.string "u_indg_service_desk_counter"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "u_alert_type"
    t.string "correlation_display"
    t.integer "reassignment_count"
    t.string "country"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "workstream"
    t.datetime "resolved_at"
    t.datetime "u_target_completion_date_time"
    t.string "u_target_date_met_exceed"
    t.string "cmdb_ci"
    t.string "assigned_company"
  end

  create_table "local_patch_managements", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "devices"
    t.string "num_of_devices"
    t.string "u_red"
    t.string "u_amber"
    t.string "u_green"
    t.text "remarks"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "month"
    t.string "created_year"
  end

  create_table "local_system_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "country"
    t.string "site"
    t.string "system_availability_today"
    t.string "system_availability_yesterday"
    t.string "status_color"
    t.text "remarks"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "manual_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.json "local_system_availability"
    t.json "network_availability"
    t.json "o365_system_availability"
    t.json "dc_patch_management_status"
    t.json "local_patch_management_status"
    t.json "critical_security_alerts"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "non_sap_applications", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "name"
    t.json "devices"
    t.string "status"
    t.boolean "sla_breached"
    t.string "sla_category"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "non_sap_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "non_sap_device_id"
    t.string "totalDowntime"
    t.string "totalAvailability"
    t.string "currentState"
    t.json "downTimeList"
    t.string "start_time"
    t.string "end_time"
    t.string "record_type"
    t.string "yesterday"
    t.string "created_date"
    t.string "month_to_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "non_sap_devices", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "host_name"
    t.string "ip_address"
    t.string "primary_app"
    t.string "uid"
    t.string "device_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "non_sap_downtimes", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "non_sap_device_id"
    t.string "start_time"
    t.string "end_time"
    t.string "downtime_date"
    t.string "total_downtime"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "remark"
    t.boolean "isremoved"
    t.boolean "is_delete"
  end

  create_table "non_sap_performance_hours", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "non_sap_device_id"
    t.string "start_time"
    t.string "end_time"
    t.string "record_type"
    t.json "usage"
    t.json "yesterday"
    t.string "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "non_sap_performances", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "non_sap_device_id"
    t.string "start_time"
    t.string "end_time"
    t.string "record_type"
    t.json "usage"
    t.json "yesterday"
    t.string "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "o365_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "today_value"
    t.string "service"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.json "incidents"
    t.string "display_name"
    t.datetime "status_time"
    t.string "record_type"
  end

  create_table "opsramp_details", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "client_secret"
    t.string "client_key"
    t.string "client_id"
    t.string "msp_id"
    t.string "auth_url"
    t.string "api_url"
    t.string "location"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "opsramp_device_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "opsramp_device_id"
    t.string "totalDowntime"
    t.string "totalAvailability"
    t.string "currentState"
    t.json "downTimeList"
    t.string "start_time"
    t.string "end_time"
    t.string "record_type"
    t.integer "yesterday"
    t.string "created_date"
    t.string "month_to_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "ip_address", default: ""
    t.string "logical_name", default: ""
    t.string "node_name", default: ""
  end

  create_table "opsramp_device_downtimes", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "opsramp_device_id"
    t.string "start_time"
    t.string "end_time"
    t.string "downtime_date"
    t.string "total_downtime"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "remark"
    t.boolean "isremoved"
    t.boolean "is_delete"
    t.string "ip_address", default: ""
  end

  create_table "opsramp_devices", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "unique_id"
    t.string "host_name"
    t.string "ip_address"
    t.string "device_type"
    t.string "alias_name"
    t.string "resource_name"
    t.string "resource_type"
    t.string "device_name"
    t.string "os_name"
    t.string "make"
    t.text "description"
    t.string "mac_address"
    t.string "status"
    t.string "state"
    t.json "network_card_details"
    t.boolean "is_updated", default: true
    t.boolean "is_active", default: true
    t.boolean "is_new", default: true
    t.json "custom_attributes"
    t.string "location"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_delete"
  end

  create_table "opsramp_network_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "opsramp_network_id"
    t.integer "networkID"
    t.integer "AvailabilityToday"
    t.string "record_type"
    t.date "created_date"
    t.string "created_time"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "opsramp_networks", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "networkID"
    t.string "networkName"
    t.string "ifName"
    t.string "ifAlias"
    t.string "ifDescription"
    t.string "ifType"
    t.string "ifTxType"
    t.boolean "dhcpEnabled"
    t.string "speed"
    t.string "linkMode"
    t.string "confLinkSpeed"
    t.string "adminStatus"
    t.string "operationalStatus"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "opsramp_tokens", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "client_key"
    t.string "client_secret"
    t.string "auth_token"
    t.string "expires_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "type"
  end

  create_table "overall_sla_statuses", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "task_parent"
    t.text "task_short_description"
    t.string "sccc_sla_u_sccc_sla_text"
    t.string "task_assignment_group"
    t.string "task_state"
    t.string "tsla_stage"
    t.boolean "tsla_has_breached"
    t.string "task_number"
    t.string "task_sys_id"
    t.string "tsla_sys_id"
    t.string "task_sys_class_name"
    t.string "task_assigned_to"
    t.string "task_contact_type"
    t.string "tsla_schedule"
    t.string "task_priority"
    t.string "tsla_percentage"
    t.string "tsla_duration"
    t.datetime "tsla_sys_created_on"
    t.datetime "tsla_sys_updated_on"
    t.datetime "task_sys_updated_on"
    t.date "task_closed_at"
    t.datetime "tsla_end_time"
    t.text "task_comments_and_work_notes"
    t.string "tsla_business_time_left"
    t.string "task_opened_by"
    t.string "task_escalation"
    t.string "tsla_sla"
    t.string "task_company"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "task_sys_created_on"
    t.string "inc_state"
    t.string "ritm_state"
    t.string "ritm_stage"
    t.string "country"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "workstream"
    t.string "chg_state"
  end

  create_table "pdf_reports", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "month"
    t.string "report_name"
    t.boolean "is_delete"
    t.boolean "is_published"
    t.string "path"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "created_year"
  end

  create_table "regional_network_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "country"
    t.string "wan_availability"
    t.string "site"
    t.string "status_rag"
    t.string "internet_availability"
    t.text "remarks"
    t.string "lan_critical_device_availability"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "remarks_modules", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.text "remarks"
    t.string "report_name"
    t.date "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "created_month"
    t.string "created_year"
  end

  create_table "reports", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "customer_id"
    t.string "title"
    t.string "report_type"
    t.text "link"
    t.string "tool"
    t.boolean "is_active", default: true
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "roles", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "name"
    t.boolean "is_active", default: true
    t.boolean "is_delete", default: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sap_applications", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "name"
    t.json "devices"
    t.string "status"
    t.boolean "sla_breached"
    t.string "sla_category"
    t.integer "availability"
    t.integer "month_to_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sap_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "sap_device_id"
    t.string "totalDowntime"
    t.string "totalAvailability"
    t.string "currentState"
    t.json "downTimeList"
    t.string "start_time"
    t.string "end_time"
    t.string "record_type"
    t.integer "yesterday"
    t.string "created_date"
    t.string "month_to_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sap_devices", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "host_name"
    t.text "url"
    t.string "primary_app"
    t.string "uid"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "component_id"
  end

  create_table "sap_downtimes", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "sap_device_id"
    t.string "start_time"
    t.string "end_time"
    t.string "downtime_date"
    t.string "total_downtime"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "remark"
    t.boolean "isremoved"
    t.boolean "is_delete"
  end

  create_table "sap_response_dailies", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.date "kpi_date"
    t.string "kpi_time"
    t.string "kpi_name"
    t.string "kpi_value"
    t.string "kpi_rating"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sap_response_monthlies", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "kpi_name"
    t.string "kpi_value"
    t.string "kpi_value_system"
    t.date "kpi_date"
    t.string "kpi_time"
    t.string "kpi_rating"
    t.string "created_month"
    t.string "created_year"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "manual_response"
    t.text "remarks"
  end

  create_table "sap_response_mtds", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.date "kpi_date"
    t.string "kpi_time"
    t.string "kpi_name"
    t.string "kpi_value"
    t.string "kpi_rating"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sap_responses", options: "ENGINE=InnoDB DEFAULT CHARSET=latin1", force: :cascade do |t|
    t.string "kpi_name"
    t.string "kpi_value"
    t.date "kpi_date"
    t.string "kpi_time"
    t.string "kpi_rating"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "record_type"
  end

  create_table "service_request_ageing_tickets", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.datetime "closed_at"
    t.datetime "opened_at"
    t.datetime "sys_created_on"
    t.datetime "sys_updated_on"
    t.datetime "due_date"
    t.string "u_reassignment_reason"
    t.string "u_backlog"
    t.string "number"
    t.string "created_date"
    t.string "state"
    t.string "sys_created_by"
    t.string "u_manager_approval_flag"
    t.string "cmdb_ci"
    t.string "impact"
    t.string "active"
    t.string "priority"
    t.string "business_duration"
    t.text "short_description"
    t.string "u_sccc_response_sla_schedule"
    t.string "assigned_to"
    t.string "stage"
    t.string "made_sla"
    t.string "opened_by"
    t.string "u_response_sla_check"
    t.string "assignment_group"
    t.string "cat_item"
    t.string "u_sccc_response_sla_duration"
    t.string "request"
    t.string "sys_id"
    t.string "contact_type"
    t.string "urgency"
    t.string "sys_mod_count"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "created_month"
    t.string "country"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "workstream"
    t.datetime "u_target_completion_date_time"
    t.string "u_target_date_met_exceed"
    t.string "requested_for"
    t.datetime "u_fulfillment_start_time_stamp"
    t.string "created_year"
    t.string "assigned_company"
  end

  create_table "service_request_items", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.datetime "closed_at"
    t.datetime "opened_at"
    t.datetime "sys_created_on"
    t.datetime "sys_updated_on"
    t.datetime "due_date"
    t.string "u_reassignment_reason"
    t.string "u_backlog"
    t.string "number"
    t.string "state"
    t.string "sys_created_by"
    t.string "u_manager_approval_flag"
    t.string "cmdb_ci"
    t.string "impact"
    t.string "active"
    t.string "priority"
    t.string "business_duration"
    t.text "short_description"
    t.string "u_sccc_response_sla_schedule"
    t.string "assigned_to"
    t.string "stage"
    t.string "made_sla"
    t.string "opened_by"
    t.string "u_response_sla_check"
    t.string "assignment_group"
    t.string "cat_item"
    t.string "u_sccc_response_sla_duration"
    t.string "request"
    t.string "sys_id"
    t.string "contact_type"
    t.string "urgency"
    t.string "sys_mod_count"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "u_fulfillment_start_time_stamp"
    t.string "country"
    t.string "pillar"
    t.string "u_module"
    t.string "u_scope"
    t.string "workstream"
    t.datetime "u_target_completion_date_time"
    t.string "u_target_date_met_exceed"
    t.string "requested_for"
    t.string "assigned_company"
  end

  create_table "servicenow_feedbacks", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "ticket_number"
    t.string "assessment_sys_id"
    t.string "workstream"
    t.string "country"
    t.string "state"
    t.datetime "resolved_at"
    t.datetime "created_on"
    t.string "servicedesk_owner"
    t.string "pillar"
    t.integer "rating"
    t.boolean "is_updated", default: false
    t.datetime "call_date"
    t.string "call_successful"
    t.text "remarks"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "trigger_sys_id"
    t.string "user"
    t.boolean "feedback_updated", default: false
    t.string "ticket_priority"
    t.string "ticket_state"
    t.string "assigned_user"
    t.string "assignment_group"
  end

  create_table "servicenow_groups", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "parent"
    t.string "u_bfl"
    t.string "u_group_type"
    t.string "sys_updated_on"
    t.string "group_type"
    t.string "sys_id"
    t.string "sys_created_on"
    t.string "u_ppm_group_lead"
    t.string "u_sla_escalation_group"
    t.json "vendors"
    t.string "email"
    t.string "sys_created_by"
    t.string "manager"
    t.string "u_application_delivery_head"
    t.boolean "active"
    t.string "u_workstream"
    t.string "group_name"
    t.json "exclude_manager"
    t.json "include_members"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "u_module"
    t.string "u_scope"
  end

  create_table "servicenow_users", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.datetime "user_sys_created_on"
    t.datetime "comp_sys_updated_on"
    t.datetime "user_sys_updated_on"
    t.datetime "comp_sys_created_on"
    t.string "comp_stock_price"
    t.string "comp_name"
    t.string "user_sys_created_by"
    t.string "user_employee_number"
    t.string "user_sys_class_name"
    t.string "user_web_service_access_only"
    t.string "user_last_name"
    t.string "user_name"
    t.string "user_notification"
    t.string "comp_profits"
    t.string "user_first_name"
    t.string "comp_sys_created_by"
    t.string "user_department"
    t.string "comp_sys_updated_by"
    t.string "user_sys_updated_by"
    t.string "comp_sys_class_name"
    t.string "user_internal_integration_user"
    t.string "comp_sys_id"
    t.string "user_sys_id"
    t.string "user_manager"
    t.string "user_active"
    t.string "comp_notes"
    t.string "user_company"
    t.string "user_email"
    t.string "user_user_name"
    t.string "user_u_manager_email"
    t.string "comp_sys_mod_count"
    t.string "comp_customer"
    t.string "user_calendar_integration"
    t.string "comp_u_code"
    t.string "comp_country"
    t.string "user_u_persona_check"
    t.string "user_u_ppm_resource"
    t.string "user_location"
    t.string "user_u_user_persona"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "solarwind_component_downtimes", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "ComponentName"
    t.integer "ComponentID"
    t.text "Message"
    t.datetime "DownEventTime"
    t.integer "OutageDurationInSeconds"
    t.string "created_date"
    t.string "created_month"
    t.text "remarks"
    t.boolean "is_delete"
    t.boolean "isremoved"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "created_year"
  end

  create_table "solarwind_device_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.datetime "DateTime"
    t.date "created_date"
    t.string "created_time"
    t.string "AvailabilityToday"
    t.string "AvailabilityYesterday"
    t.string "AvailabilityMonth"
    t.string "record_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "node_name", default: ""
    t.string "ip_address", default: ""
    t.string "logical_name", default: ""
  end

  create_table "solarwind_device_availability_hours", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.datetime "DateTime"
    t.string "created_date"
    t.string "created_time"
    t.string "Availability"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "solarwind_device_downtimes", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "StatusLED"
    t.string "Caption"
    t.string "IPAddress"
    t.string "NodeID"
    t.string "DataCenter"
    t.string "Devicetype"
    t.text "Message"
    t.string "DownEventTime"
    t.string "OutageDurationInSeconds"
    t.string "created_month"
    t.string "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "remarks"
    t.boolean "isremoved"
    t.boolean "is_delete"
    t.string "created_year"
  end

  create_table "solarwind_devices", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.string "ObjectSubType"
    t.string "NodeName"
    t.string "DisplayName"
    t.string "IPAddress"
    t.string "Caption"
    t.boolean "IsServer"
    t.string "MachineType"
    t.text "NodeDescription"
    t.text "Description"
    t.text "DNS"
    t.text "Status"
    t.string "SysName"
    t.string "Vendor"
    t.string "DataCenter"
    t.string "DeviceCategory"
    t.datetime "LastSync"
    t.datetime "LastSystemUpTimePollUtc"
    t.datetime "NextPoll"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_delete"
  end

  create_table "solarwind_interface_availabilities", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.integer "InterfaceID"
    t.datetime "DateTime"
    t.string "AvailabilityToday"
    t.string "AvailabilityYesterday"
    t.string "AvailabilityMonth"
    t.string "record_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "ip_address"
  end

  create_table "solarwind_interface_availability_hours", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.integer "InterfaceID"
    t.datetime "DateTime"
    t.string "created_date"
    t.string "created_time"
    t.string "Availability"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "solarwind_interface_downtimes", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "StatusLED"
    t.string "MPLS_Details"
    t.string "DataCenter"
    t.string "Interface_Details"
    t.string "NodeID"
    t.string "InterfaceID"
    t.string "FullName"
    t.text "Message"
    t.string "DownEventTime"
    t.string "OutageDurationInSeconds"
    t.string "created_month"
    t.string "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "isremoved"
    t.text "remarks"
    t.boolean "is_delete"
    t.string "created_year"
  end

  create_table "solarwind_interfaces", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.integer "NodeID"
    t.integer "InterfaceID"
    t.string "ObjectSubType"
    t.string "Name"
    t.string "TypeName"
    t.string "TypeDescription"
    t.integer "Speed"
    t.integer "MTU"
    t.datetime "LastChange"
    t.string "PhysicalAddress"
    t.string "InBandwidth"
    t.string "OutBandwidth"
    t.text "Caption"
    t.text "FullName"
    t.datetime "LastSync"
    t.string "Alias"
    t.string "IfName"
    t.datetime "CustomPollerLastStatisticsPoll"
    t.datetime "NextPoll"
    t.integer "InterfaceSpeed"
    t.string "InterfaceCaption"
    t.string "InterfaceName"
    t.string "InterfaceTypeName"
    t.string "InterfaceAlias"
    t.datetime "InterfaceLastChange"
    t.string "InterfaceMTU"
    t.string "InterfaceTypeDescription"
    t.string "Status"
    t.string "MPLS_Details"
    t.string "DataCenter"
    t.string "Interface_Details"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_delete"
  end

  create_table "solarwind_response_times", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "record_type"
    t.string "AvgResponseTime"
    t.string "MaxResponseTime"
    t.string "MinResponseTime"
    t.integer "NodeID"
    t.string "IPAddress"
    t.string "Caption"
    t.string "ObservationTimestamp"
    t.string "created_month"
    t.string "created_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.text "Name"
    t.string "created_year"
  end

  create_table "users", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "name", default: ""
    t.string "role", default: "end_user", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "customer_id", default: 0
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  create_table "widget_records", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "name"
    t.string "value"
    t.string "status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "widgets", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8mb3", force: :cascade do |t|
    t.string "name"
    t.string "file_name"
    t.string "size_type"
    t.boolean "is_active", default: true
    t.boolean "is_delete", default: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "module", default: ""
    t.string "widget_type", default: "live"
    t.text "filters"
    t.string "title"
    t.text "configuration"
    t.text "options"
    t.string "table_name", default: ""
    t.string "url_query", default: ""
  end

end
